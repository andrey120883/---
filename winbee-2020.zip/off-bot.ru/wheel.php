<?
/*
Автор скрипта - OFF-BOT.RU, по всем вопросам пишите мне.
*/
include_once('inc/bd.php');
include_once('inc/config.php');

$query = ("SELECT * FROM `users` WHERE `sid` = '$sid'");
$result = mysqli_query($link,$query);
$search = mysqli_num_rows($result);

$search = mysqli_num_rows($result);
if($search == 0){
  header('Location: /');
}
?>
<html style="--vh:3.03px;">

<head>
  <title>Колесо фортуны — <? echo $site_name;?></title>
  <meta data-n-head="ssr" charset="utf-8">

  <script src="js/jQueryv3.3.1.js"></script>
  <script src="js/wheel.js"></script>
  <script src="js/toastr.js"></script>
  <link rel="stylesheet" href="js/toastr.css">
  <meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta data-n-head="ssr" name="apple-mobile-web-app-title" content="Winbee">
  <meta data-n-head="ssr" name="application-name" content="<? echo $site_name;?>">
  <meta data-n-head="ssr" name="msapplication-TileColor" content="#ffffff">
  <meta data-n-head="ssr" name="msapplication-config" content="/favicon/browserconfig.xml">
  <meta data-n-head="ssr" name="theme-color" content="#ffffff">
  <link data-n-head="ssr" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,600&amp;display=swap&amp;subset=cyrillic-ext">
  <link data-n-head="ssr" rel="apple-touch-icon" sizes="180x180" href="/favicon/apple-touch-icon.png">
  <link data-n-head="ssr" rel="icon" type="image/png" sizes="32x32" href="/favicon/favicon-32x32.png">
  <link data-n-head="ssr" rel="icon" type="image/png" sizes="16x16" href="/favicon/favicon-16x16.png">
  <link data-n-head="ssr" rel="manifest" href="/favicon/site.webmanifest">
  <link data-n-head="ssr" rel="mask-icon" href="/favicon/safari-pinned-tab.svg" color="381960">
  <link data-n-head="ssr" rel="shortcut icon" href="/favicon/favicon.ico">
  <script>
   <?
  if($prava == 1 || $prava == 2){
  echo 'function chat_admin(action,id){
    $.ajax({
        url: "inc/engine.php",
        type: "POST",
        dataType: "html",
        data: {
            id: id,
            type: \'chat_admin\',
            action: action,
        },
        success: function(data){
            obj = $.parseJSON(data);
            if(obj.notification == \'true\'){
                toastr[\'error\'](obj.mess);
            }

    }
  })
  }';
}
?>
  </script>
  <style data-vue-ssr-id="4f857918:0 2901aeae:0 3191d5ad:0 932a8f60:0 3c054965:0 7294dc5e:0 3db2ea20:0 7cd1bdc3:0 9f002ef8:0 b035a29a:0 52d2ce5c:0 0e0eb82f:0 22efe3a0:0 34bf7ba4:0 47e7e198:0 b9d01396:0 1765e5ca:0 44df22ea:0 66402b96:0 9ae97294:0 36d6a109:0 0ebf4dcb:0 f9cc371a:0 293cc79e:0 60edd0f6:0 ede60a42:0 b6c3e0b8:0 f1add17c:0 62c7f3c4:0 515e6b90:0 5f9a150f:0 5a214042:0 ba8e1006:0 e1a087e2:0 0311afca:0 28a3f015:0 0075ccc4:0 1bda4f16:0 1056a1e2:0">
    /*! normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css */
    
    html {
      line-height: 1.15;
      -webkit-text-size-adjust: 100%
    }
    
    body {
      margin: 0
    }
    
    main {
      display: block
    }
    
    h1 {
      font-size: 2em;
      margin: .67em 0
    }
    
    hr {
      box-sizing: content-box;
      height: 0;
      overflow: visible
    }
    
    pre {
      font-family: monospace, monospace;
      font-size: 1em
    }
    
    a {
      background-color: transparent
    }
    
    abbr[title] {
      border-bottom: none;
      text-decoration: underline;
      -webkit-text-decoration: underline dotted;
      text-decoration: underline dotted
    }
    
    b,
    strong {
      font-weight: bolder
    }
    
    code,
    kbd,
    samp {
      font-family: monospace, monospace;
      font-size: 1em
    }
    
    small {
      font-size: 80%
    }
    
    sub,
    sup {
      font-size: 75%;
      line-height: 0;
      position: relative;
      vertical-align: baseline
    }
    
    sub {
      bottom: -.25em
    }
    
    sup {
      top: -.5em
    }
    
    img {
      border-style: none
    }
    
    button,
    input,
    optgroup,
    select,
    textarea {
      font-family: inherit;
      font-size: 100%;
      line-height: 1.15;
      margin: 0
    }
    
    button,
    input {
      overflow: visible
    }
    
    button,
    select {
      text-transform: none
    }
    
    [type=button],
    [type=reset],
    [type=submit],
    button {
      -webkit-appearance: button
    }
    
    [type=button]::-moz-focus-inner,
    [type=reset]::-moz-focus-inner,
    [type=submit]::-moz-focus-inner,
    button::-moz-focus-inner {
      border-style: none;
      padding: 0
    }
    
    [type=button]:-moz-focusring,
    [type=reset]:-moz-focusring,
    [type=submit]:-moz-focusring,
    button:-moz-focusring {
      outline: 1px dotted ButtonText
    }
    
    fieldset {
      padding: .35em .75em .625em
    }
    
    legend {
      box-sizing: border-box;
      color: inherit;
      display: table;
      max-width: 100%;
      padding: 0;
      white-space: normal
    }
    
    progress {
      vertical-align: baseline
    }
    
    textarea {
      overflow: auto
    }
    
    [type=checkbox],
    [type=radio] {
      box-sizing: border-box;
      padding: 0
    }
    
    [type=number]::-webkit-inner-spin-button,
    [type=number]::-webkit-outer-spin-button {
      height: auto
    }
    
    [type=search] {
      -webkit-appearance: textfield;
      outline-offset: -2px
    }
    
    [type=search]::-webkit-search-decoration {
      -webkit-appearance: none
    }
    
    ::-webkit-file-upload-button {
      -webkit-appearance: button;
      font: inherit
    }
    
    details {
      display: block
    }
    
    summary {
      display: list-item
    }
    
    [hidden],
    template {
      display: none
    }
    
    .vue-notification-group {
      display: block;
      position: fixed;
      z-index: 5000
    }
    
    .vue-notification-wrapper {
      display: block;
      overflow: hidden;
      width: 100%;
      margin: 0;
      padding: 0
    }
    
    .notification-title {
      font-weight: 600
    }
    
    .vue-notification-template {
      background: #fff
    }
    
    .vue-notification,
    .vue-notification-template {
      display: block;
      box-sizing: border-box;
      text-align: left
    }
    
    .vue-notification {
      font-size: 12px;
      padding: 10px;
      margin: 0 5px 5px;
      color: #fff;
      background: #44a4fc;
      border-left: 5px solid #187fe7
    }
    
    .vue-notification.warn {
      background: #ffb648;
      border-left-color: #f48a06
    }
    
    .vue-notification.error {
      background: #e54d42;
      border-left-color: #b82e24
    }
    
    .vue-notification.success {
      background: #68cd86;
      border-left-color: #42a85f
    }
    
    .vn-fade-enter-active,
    .vn-fade-leave-active,
    .vn-fade-move {
      transition: all .5s
    }
    
    .vn-fade-enter,
    .vn-fade-leave-to {
      opacity: 0
    }
    
    .nuxt-progress {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      height: 2px;
      width: 0;
      opacity: 1;
      -webkit-transition: width .1s, opacity .4s;
      transition: width .1s, opacity .4s;
      background-color: #fff;
      z-index: 999999
    }
    
    .nuxt-progress.nuxt-progress-notransition {
      -webkit-transition: none;
      transition: none
    }
    
    .nuxt-progress-failed {
      background-color: red
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      -ms-overflow-style: none;
      scrollbar-width: none
    }
    
    body {
      background: #381960;
      font-family: Source Sans Pro, sans-serif;
      font-size: 14px
    }
    
    ul {
      margin: 0;
      padding: 0
    }
    
    a {
      color: #ffed2a;
      text-decoration: none
    }
    
    h1,
    h2,
    h3,
    h4,
    h5 {
      color: #fff;
      font-weight: 700
    }
    
    h2 {
      font-size: 30px
    }
    
    h3 {
      font-size: 26px
    }
    
    h4 {
      font-size: 20px
    }
    
    circle,
    path,
    rect {
      -webkit-transition: all .3s;
      transition: all .3s
    }
    
    a,
    button,
    input,
    select,
    textarea {
      -webkit-tap-highlight-color: rgba(0, 0, 0, 0)
    }
    
    .vue-notification-group {
      display: block;
      position: fixed;
      z-index: 5000
    }
    
    .vue-notification-wrapper {
      display: block;
      overflow: hidden;
      width: 100%;
      margin: 0;
      padding: 0
    }
    
    .notification-title {
      font-weight: 700;
      font-size: 12px;
      text-transform: uppercase;
      line-height: 18px
    }
    
    .vue-notification,
    .vue-notification-template {
      display: block;
      box-sizing: border-box;
      background: #fff;
      text-align: left
    }
    
    .vue-notification {
      font-size: 14px;
      line-height: 20px;
      padding: 10px 15px;
      margin: 5px;
      color: #3f2652;
      border-radius: 4px;
      box-shadow: 0 5px 10px 0 rgba(0, 0, 0, .6)
    }
    
    .vue-notification.warn {
      background: #ffb648
    }
    
    .vue-notification.error {
      background: #ff5553;
      color: #fff
    }
    
    .vue-notification.success {
      background: #4dc500;
      color: #fff
    }
    
    .vn-fade-enter-active,
    .vn-fade-leave-active,
    .vn-fade-move {
      -webkit-transition: all .5s;
      transition: all .5s
    }
    
    .vn-fade-enter,
    .vn-fade-leave-to {
      opacity: 0
    }
    
    .content[data-v-31cda96b] {
      border-bottom: 1px solid hsla(0, 0%, 100%, .2);
      padding-bottom: 17px
    }
    
    @media screen and (max-width:719px) {
      .content[data-v-31cda96b] {
        border-bottom: none;
        padding-bottom: 0
      }
    }
    
    .content__wrap[data-v-31cda96b] {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 30px;
      display: -webkit-box;
      display: flex
    }
    
    @media screen and (max-width:719px) {
      .content__wrap[data-v-31cda96b] {
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        flex-direction: column;
        padding: 0
      }
    }
    
    .content__header[data-v-31cda96b] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center;
      -webkit-transform: translateX(-3px);
      transform: translateX(-3px);
      margin-bottom: 5px
    }
    
    @media screen and (max-width:850px) {
      .content__header[data-v-31cda96b] {
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        flex-direction: column
      }
    }
    
    @media screen and (max-width:719px) {
      .content__header[data-v-31cda96b] {
        -webkit-box-orient: horizontal;
        -webkit-box-direction: normal;
        flex-direction: row;
        -webkit-transform: none;
        transform: none;
        padding: 0 0 0 9px
      }
    }
    
    @media screen and (max-width:719px) {
      .content__header span[data-v-31cda96b] {
        display: none
      }
    }
    
    .content__header h1[data-v-31cda96b] {
      font-size: 48px;
      font-weight: 800;
      color: #fff;
      margin: 0
    }
    
    @media screen and (max-width:719px) {
      .content__header h1[data-v-31cda96b] {
        font-size: 26px
      }
    }
    
    .header[data-v-180c07fb] {
      height: 82px;
      -webkit-box-pack: justify;
      justify-content: space-between;
      padding: 0 30px;
      max-width: 1200px;
      margin: 0 auto
    }
    
    .header[data-v-180c07fb],
    .header__user[data-v-180c07fb] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center
    }
    
    @media (max-width:1199px) {
      .header[data-v-180c07fb] {
        height: 60px;
        padding: 0 10px
      }
    }
    
    .logo[data-v-2b804d1f] {
      display: block;
      width: 110px;
      height: 29px;
      font-size: 25px;
    }
    
    @media (max-width:1199px) {
      .logo[data-v-2b804d1f] {
        width: 33px;
        height: 30px;
      }
    }
    
    .menu-desktop[data-v-52012dc4] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center;
      -webkit-box-pack: start;
      justify-content: flex-start;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
    
    .menu__item[data-v-52012dc4] {
      list-style: none;
      margin-right: 50px
    }
    
    .menu__item[data-v-52012dc4]:last-child {
      margin-right: 0
    }
    
    .menu__link[data-v-52012dc4] {
      display: inline-block;
      font-size: 16px;
      color: #a698af;
      -webkit-transition: color .2s ease-in-out;
      transition: color .2s ease-in-out;
      cursor: pointer
    }
    
    .menu__link[data-v-52012dc4]:hover {
      color: #fff
    }
    
    .menu__link_active[data-v-52012dc4] {
      position: relative;
      color: #fff
    }
    
    .menu__link_active[data-v-52012dc4]:after {
      content: "";
      width: 100%;
      height: 2px;
      background-color: #ffed2a;
      position: absolute;
      bottom: -5px;
      left: 0
    }
    
    @media (max-width:1199px) {
      .menu-desktop[data-v-52012dc4] {
        display: none
      }
    }
    
    @media screen and (min-width:1200px) {
      .menu-mobile[data-v-58233ac6] {
        display: none!important
      }
    }
    
    .menu-mobile[data-v-58233ac6] {
      height: 50px;
      -webkit-box-align: center;
      align-items: center;
      -webkit-box-pack: justify;
      justify-content: space-between;
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      z-index: 10;
      padding: 0 10px;
      background: #381960;
      border-top: 1px solid hsla(0, 0%, 100%, .1)
    }
    
    .menu-mobile[data-v-58233ac6],
    .menu__items[data-v-58233ac6] {
      display: -webkit-box;
      display: flex
    }
    
    .menu__items[data-v-58233ac6] {
      -webkit-box-align: start;
      align-items: flex-start;
      -webkit-box-pack: start;
      justify-content: flex-start;
      height: 100%
    }
    
    .menu__item[data-v-58233ac6] {
      display: block;
      list-style: none;
      font-size: 10px;
      color: #a698af;
      padding-top: 10px;
      margin-right: 20px;
      text-align: center
    }
    
    .menu__link[data-v-58233ac6] {
      display: inline-block;
      color: #a698af;
      -webkit-transition: color .2s ease-in-out;
      transition: color .2s ease-in-out;
      cursor: pointer
    }
    
    .menu__link_active[data-v-58233ac6] {
      color: #fff
    }
    
    .menu__icon_default[data-v-58233ac6] {
      display: inline
    }
    
    .menu__icon_active[data-v-58233ac6],
    .menu__link_active .menu__icon_default[data-v-58233ac6] {
      display: none
    }
    
    .menu__link_active .menu__icon_active[data-v-58233ac6] {
      display: inline
    }
    
    .menu__additional[data-v-58233ac6] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center;
      -webkit-box-pack: start;
      justify-content: flex-start;
      border-radius: 5px;
      background-color: hsla(0, 0%, 100%, .1);
      padding: 8px 9px 8px 11px
    }
    
    .chat-button[data-v-75f76985] {
      width: 18px;
      height: 18px;
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxOCIgaGVpZ2h0PSIxOCIgdmlld0JveD0iMCAwIDE4IDE4Ij4KICAgIDxwYXRoIGZpbGw9IiNCMEFBQjMiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTguNSAxNC43NTljNS4yNDcgMCA5LjUtMS43MTQgOS41LTcuMzhTMTQuNzQ3IDAgOS41IDAgMCAxLjcxMyAwIDcuMzhjMCAzLjUzMyAxLjY1NSA1LjUzIDQuMTczIDYuNTMxLjE2Ni45NzctLjU1OCAyLjM0LTIuMTczIDQuMDg5IDMuNTIyLS41MDggNS41MjItMS41MDggNi0zIC43MDEtLjAwMy0uMDgzLS4yNDEuNS0uMjQxem0tMS4yMy0uNzU2bC0uMjIyLjY5MmMtLjIyLjY4OS0xLjA3MSAxLjI5OS0yLjU5IDEuNzYzLjU5OC0xLjAwMi44NC0xLjg5Ny43LTIuNzE1bC0uMDk0LS41NTMtLjUyMS0uMjA4QzIuMjA0IDEyLjA1MiAxIDEwLjI5IDEgNy4zOCAxIDIuOTIzIDMuOTA5IDEgOS41IDEgMTQuNzYyIDEgMTcgMi43MzIgMTcgNy4zOGMwIDQuNDU1LTIuOTA5IDYuMzc5LTguNSA2LjM3OS0uMzYyIDAtLjU4NS4wMzItLjgzNy4yNDJsLS4zOTQuMDAyeiIvPgo8L3N2Zz4K) no-repeat 50%
    }
    
    .balance[data-v-1d7aa3c2] {
      font-size: 26px;
      font-weight: 700;
      color: #ffed2a
    }
    
    @media (max-width:1199px) {
      .balance[data-v-1d7aa3c2] {
        font-size: 20px
      }
    }
    
    .wallet[data-v-2f84b7f5] {
      display: block;
      width: 86px;
      height: 34px;
      font-size: 12px;
      font-weight: 700;
      line-height: 1.5;
      text-transform: uppercase;
      margin-left: 15px;
      color: #fff;
      background: url(/_nuxt/img/06f9df4.svg) no-repeat 50%;
      -webkit-transition: background-image .2s ease-in-out;
      transition: background-image .2s ease-in-out;
      text-decoration: none;
      padding-left: 11px;
      padding-top: 8px
    }
    
    .wallet[data-v-2f84b7f5]:hover {
      background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4NiIgaGVpZ2h0PSIzNCIgdmlld0JveD0iMCAwIDg2IDM0Ij4KICAgIDxwYXRoIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTc5LjU5IDBjMi4yMyAwIDMuMDM3LjIzMiAzLjg1Mi42NjhhNC41NDMgNC41NDMgMCAwIDEgMS44OSAxLjg5Yy40MzYuODE1LjY2OCAxLjYyMy42NjggMy44NTJ2MjEuMThjMCAyLjIzLS4yMzIgMy4wMzctLjY2OCAzLjg1MmE0LjU0MyA0LjU0MyAwIDAgMS0xLjg5IDEuODljLS44MTUuNDM2LTEuNjIzLjY2OC0zLjg1Mi42NjhINi40MWMtMi4yMyAwLTMuMDM3LS4yMzItMy44NTItLjY2OGE0LjU0MyA0LjU0MyAwIDAgMS0xLjg5LTEuODlDLjIzMiAzMC42MjcgMCAyOS44MiAwIDI3LjU5VjYuNDFjMC0yLjIzLjIzMi0zLjAzNy42NjgtMy44NTJhNC41NDMgNC41NDMgMCAwIDEgMS44OS0xLjg5QzMuMzczLjIzMiA0LjE4IDAgNi40MSAwaDczLjE4em0uMjY0IDJINi40MWMtMS43MyAwLTIuMzEyLjExMi0yLjkwOS40MzEtLjQ2Ni4yNS0uODIuNjA0LTEuMDcgMS4wNy0uMzAyLjU2NS0uNDE5IDEuMTE3LS40MyAyLjY0NUwyIDI3LjU5YzAgMS43My4xMTIgMi4zMTIuNDMxIDIuOTA5LjI1LjQ2Ni42MDQuODIgMS4wNyAxLjA3LjU5Ny4zMTkgMS4xNzkuNDMxIDIuOTA5LjQzMWg3My4xOGMxLjczIDAgMi4zMTItLjExMiAyLjkwOS0uNDMxLjQ2Ni0uMjUuODItLjYwNCAxLjA3LTEuMDcuMzE5LS41OTcuNDMxLTEuMTc5LjQzMS0yLjkwOVYyMmgtNmEzIDMgMCAwIDEtMy0zdi00YTMgMyAwIDAgMSAzLTNoNlY2LjQxYzAtMS43My0uMTEyLTIuMzEyLS40MzEtMi45MDlhMi41NDQgMi41NDQgMCAwIDAtMS4wNy0xLjA3Yy0uNTY1LS4zMDItMS4xMTctLjQxOS0yLjY0NS0uNDN6TTg0IDEzaC02YTIgMiAwIDAgMC0yIDJ2NGEyIDIgMCAwIDAgMiAyaDZ2LTh6bS00IDJhMiAyIDAgMSAxIDAgNCAyIDIgMCAwIDEgMC00eiIvPgo8L3N2Zz4K)
    }
    
    .wallet[data-v-2f84b7f5]:active {
      background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4NiIgaGVpZ2h0PSIzNCIgdmlld0JveD0iMCAwIDg2IDM0Ij4KICAgIDxwYXRoIGZpbGw9IiNGRkVEMkEiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTc5LjU5IDBjMi4yMyAwIDMuMDM3LjIzMiAzLjg1Mi42NjhhNC41NDMgNC41NDMgMCAwIDEgMS44OSAxLjg5Yy40MzYuODE1LjY2OCAxLjYyMy42NjggMy44NTJ2MjEuMThjMCAyLjIzLS4yMzIgMy4wMzctLjY2OCAzLjg1MmE0LjU0MyA0LjU0MyAwIDAgMS0xLjg5IDEuODljLS44MTUuNDM2LTEuNjIzLjY2OC0zLjg1Mi42NjhINi40MWMtMi4yMyAwLTMuMDM3LS4yMzItMy44NTItLjY2OGE0LjU0MyA0LjU0MyAwIDAgMS0xLjg5LTEuODlDLjIzMiAzMC42MjcgMCAyOS44MiAwIDI3LjU5VjYuNDFjMC0yLjIzLjIzMi0zLjAzNy42NjgtMy44NTJhNC41NDMgNC41NDMgMCAwIDEgMS44OS0xLjg5QzMuMzczLjIzMiA0LjE4IDAgNi40MSAwaDczLjE4em0uMjY0IDJINi40MWMtMS43MyAwLTIuMzEyLjExMi0yLjkwOS40MzEtLjQ2Ni4yNS0uODIuNjA0LTEuMDcgMS4wNy0uMzAyLjU2NS0uNDE5IDEuMTE3LS40MyAyLjY0NUwyIDI3LjU5YzAgMS43My4xMTIgMi4zMTIuNDMxIDIuOTA5LjI1LjQ2Ni42MDQuODIgMS4wNyAxLjA3LjU5Ny4zMTkgMS4xNzkuNDMxIDIuOTA5LjQzMWg3My4xOGMxLjczIDAgMi4zMTItLjExMiAyLjkwOS0uNDMxLjQ2Ni0uMjUuODItLjYwNCAxLjA3LTEuMDcuMzE5LS41OTcuNDMxLTEuMTc5LjQzMS0yLjkwOVYyMmgtNmEzIDMgMCAwIDEtMy0zdi00YTMgMyAwIDAgMSAzLTNoNlY2LjQxYzAtMS43My0uMTEyLTIuMzEyLS40MzEtMi45MDlhMi41NDQgMi41NDQgMCAwIDAtMS4wNy0xLjA3Yy0uNTY1LS4zMDItMS4xMTctLjQxOS0yLjY0NS0uNDN6TTg0IDEzaC02YTIgMiAwIDAgMC0yIDJ2NGEyIDIgMCAwIDAgMiAyaDZ2LTh6bS00IDJhMiAyIDAgMSAxIDAgNCAyIDIgMCAwIDEgMC00eiIvPgo8L3N2Zz4K)
    }
    
    @media (max-width:1199px) {
      .wallet[data-v-2f84b7f5] {
        margin-left: 11px
      }
    }
    
    .profile[data-v-2be93831] {
      width: 26px;
      height: 26px;
      margin-left: 15px;
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNiIgaGVpZ2h0PSIyNiIgdmlld0JveD0iMCAwIDI2IDI2Ij4KICAgIDxwYXRoIGZpbGw9IiNGRkYiIGZpbGwtb3BhY2l0eT0iLjIiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTEzIDBjNy4xOCAwIDEzIDUuODIgMTMgMTNzLTUuODIgMTMtMTMgMTNTMCAyMC4xOCAwIDEzIDUuODIgMCAxMyAwem0wIDJDNi45MjUgMiAyIDYuOTI1IDIgMTNjMCAzLjM1OSAxLjUwNiA2LjM2NiAzLjg3OSA4LjM4NEw1LjUgMjAuNWw0LjUxMi0xLjI5MlYxNi43NWMtLjA2NC0uMDU4LS4xMjctLjExLS4xODUtLjE2Ny0xLjA3OS0xLjA0NS0xLjYzOS0yLjUxNi0xLjYzOS00LjAxNnYtMi40OEE0LjIxMyA0LjIxMyAwIDAgMSAxMi40IDUuODc1aDEuMTJhNC4yMTMgNC4yMTMgMCAwIDEgNC4yMSA0LjIxMnYyLjQ4YzAgMS41LS41NTkgMi45NzEtMS42MzggNC4wMTZsLS4xODQuMTY3djIuNDU4TDIwLjUgMjAuNWwuMTQuNDE1QzIyLjcxIDE4LjkxNSAyNCAxNi4xMDggMjQgMTNjMC02LjA3NS00LjkyNS0xMS0xMS0xMXoiLz4KPC9zdmc+Cg==) no-repeat 50%;
      -webkit-transition: background-image .2s ease-in-out;
      transition: background-image .2s ease-in-out;
      cursor: pointer;
      text-decoration: none
    }
    
    .profile[data-v-2be93831]:hover {
      background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNiIgaGVpZ2h0PSIyNiIgdmlld0JveD0iMCAwIDI2IDI2Ij4KICAgIDxwYXRoIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTEzIDBjNy4xOCAwIDEzIDUuODIgMTMgMTNzLTUuODIgMTMtMTMgMTNTMCAyMC4xOCAwIDEzIDUuODIgMCAxMyAwem0wIDJDNi45MjUgMiAyIDYuOTI1IDIgMTNjMCAzLjM1OSAxLjUwNiA2LjM2NiAzLjg3OSA4LjM4NEw1LjUgMjAuNWw0LjUxMi0xLjI5MlYxNi43NWMtLjA2NC0uMDU4LS4xMjctLjExLS4xODUtLjE2Ny0xLjA3OS0xLjA0NS0xLjYzOS0yLjUxNi0xLjYzOS00LjAxNnYtMi40OEE0LjIxMyA0LjIxMyAwIDAgMSAxMi40IDUuODc1aDEuMTJhNC4yMTMgNC4yMTMgMCAwIDEgNC4yMSA0LjIxMnYyLjQ4YzAgMS41LS41NTkgMi45NzEtMS42MzggNC4wMTZsLS4xODQuMTY3djIuNDU4TDIwLjUgMjAuNWwuMTQuNDE1QzIyLjcxIDE4LjkxNSAyNCAxNi4xMDggMjQgMTNjMC02LjA3NS00LjkyNS0xMS0xMS0xMXoiLz4KPC9zdmc+Cg==)
    }
    
    .profile[data-v-2be93831]:active {
      background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNiIgaGVpZ2h0PSIyNiIgdmlld0JveD0iMCAwIDI2IDI2Ij4KICAgIDxwYXRoIGZpbGw9IiNGRkVEMkEiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTEzIDBjNy4xOCAwIDEzIDUuODIgMTMgMTNzLTUuODIgMTMtMTMgMTNTMCAyMC4xOCAwIDEzIDUuODIgMCAxMyAwem0wIDJDNi45MjUgMiAyIDYuOTI1IDIgMTNjMCAzLjM1OSAxLjUwNiA2LjM2NiAzLjg3OSA4LjM4NEw1LjUgMjAuNWw0LjUxMi0xLjI5MlYxNi43NWMtLjA2NC0uMDU4LS4xMjctLjExLS4xODUtLjE2Ny0xLjA3OS0xLjA0NS0xLjYzOS0yLjUxNi0xLjYzOS00LjAxNnYtMi40OEE0LjIxMyA0LjIxMyAwIDAgMSAxMi40IDUuODc1aDEuMTJhNC4yMTMgNC4yMTMgMCAwIDEgNC4yMSA0LjIxMnYyLjQ4YzAgMS41LS41NTkgMi45NzEtMS42MzggNC4wMTZsLS4xODQuMTY3djIuNDU4TDIwLjUgMjAuNWwuMTQuNDE1QzIyLjcxIDE4LjkxNSAyNCAxNi4xMDggMjQgMTNjMC02LjA3NS00LjkyNS0xMS0xMS0xMXoiLz4KPC9zdmc+Cg==)
    }
    
    @media (max-width:1199px) {
      .profile[data-v-2be93831] {
        margin-left: 11px
      }
    }
    
    .main-page[data-v-84c2ab78] {
      width: 100%
    }
    
    .main-page__menu[data-v-84c2ab78] {
      width: 100%;
      display: -webkit-box;
      display: flex;
      flex-wrap: wrap;
      max-width: 1200px;
      -webkit-box-pack: justify;
      justify-content: space-between
    }
    
    .main-page__benefits[data-v-84c2ab78] {
      margin-top: 25px
    }
    
    .main-page__columnns[data-v-84c2ab78] {
      display: -webkit-box;
      display: flex;
      margin-top: 5px;
      padding-bottom: 10px
    }
    
    .main-page__chat[data-v-84c2ab78] {
      margin-top: 20px;
      padding-left: 20px
    }
    
    @media screen and (max-width:1100px) {
      .main-page[data-v-84c2ab78] {
        padding: 0
      }
      .main-page__menu[data-v-84c2ab78] {
        max-width: auto;
        padding: 0 10px
      }
      .main-page__benefits[data-v-84c2ab78] {
        margin-top: 10px
      }
      .main-page__columnns[data-v-84c2ab78] {
        display: block
      }
      .main-page__chat[data-v-84c2ab78] {
        display: none
      }
    }
    
    .game-cover {
      cursor: pointer;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
      height: 302px
    }
    
    .game-cover_disabled {
      cursor: default
    }
    
    .game-cover__wrapper {
      position: relative;
      height: 100%;
      -webkit-transition: -webkit-transform .3s;
      transition: -webkit-transform .3s;
      transition: transform .3s;
      transition: transform .3s, -webkit-transform .3s
    }
    
    .game-cover:not(.game-cover_disabled):hover .game-cover__wrapper {
      -webkit-transform: translateY(-5px);
      transform: translateY(-5px)
    }
    
    .game-cover:not(.game-cover_disabled):hover .game-cover__image {
      box-shadow: 0 8px 20px 0 rgba(0, 0, 0, .3)
    }
    
    .game-cover__image {
      border-radius: 7px;
      -webkit-transition: box-shadow .3s, -webkit-transform .3s;
      transition: box-shadow .3s, -webkit-transform .3s;
      transition: transform .3s, box-shadow .3s;
      transition: transform .3s, box-shadow .3s, -webkit-transform .3s
    }
    
    .game-cover__name {
      position: absolute;
      left: 23px;
      bottom: 23px;
      z-index: 1;
      color: #fff;
      font-size: 26px;
      font-weight: 700
    }
    
    .game-cover__later,
    .game-cover__novelty {
      position: absolute;
      top: 20px;
      right: 0;
      width: 75px;
      height: 31px;
      background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAfCAMAAACYj8A5AAAAOVBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC8dlA9AAAAE3RSTlPLAMHIVTAVBr2brqJ/cGFNQx4Pq2jKPwAAAGVJREFUSMfl1csNwDAIA1AcSv5p0+w/bJfwwVIZ4AkJZBtiuJEmV6PNZZpWTjwLm2jhJlqYRKs0noXTeRbeyrMQzrPwEC0solUSz8LQ3GtJ3jFc8e9Pl8yJKZmrW7OHftG10ZxEfb6iAgejZ9qJAAAAAElFTkSuQmCC)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .game-cover__later,
      .game-cover__novelty {
        background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAAA+CAMAAAD+kBJTAAAAYFBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD6T+iNAAAAIHRSTlPLAMeiv1XEuZYnHwunn5qSFxIFtH11a2FRTUM7M4mISpspbwcAAADySURBVGje1dqHEcIwEETR/eScc+y/S8DgwTYNfF4FmrF0uj05AIdBPzKwbMeH1SBCdGPEPEb0YoTuEBaYxoh7jMBYtgKjTnyASys6AMfo8LKLDYVrZCiMbceRt+U6KnwMXWWC0llVJii5Gi++tvHgayXqCKkYT2JB1ULTE1IztLTQ1J3iQMM+CjQ50ixNI0W1p8kRhfixicDfLMv5EaVb3lkgnOXUefk4r2pnY+NsA6VNszNiOAOZM746w75zNCIdJN0iIx5SOke6zgG49LnAcz9XcIgRsxhh3FkJwmP45HxO1P5w4NzzsDCuC6DbtsTD0gMZMQZgpm54ewAAAABJRU5ErkJggg==)
      }
    }
    
    .game-cover__later,
    .game-cover__novelty {
      background: -webkit-image-set(url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAfCAMAAACYj8A5AAAAOVBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC8dlA9AAAAE3RSTlPLAMHIVTAVBr2brqJ/cGFNQx4Pq2jKPwAAAGVJREFUSMfl1csNwDAIA1AcSv5p0+w/bJfwwVIZ4AkJZBtiuJEmV6PNZZpWTjwLm2jhJlqYRKs0noXTeRbeyrMQzrPwEC0solUSz8LQ3GtJ3jFc8e9Pl8yJKZmrW7OHftG10ZxEfb6iAgejZ9qJAAAAAElFTkSuQmCC) 1x, url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAAA+CAMAAAD+kBJTAAAAYFBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD6T+iNAAAAIHRSTlPLAMeiv1XEuZYnHwunn5qSFxIFtH11a2FRTUM7M4mISpspbwcAAADySURBVGje1dqHEcIwEETR/eScc+y/S8DgwTYNfF4FmrF0uj05AIdBPzKwbMeH1SBCdGPEPEb0YoTuEBaYxoh7jMBYtgKjTnyASys6AMfo8LKLDYVrZCiMbceRt+U6KnwMXWWC0llVJii5Gi++tvHgayXqCKkYT2JB1ULTE1IztLTQ1J3iQMM+CjQ50ixNI0W1p8kRhfixicDfLMv5EaVb3lkgnOXUefk4r2pnY+NsA6VNszNiOAOZM746w75zNCIdJN0iIx5SOke6zgG49LnAcz9XcIgRsxhh3FkJwmP45HxO1P5w4NzzsDCuC6DbtsTD0gMZMQZgpm54ewAAAABJRU5ErkJggg==) 2x);
      background: image-set(url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAfCAMAAACYj8A5AAAAOVBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC8dlA9AAAAE3RSTlPLAMHIVTAVBr2brqJ/cGFNQx4Pq2jKPwAAAGVJREFUSMfl1csNwDAIA1AcSv5p0+w/bJfwwVIZ4AkJZBtiuJEmV6PNZZpWTjwLm2jhJlqYRKs0noXTeRbeyrMQzrPwEC0solUSz8LQ3GtJ3jFc8e9Pl8yJKZmrW7OHftG10ZxEfb6iAgejZ9qJAAAAAElFTkSuQmCC) 1x, url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAAA+CAMAAAD+kBJTAAAAYFBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD6T+iNAAAAIHRSTlPLAMeiv1XEuZYnHwunn5qSFxIFtH11a2FRTUM7M4mISpspbwcAAADySURBVGje1dqHEcIwEETR/eScc+y/S8DgwTYNfF4FmrF0uj05AIdBPzKwbMeH1SBCdGPEPEb0YoTuEBaYxoh7jMBYtgKjTnyASys6AMfo8LKLDYVrZCiMbceRt+U6KnwMXWWC0llVJii5Gi++tvHgayXqCKkYT2JB1ULTE1IztLTQ1J3iQMM+CjQ50ixNI0W1p8kRhfixicDfLMv5EaVb3lkgnOXUefk4r2pnY+NsA6VNszNiOAOZM746w75zNCIdJN0iIx5SOke6zgG49LnAcz9XcIgRsxhh3FkJwmP45HxO1P5w4NzzsDCuC6DbtsTD0gMZMQZgpm54ewAAAABJRU5ErkJggg==) 2x);
      color: #fff;
      font-size: 13px;
      font-weight: 700;
      padding-top: 8px;
      padding-left: 21px
    }
    
    .game-cover__later {
      background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAfCAMAAACYj8A5AAAAP1BMVEUAAAD///////////////////////////////////////////////////////////////////////////////9Du/pqAAAAFHRSTlMA8fpqGcLay5+NeWBUPyUSCgU5NzKS4LsAAABnSURBVEjH5dXJDcAwCETRMYm3xI6zuP9a08Q/IJkCnkAgRnqzTaa0h0mVtunTImdUAy0doKUCWk/kLI3EWboCZ6kbZ+kELVXQugNnKfvsq7rcYzePdz+Syz9RXP7V5jOHlsjaLxpk/fkFqxFcxVDMAAAAAElFTkSuQmCC)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .game-cover__later {
        background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAAA+CAMAAAD+kBJTAAAAY1BMVEUAAAD///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////+aRQ2gAAAAIHRSTlMAyQL40Pzzuyfu6OPCtWxpYR0Wq5yShnlUST81LQ0JXB3XCDIAAAD7SURBVGje1dmHlcJAEATRYs/AGbz3nX+UeBBSABQ/Ar2n3ZnpWYAyaP/GBRi1ogOlHR/oRwi6EYLvCMFfhEB4DxPYRwj4jA/Q+YkOwOojNpwMYsPZLDJcjOPCxU5WvbgauYo9NxtVb+Ru+RUPHnrxoGIaDSqKZyKkaqvp2jwZWoIZz9aSrk3NIgrUzWNAgyLN0tAxVHvqHFGIpkle730+y/kTpUfeWSCc5dTZfJyt2jnYOMdA6dDsjBjOQOaMr86w71yNSBdJzrWbc0npXOk6F+DO54Ki6c/v8Pr6HyEQnqwEfNfwyPmcGNeYdQfFeOaBofC7OOm3VDPg0QEvUEibQZcMnwAAAABJRU5ErkJggg==)
      }
    }
    
    .game-cover__later {
      background: -webkit-image-set(url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAfCAMAAACYj8A5AAAAP1BMVEUAAAD///////////////////////////////////////////////////////////////////////////////9Du/pqAAAAFHRSTlMA8fpqGcLay5+NeWBUPyUSCgU5NzKS4LsAAABnSURBVEjH5dXJDcAwCETRMYm3xI6zuP9a08Q/IJkCnkAgRnqzTaa0h0mVtunTImdUAy0doKUCWk/kLI3EWboCZ6kbZ+kELVXQugNnKfvsq7rcYzePdz+Syz9RXP7V5jOHlsjaLxpk/fkFqxFcxVDMAAAAAElFTkSuQmCC) 1x, url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAAA+CAMAAAD+kBJTAAAAY1BMVEUAAAD///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////+aRQ2gAAAAIHRSTlMAyQL40Pzzuyfu6OPCtWxpYR0Wq5yShnlUST81LQ0JXB3XCDIAAAD7SURBVGje1dmHlcJAEATRYs/AGbz3nX+UeBBSABQ/Ar2n3ZnpWYAyaP/GBRi1ogOlHR/oRwi6EYLvCMFfhEB4DxPYRwj4jA/Q+YkOwOojNpwMYsPZLDJcjOPCxU5WvbgauYo9NxtVb+Ru+RUPHnrxoGIaDSqKZyKkaqvp2jwZWoIZz9aSrk3NIgrUzWNAgyLN0tAxVHvqHFGIpkle730+y/kTpUfeWSCc5dTZfJyt2jnYOMdA6dDsjBjOQOaMr86w71yNSBdJzrWbc0npXOk6F+DO54Ki6c/v8Pr6HyEQnqwEfNfwyPmcGNeYdQfFeOaBofC7OOm3VDPg0QEvUEibQZcMnwAAAABJRU5ErkJggg==) 2x);
      background: image-set(url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAfCAMAAACYj8A5AAAAP1BMVEUAAAD///////////////////////////////////////////////////////////////////////////////9Du/pqAAAAFHRSTlMA8fpqGcLay5+NeWBUPyUSCgU5NzKS4LsAAABnSURBVEjH5dXJDcAwCETRMYm3xI6zuP9a08Q/IJkCnkAgRnqzTaa0h0mVtunTImdUAy0doKUCWk/kLI3EWboCZ6kbZ+kELVXQugNnKfvsq7rcYzePdz+Syz9RXP7V5jOHlsjaLxpk/fkFqxFcxVDMAAAAAElFTkSuQmCC) 1x, url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAAA+CAMAAAD+kBJTAAAAY1BMVEUAAAD///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////+aRQ2gAAAAIHRSTlMAyQL40Pzzuyfu6OPCtWxpYR0Wq5yShnlUST81LQ0JXB3XCDIAAAD7SURBVGje1dmHlcJAEATRYs/AGbz3nX+UeBBSABQ/Ar2n3ZnpWYAyaP/GBRi1ogOlHR/oRwi6EYLvCMFfhEB4DxPYRwj4jA/Q+YkOwOojNpwMYsPZLDJcjOPCxU5WvbgauYo9NxtVb+Ru+RUPHnrxoGIaDSqKZyKkaqvp2jwZWoIZz9aSrk3NIgrUzWNAgyLN0tAxVHvqHFGIpkle730+y/kTpUfeWSCc5dTZfJyt2jnYOMdA6dDsjBjOQOaMr86w71yNSBdJzrWbc0npXOk6F+DO54Ki6c/v8Pr6HyEQnqwEfNfwyPmcGNeYdQfFeOaBofC7OOm3VDPg0QEvUEibQZcMnwAAAABJRU5ErkJggg==) 2x);
      color: #3f2652
    }
    
    .game-cover__toner {
      position: absolute;
      top: 0;
      left: 0;
      z-index: 0;
      width: 100%;
      height: 100%;
      border-radius: 7px;
      background: rgba(0, 0, 0, .4)
    }
    
    @-moz-document url-prefix() {
      .game-cover__novelty {
        background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAfCAMAAACYj8A5AAAAOVBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC8dlA9AAAAE3RSTlPLAMHIVTAVBr2brqJ/cGFNQx4Pq2jKPwAAAGVJREFUSMfl1csNwDAIA1AcSv5p0+w/bJfwwVIZ4AkJZBtiuJEmV6PNZZpWTjwLm2jhJlqYRKs0noXTeRbeyrMQzrPwEC0solUSz8LQ3GtJ3jFc8e9Pl8yJKZmrW7OHftG10ZxEfb6iAgejZ9qJAAAAAElFTkSuQmCC)
      }
      .game-cover__later {
        background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAfCAMAAACYj8A5AAAAP1BMVEUAAAD///////////////////////////////////////////////////////////////////////////////9Du/pqAAAAFHRSTlMA8fpqGcLay5+NeWBUPyUSCgU5NzKS4LsAAABnSURBVEjH5dXJDcAwCETRMYm3xI6zuP9a08Q/IJkCnkAgRnqzTaa0h0mVtunTImdUAy0doKUCWk/kLI3EWboCZ6kbZ+kELVXQugNnKfvsq7rcYzePdz+Syz9RXP7V5jOHlsjaLxpk/fkFqxFcxVDMAAAAAElFTkSuQmCC)
      }
    }
    
    @media screen and (max-width:1100px) {
      .game-cover,
      .game-cover__image {
        width: calc((100vw - 20px)/2 - 5px);
        height: calc((100vw - 20px)/2 - 30px)
      }
      .game-cover {
        margin-bottom: 10px
      }
      .game-cover__name {
        background: rgba(0, 0, 0, .3);
        font-size: 14px;
        padding: 7px;
        border-radius: 4px;
        left: 7px;
        bottom: 7px
      }
      .game-cover__later,
      .game-cover__novelty {
        top: 10px;
        background-size: contain;
        width: 51px;
        height: 21px;
        font-size: 9px;
        padding: 5px 0 0 14px
      }
    }
    
    .benefits__wrapper[data-v-2334d768] {
      background-color: rgba(0, 0, 0, .2);
      border-radius: 7px;
      padding: 25px
    }
    
    .benefits__items[data-v-2334d768] {
      display: -webkit-box;
      display: flex
    }
    
    .benefits__item[data-v-2334d768] {
      width: 25%;
      padding-right: 35px
    }
    
    .benefits__text[data-v-2334d768] {
      font-size: 14px;
      line-height: 1.43;
      color: #fff;
      padding-top: 8px
    }
    
    .benefits__dots[data-v-2334d768] {
      display: none
    }
    
    @media screen and (max-width:767px) {
      .benefits[data-v-2334d768] {
        padding: 0 10px
      }
      .benefits__wrapper[data-v-2334d768] {
        padding: 15px
      }
      .benefits__items[data-v-2334d768] {
        overflow: hidden
      }
      .benefits__item[data-v-2334d768] {
        width: 50%;
        display: none;
        padding-right: 25px
      }
      .benefits__item.active[data-v-2334d768] {
        display: block
      }
      .benefits__text[data-v-2334d768] {
        font-size: 12px
      }
      .benefits__dots[data-v-2334d768] {
        display: block;
        margin-top: 15px
      }
    }
    
    .nav_dots[data-v-2d9bc7df] {
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center;
      list-style: none
    }
    
    .nav_dots li[data-v-2d9bc7df] {
      cursor: pointer;
      width: 9px;
      height: 9px;
      background-color: hsla(0, 0%, 100%, .1);
      border-radius: 30px;
      margin-right: 10px
    }
    
    .nav_dots li.active[data-v-2d9bc7df] {
      background-color: #ffed2a
    }
    
    .table__live {
      height: 650px;
      overflow: hidden
    }
    
    @media screen and (max-width:767px) {
      .table__live .th:nth-child(4),
      .table__live .th:nth-child(6),
      .table__live td:first-child span,
      .table__live td:nth-child(4),
      .table__live td:nth-child(6) {
        display: none!important
      }
      .table__live .th:first-child,
      .table__live td:first-child {
        width: 50px
      }
      .table__live td:first-child:after {
        background: none!important
      }
    }
    
    .table__live[data-v-43846d9d] {
      margin-top: 20px
    }
    
    .table[data-v-85f1a3f0] {
      border-radius: 7px
    }
    
    .table__header[data-v-291dc6c8] {
      width: 100%;
      display: table;
      table-layout: fixed;
      padding: 19px 0;
      border-radius: 7px 7px 0 0;
      position: relative;
      z-index: 2
    }
    
    .table__header_black[data-v-291dc6c8] {
      background: #110028
    }
    
    .table__header_blue[data-v-291dc6c8] {
      background-color: #2c134d
    }
    
    .table__header .thead[data-v-291dc6c8] {
      display: table-header-group;
      vertical-align: middle
    }
    
    .table__header .tr[data-v-291dc6c8] {
      display: table-row
    }
    
    .table__header .th[data-v-291dc6c8] {
      display: table-cell;
      color: #a698af;
      font-size: 12px;
      font-weight: 700;
      text-transform: uppercase;
      padding-left: 18px
    }
    
    .table__content[data-v-257303ce],
    .table__wrapper[data-v-257303ce] {
      overflow: hidden
    }
    
    .table__content table[data-v-257303ce] {
      width: 100%;
      table-layout: fixed;
      border-spacing: 0
    }
    
    .table__content .table_black[data-v-257303ce] {
      background: #1e0b38
    }
    
    .table__content .table_blue[data-v-257303ce] {
      background: #321656
    }
    
    .table__content tr[data-v-257303ce] {
      height: 50px
    }
    
    .table__animate[data-v-257303ce] {
      -webkit-animation-fill-mode: forwards;
      animation-fill-mode: forwards;
      -webkit-animation-duration: .8s;
      animation-duration: .8s;
      -webkit-animation-timing-function: linear;
      animation-timing-function: linear;
      will-change: transform
    }
    
    .table__animate[data-v-257303ce]:nth-child(2n) {
      -webkit-animation-name: animate-row-2;
      animation-name: animate-row-2
    }
    
    .table__animate[data-v-257303ce]:nth-child(odd) {
      -webkit-animation-name: animate-row;
      animation-name: animate-row
    }
    
    .table__content td[data-v-257303ce] {
      position: relative;
      font-size: 14px;
      padding-left: 18px;
      color: #a698af;
      overflow: hidden;
      white-space: nowrap
    }
    
    .table__content .table_black td[data-v-257303ce] {
      border-bottom: 1px solid hsla(0, 0%, 100%, .1)
    }
    
    .table__content .table_blue td[data-v-257303ce] {
      border-bottom: 1px solid hsla(0, 0%, 100%, .05)
    }
    
    .table__content td[data-v-257303ce]:after {
      width: 50px;
      height: 50px;
      content: "";
      position: absolute;
      right: 0;
      top: 0
    }
    
    .table__content .table_black td[data-v-257303ce]:after {
      background: -webkit-gradient(linear, left top, right top, from(rgba(50, 22, 86, 0)), color-stop(80%, #1e0b38));
      background: linear-gradient(90deg, rgba(50, 22, 86, 0), #1e0b38 80%)
    }
    
    .table__content .table_blue td[data-v-257303ce]:after {
      background: -webkit-gradient(linear, left top, right top, from(rgba(50, 22, 86, 0)), color-stop(80%, #321656));
      background: linear-gradient(90deg, rgba(50, 22, 86, 0), #321656 80%)
    }
    
    .table__content td img[data-v-257303ce] {
      vertical-align: middle;
      margin-right: 7px
    }
    
    @-webkit-keyframes animate-row {
      0% {
        -webkit-transform: translateY(-50px);
        transform: translateY(-50px)
      }
    }
    
    @keyframes animate-row {
      0% {
        -webkit-transform: translateY(-50px);
        transform: translateY(-50px)
      }
    }
    
    @-webkit-keyframes animate-row-2 {
      0% {
        -webkit-transform: translateY(-50px);
        transform: translateY(-50px)
      }
    }
    
    @keyframes animate-row-2 {
      0% {
        -webkit-transform: translateY(-50px);
        transform: translateY(-50px)
      }
    }
    
    .chat[data-v-5a5ddd64] {
      display: -webkit-box;
      display: flex;
      -webkit-box-orient: vertical;
      -webkit-box-direction: normal;
      flex-direction: column;
      width: 306px;
      background-color: hsla(0, 0%, 100%, 0);
      padding: 0 0 38px;
      position: relative;
      height: 100%;
      overflow: hidden
    }
    
    @media (max-width:1200px) {
      .chat[data-v-5a5ddd64] {
        width: 100%;
        height: 100vh;
        height: calc(var(--vh, 1vh)*100);
        padding: 50px 0 0
      }
    }
    
    .chat-footer[data-v-5a5ddd64],
    .chat-online[data-v-5a5ddd64] {
      display: -webkit-box;
      display: flex
    }
    
    .chat-online[data-v-5a5ddd64] {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      font-size: 12px;
      color: #9e8fa9;
      height: 38px;
      -webkit-box-align: center;
      align-items: center;
      -webkit-box-pack: center;
      justify-content: center
    }
    
    @media (max-width:1200px) {
      .chat-online[data-v-5a5ddd64] {
        top: 0;
        height: 50px;
        bottom: auto;
        background: #301552;
        border-bottom: 1px solid hsla(0, 0%, 100%, .1)
      }
    }
    
    .chat-online[data-v-5a5ddd64]:before {
      content: "";
      width: 10px;
      height: 9px;
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMCIgaGVpZ2h0PSI5IiB2aWV3Qm94PSIwIDAgMTAgOSI+CiAgICA8ZyBmaWxsPSIjQTU5N0FFIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPgogICAgICAgIDxwYXRoIGQ9Ik0zLjgzMyA1aDIuMzM0YTMuMjUgMy4yNSAwIDAgMSAzIDIgMS40NDQgMS40NDQgMCAwIDEtMS4zMzQgMkgyLjE2N0ExLjQ0NCAxLjQ0NCAwIDAgMSAuODMzIDdhMy4yNSAzLjI1IDAgMCAxIDMtMnpNNSA0YzEuMzMzIDAgMi0xLjMzMyAyLTJzMC0yLTItMi0yIDEuMzMzLTIgMiAuNjY3IDIgMiAyeiIvPgogICAgPC9nPgo8L3N2Zz4K) no-repeat 50%;
      background-size: contain;
      margin-right: 3px
    }
    
    .chat-options[data-v-5a5ddd64] {
      -webkit-box-flex: 0;
      flex: none;
      position: relative;
      border-radius: 0 0 7px 7px;
      border: 1px solid hsla(0, 0%, 100%, .1)
    }
    
    @media (max-width:1200px) {
      .chat-options[data-v-5a5ddd64] {
        border: 0;
        border-top: 1px solid hsla(0, 0%, 100%, .1);
        border-radius: 0
      }
    }
    
    #chat-options-input[data-v-5a5ddd64] {
      position: relative
    }
    
    #chat-options-input.disabled[data-v-5a5ddd64] {
      opacity: .5;
      pointer-events: none
    }
    
    .chat-options-input-text[data-v-5a5ddd64] {
      border: 0 solid hsla(0, 0%, 100%, .1);
      background: none;
      font-size: 14px;
      color: #fff;
      width: calc(100% + 20px);
      padding: 11px 60px 0 15px;
      resize: none;
      height: 45px;
      -webkit-transition: height .2s ease-out;
      transition: height .2s ease-out;
      margin-bottom: -3px;
      line-height: 1.65;
      word-wrap: break-word;
      will-change: contents
    }
    
    #chat-options-input[data-v-5a5ddd64] {
      height: 45px
    }
    
    @-moz-document url-prefix() {
      .chat-options-input-text {
        padding-top: 8px
      }
    }
    
    .chat-options-input-text[data-v-5a5ddd64]::-webkit-input-placeholder {
      color: #a698af
    }
    
    .chat-options-input-text[data-v-5a5ddd64]:-ms-input-placeholder,
    .chat-options-input-text[data-v-5a5ddd64]::-moz-placeholder,
    .chat-options-input-text[data-v-5a5ddd64]::-ms-input-placeholder,
    .chat-options-input-text[data-v-5a5ddd64]::-webkit-input-placeholder,
    .chat-options-input-text[data-v-5a5ddd64]::placeholder {
      color: #a698af
    }
    
    .chat-options-input-button[data-v-5a5ddd64] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center;
      -webkit-box-pack: start;
      justify-content: flex-start;
      position: absolute;
      bottom: 0;
      right: 0;
      cursor: pointer;
      padding-right: 8px;
      height: 45px
    }
    
    .chat-options-input-button[data-v-5a5ddd64]:before {
      content: "";
      width: 18px;
      height: 19px;
      background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxOCIgaGVpZ2h0PSIxOSIgdmlld0JveD0iMCAwIDE4IDE5Ij4KICAgIDxwYXRoIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0ibm9uemVybyIgc3Ryb2tlPSIjQTI5NEFDIiBkPSJNMTYuNTI4IDEwLjgxOGExLjUgMS41IDAgMCAwIDAtMi42MzZMMi44NDQuNzQ1YTEuNSAxLjUgMCAwIDAtMi4wMjUgMi4wNWwzLjA3IDUuNDgzYTIuNSAyLjUgMCAwIDEgMCAyLjQ0NGwtMy4wNyA1LjQ4MmExLjUgMS41IDAgMCAwIDIuMDI1IDIuMDUxbDEzLjY4NC03LjQzN3oiLz4KPC9zdmc+Cg==);
      background-repeat: no-repeat;
      background-position: 50%;
      background-size: contain;
      -webkit-transition: all .2s ease-in-out;
      transition: all .2s ease-in-out
    }
    
    .chat-options-input-button[data-v-5a5ddd64]:hover:before {
      background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxOCIgaGVpZ2h0PSIxOSIgdmlld0JveD0iMCAwIDE4IDE5Ij4KICAgIDxwYXRoIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTE2Ljc2NyAxMS4yNTdMMy4wODMgMTguNjk0YTIgMiAwIDAgMS0yLjctMi43MzRsMy4wNy01LjQ4M2EyIDIgMCAwIDAgMC0xLjk1NEwuMzgzIDMuMDRhMiAyIDAgMCAxIDIuNy0yLjczNGwxMy42ODQgNy40MzdhMiAyIDAgMCAxIDAgMy41MTR6Ii8+Cjwvc3ZnPgo=)
    }
    
    .chat-options-input-button[data-v-5a5ddd64]:active:before {
      background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxOCIgaGVpZ2h0PSIxOSIgdmlld0JveD0iMCAwIDE4IDE5Ij4KICAgIDxwYXRoIGZpbGw9IiNGRkVEMkEiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTE2Ljc2NyAxMS4yNTdMMy4wODMgMTguNjk0YTIgMiAwIDAgMS0yLjctMi43MzRsMy4wNy01LjQ4M2EyIDIgMCAwIDAgMC0xLjk1NEwuMzgzIDMuMDRhMiAyIDAgMCAxIDIuNy0yLjczNGwxMy42ODQgNy40MzdhMiAyIDAgMCAxIDAgMy41MTR6Ii8+Cjwvc3ZnPgo=)
    }
    
    @media (max-width:1200px) {
      .chat-options-input-button[data-v-5a5ddd64]:before {
        background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxOCIgaGVpZ2h0PSIxOSIgdmlld0JveD0iMCAwIDE4IDE5Ij4KICAgIDxwYXRoIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0ibm9uemVybyIgc3Ryb2tlPSIjQTI5NEFDIiBkPSJNMTYuNTI4IDEwLjgxOGExLjUgMS41IDAgMCAwIDAtMi42MzZMMi44NDQuNzQ1YTEuNSAxLjUgMCAwIDAtMi4wMjUgMi4wNWwzLjA3IDUuNDgzYTIuNSAyLjUgMCAwIDEgMCAyLjQ0NGwtMy4wNyA1LjQ4MmExLjUgMS41IDAgMCAwIDIuMDI1IDIuMDUxbDEzLjY4NC03LjQzN3oiLz4KPC9zdmc+Cg==)!important
      }
    }
    
    .chat-access[data-v-5a5ddd64] {
      display: none;
      line-height: 1.33;
      font-size: 12px;
      border-radius: 5px;
      color: #fff;
      background: #ff403d;
      position: absolute;
      bottom: 94px;
      left: 10px;
      right: 10px;
      padding: 5px 11px 7px;
      pointer-events: none
    }
    
    @media (max-width:1200px) {
      .chat-access[data-v-5a5ddd64] {
        bottom: 58px
      }
    }
    
    .chat-access.show[data-v-5a5ddd64] {
      display: block;
      -webkit-animation: showSystem-data-v-5a5ddd64 .2s ease-out forwards;
      animation: showSystem-data-v-5a5ddd64 .2s ease-out forwards
    }
    
    .chat-access.hide[data-v-5a5ddd64] {
      display: block;
      -webkit-animation: hideSystem-data-v-5a5ddd64 .2s ease-out forwards;
      animation: hideSystem-data-v-5a5ddd64 .2s ease-out forwards
    }
    
    .chat-messages[data-v-5a5ddd64] {
      -webkit-box-flex: 1;
      flex: auto;
      -webkit-transition: all .3s;
      transition: all .3s;
      min-height: 100px;
      display: -webkit-box;
      display: flex;
      height: 120px;
      -webkit-box-orient: vertical;
      -webkit-box-direction: reverse;
      flex-direction: column-reverse;
      position: relative;
      padding: 0 11px;
      border-radius: 7px 7px 0 0;
      border: 1px solid hsla(0, 0%, 100%, .1);
      border-bottom: 0
    }
    
    @media (max-width:1200px) {
      .chat-messages[data-v-5a5ddd64] {
        border-radius: 0;
        border: 0
      }
    }
    
    .chat-messages-container[data-v-5a5ddd64] {
      position: relative;
      margin-right: -15px;
      padding-right: 15px;
      height: 100%;
      overflow: scroll;
      overflow-anchor: none;
      touch-action: auto
    }
    
    @-webkit-keyframes showSystem-data-v-5a5ddd64 {
      0% {
        opacity: 0
      }
      to {
        opacity: 1
      }
    }
    
    @keyframes showSystem-data-v-5a5ddd64 {
      0% {
        opacity: 0
      }
      to {
        opacity: 1
      }
    }
    
    @-webkit-keyframes hideSystem-data-v-5a5ddd64 {
      0% {
        opacity: 1
      }
      to {
        opacity: 0
      }
    }
    
    @keyframes hideSystem-data-v-5a5ddd64 {
      0% {
        opacity: 1
      }
      to {
        opacity: 0
      }
    }
    
    .chat__close[data-v-5a5ddd64] {
      display: none
    }
    
    @media screen and (max-width:767px) {
      .chat__close[data-v-5a5ddd64] {
        position: absolute;
        right: 16px;
        top: 16px;
        display: block;
        width: 16px;
        height: 16px;
        border-radius: 4px;
        display: -webkit-box;
        display: flex;
        -webkit-box-pack: center;
        justify-content: center;
        -webkit-box-align: center;
        align-items: center;
        cursor: pointer;
        -webkit-transition: all .3s;
        transition: all .3s
      }
      .chat__close svg[data-v-5a5ddd64] {
        width: 17px;
        height: 17px;
        fill: hsla(0, 0%, 100%, .3);
        color: hsla(0, 0%, 100%, .3)
      }
      @media screen and (min-width:720px) {
        .chat__close:hover svg[data-v-5a5ddd64] {
          fill: #fff;
          color: #fff
        }
      }
      .chat__close:active svg[data-v-5a5ddd64] {
        fill: #1d0130;
        color: #1d0130
      }
      .chat__close svg path[data-v-5a5ddd64] {
        fill-opacity: 1
      }
    }
    
    .chat-show-rules[data-v-5a5ddd64] {
      cursor: pointer;
      display: inline-block;
      margin-left: 20px
    }
    
    .footer__wrap[data-v-28d2291f] {
      max-width: 1200px;
      padding: 15px 30px;
      margin: 0 auto
    }
    
    .footer__row[data-v-28d2291f] {
      -webkit-box-pack: justify;
      justify-content: space-between
    }
    
    .footer__row[data-v-28d2291f],
    .footer__sitename[data-v-28d2291f] {
      display: -webkit-box;
      display: flex
    }
    
    .footer__sitename[data-v-28d2291f] {
      font-size: 14px;
      font-weight: 700;
      color: #fff;
      -webkit-box-align: center;
      align-items: center
    }
    
    .footer__adverts[data-v-28d2291f] {
      font-size: 14px;
      line-height: 2.08;
      color: #fff
    }
    
    .footer__adverts a[data-v-28d2291f] {
      font-size: 14px!important
    }
    
    .footer__col[data-v-28d2291f]:last-child {
      display: -webkit-box;
      display: flex;
      padding-top: 5px;
      margin-right: 0
    }
    
    .footer a[data-v-28d2291f] {
      font-size: 12px;
      line-height: 1.33
    }
    
    .footer a[data-v-28d2291f]:active {
      color: #fff
    }
    
    .footer__col a[data-v-28d2291f] {
      margin-right: 30px
    }
    
    .footer__col:last-child a[data-v-28d2291f]:first-child {
      display: inline-block
    }
    
    .footer__button[data-v-28d2291f] {
      width: 32px;
      height: 32px;
      border-radius: 30px;
      background-repeat: no-repeat;
      background-position: 50%;
      margin-right: 10px!important
    }
    
    .vk[data-v-28d2291f] {
      background-image: url(/images/footer/vk_default.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .vk[data-v-28d2291f] {
        background-image: url(/images/footer/vk_default@2x.png)
      }
    }
    
    .vk[data-v-28d2291f] {
      background-image: -webkit-image-set(url("/images/footer/vk_default.png") 1x, url("/images/footer/vk_default@2x.png") 2x);
      background-image: image-set(url("/images/footer/vk_default.png") 1x, url("/images/footer/vk_default@2x.png") 2x);
      --moz-background-image: url(/images/footer/vk_default.png)
    }
    
    .vk[data-v-28d2291f]:active,
    .vk[data-v-28d2291f]:hover {
      background-image: url(/images/footer/vk_active.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .vk[data-v-28d2291f]:active,
      .vk[data-v-28d2291f]:hover {
        background-image: url(/images/footer/vk_active@2x.png)
      }
    }
    
    .vk[data-v-28d2291f]:active,
    .vk[data-v-28d2291f]:hover {
      background-image: -webkit-image-set(url("/images/footer/vk_active.png") 1x, url("/images/footer/vk_active@2x.png") 2x);
      background-image: image-set(url("/images/footer/vk_active.png") 1x, url("/images/footer/vk_active@2x.png") 2x)
    }
    
    .telegram[data-v-28d2291f] {
      background-image: url(/images/footer/telegram_default.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .telegram[data-v-28d2291f] {
        background-image: url(/images/footer/telegram_default@2x.png)
      }
    }
    
    .telegram[data-v-28d2291f] {
      background-image: -webkit-image-set(url("/images/footer/telegram_default.png") 1x, url("/images/footer/telegram_default@2x.png") 2x);
      background-image: image-set(url("/images/footer/telegram_default.png") 1x, url("/images/footer/telegram_default@2x.png") 2x)
    }
    
    .telegram[data-v-28d2291f]:active,
    .telegram[data-v-28d2291f]:hover {
      background-image: url(/images/footer/telegram_active.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .telegram[data-v-28d2291f]:active,
      .telegram[data-v-28d2291f]:hover {
        background-image: url(/images/footer/telegram_active@2x.png)
      }
    }
    
    .telegram[data-v-28d2291f]:active,
    .telegram[data-v-28d2291f]:hover {
      background-image: -webkit-image-set(url("/images/footer/telegram_active.png") 1x, url("/images/footer/telegram_active@2x.png") 2x);
      background-image: image-set(url("/images/footer/telegram_active.png") 1x, url("/images/footer/telegram_active@2x.png") 2x)
    }
    
    @-moz-document url-prefix() {
      .vk {
        background: url(/images/footer/vk_default.png) 50% no-repeat
      }
      .vk:active,
      .vk:hover {
        background: url(/images/footer/vk_active.png) 50% no-repeat
      }
      .telegram {
        background: url(/images/footer/telegram_default.png) 50% no-repeat
      }
      .telegram:active,
      .telegram:hover {
        background: url(/images/footer/telegram_active.png) 50% no-repeat
      }
    }
    
    .footer__button.telegram[data-v-28d2291f]:hover,
    .footer__button.vk[data-v-28d2291f]:hover {
      background-color: #fff
    }
    
    .footer__button.telegram[data-v-28d2291f]:active,
    .footer__button.vk[data-v-28d2291f]:active {
      background-color: #ffed2a
    }
    
    .footer__button.vk[data-v-28d2291f] {
      background-color: #4a76a8
    }
    
    .footer__button.telegram[data-v-28d2291f] {
      background-color: #31a8df
    }
    
    .popup__content[data-v-1ddfe4aa] {
      margin: 35px 0 0;
      padding: 10px 50px;
      text-align: center
    }
    
    .popup__content p[data-v-1ddfe4aa] {
      font-size: 16px;
      line-height: 1.44;
      color: #fff;
      margin-bottom: 21px;
      text-align: center
    }
    
    .popup__content button[data-v-1ddfe4aa] {
      width: 186px
    }
    
    .popup__image[data-v-1ddfe4aa] {
      margin-bottom: 22px;
      text-align: center
    }
    
    .v--modal {
      border: 1px solid hsla(0, 0%, 100%, .1)!important;
      background-color: rgba(41, 26, 67, .85)!important;
      padding: 18px 0 26px!important
    }
    
    @media screen and (max-width:719px) {
      .v--modal {
        padding: 18px 0 20px!important
      }
    }
    
    .v--modal-overlay {
      background: rgba(0, 0, 0, .95)!important
    }
    
    .popup__header[data-v-a21c11a8] {
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: justify;
      justify-content: space-between;
      -webkit-box-align: center;
      align-items: center;
      border-bottom: 1px solid hsla(0, 0%, 100%, .15);
      margin-bottom: 25px;
      padding: 0 22px 21px
    }
    
    @media screen and (max-width:719px) {
      .popup__header[data-v-a21c11a8] {
        padding: 0 10px 16px;
        margin-bottom: 15px
      }
    }
    
    .popup__title[data-v-a21c11a8] {
      font-size: 26px;
      font-weight: 800;
      color: #fff
    }
    
    @media screen and (max-width:719px) {
      .popup__title[data-v-a21c11a8] {
        font-size: 20px
      }
    }
    
    .popup__close[data-v-a21c11a8] {
      width: 16px;
      height: 16px;
      border-radius: 4px;
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center;
      -webkit-box-align: center;
      align-items: center;
      cursor: pointer;
      -webkit-transition: all .3s;
      transition: all .3s
    }
    
    .popup__close svg[data-v-a21c11a8] {
      width: 17px;
      height: 17px;
      fill: hsla(0, 0%, 100%, .3);
      color: hsla(0, 0%, 100%, .3)
    }
    
    @media screen and (min-width:720px) {
      .popup__close:hover svg[data-v-a21c11a8] {
        fill: #fff;
        color: #fff
      }
    }
    
    .popup__close:active svg[data-v-a21c11a8] {
      fill: #1d0130;
      color: #1d0130
    }
    
    .popup__close svg path[data-v-a21c11a8] {
      fill-opacity: 1
    }
    
    .giftcode__form[data-v-2ca6d62e] {
      width: 302px;
      margin: 60px auto 25px
    }
    
    .giftcode__hint[data-v-2ca6d62e] {
      text-align: center;
      max-width: 400px;
      color: #a698af;
      font-size: 12px;
      line-height: 1.55;
      margin: 0 auto 25px
    }
    
    .giftcode__footer[data-v-2ca6d62e] {
      height: 125px;
      position: relative;
      top: 26px;
      background-color: hsla(0, 0%, 100%, .09804)
    }
    
    .giftcide__image[data-v-2ca6d62e] {
      position: absolute;
      z-index: 2;
      left: 20px;
      top: -9px
    }
    
    .giftcode__subscribe[data-v-2ca6d62e] {
      margin-left: 185px
    }
    
    .giftcode__subscribe span[data-v-2ca6d62e] {
      display: inline-block;
      color: #fff;
      font-size: 16px;
      font-weight: 700;
      margin-top: 15px
    }
    
    .giftcode__links[data-v-2ca6d62e] {
      margin-top: 15px
    }
    
    .footer__button[data-v-2ca6d62e] {
      display: inline-block;
      width: 48px;
      height: 48px;
      border-radius: 30px;
      background-repeat: no-repeat;
      background-position: 50%;
      margin-right: 10px!important
    }
    
    @media screen and (max-width:767px) {
      .giftcode__form[data-v-2ca6d62e] {
        width: 100%;
        margin: 30px 0 25px;
        padding: 0 15px
      }
      .giftcide__image[data-v-2ca6d62e] {
        left: 0
      }
      .giftcode__subscribe span[data-v-2ca6d62e] {
        font-size: 12px;
        line-height: normal
      }
      .footer__button[data-v-2ca6d62e] {
        width: 32px;
        height: 32px
      }
    }
    
    .vk[data-v-2ca6d62e] {
      background-image: url(/images/footer/vk_default.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .vk[data-v-2ca6d62e] {
        background-image: url(/images/footer/vk_default@2x.png)
      }
    }
    
    .vk[data-v-2ca6d62e] {
      background-image: -webkit-image-set(url("/images/footer/vk_default.png") 1x, url("/images/footer/vk_default@2x.png") 2x);
      background-image: image-set(url("/images/footer/vk_default.png") 1x, url("/images/footer/vk_default@2x.png") 2x);
      --moz-background-image: url(/images/footer/vk_default.png)
    }
    
    .vk[data-v-2ca6d62e]:active,
    .vk[data-v-2ca6d62e]:hover {
      background-image: url(/images/footer/vk_active.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .vk[data-v-2ca6d62e]:active,
      .vk[data-v-2ca6d62e]:hover {
        background-image: url(/images/footer/vk_active@2x.png)
      }
    }
    
    .vk[data-v-2ca6d62e]:active,
    .vk[data-v-2ca6d62e]:hover {
      background-image: -webkit-image-set(url("/images/footer/vk_active.png") 1x, url("/images/footer/vk_active@2x.png") 2x);
      background-image: image-set(url("/images/footer/vk_active.png") 1x, url("/images/footer/vk_active@2x.png") 2x)
    }
    
    .telegram[data-v-2ca6d62e] {
      background-image: url(/images/footer/telegram_default.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .telegram[data-v-2ca6d62e] {
        background-image: url(/images/footer/telegram_default@2x.png)
      }
    }
    
    .telegram[data-v-2ca6d62e] {
      background-image: -webkit-image-set(url("/images/footer/telegram_default.png") 1x, url("/images/footer/telegram_default@2x.png") 2x);
      background-image: image-set(url("/images/footer/telegram_default.png") 1x, url("/images/footer/telegram_default@2x.png") 2x)
    }
    
    .telegram[data-v-2ca6d62e]:active,
    .telegram[data-v-2ca6d62e]:hover {
      background-image: url(/images/footer/telegram_active.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .telegram[data-v-2ca6d62e]:active,
      .telegram[data-v-2ca6d62e]:hover {
        background-image: url(/images/footer/telegram_active@2x.png)
      }
    }
    
    .telegram[data-v-2ca6d62e]:active,
    .telegram[data-v-2ca6d62e]:hover {
      background-image: -webkit-image-set(url("/images/footer/telegram_active.png") 1x, url("/images/footer/telegram_active@2x.png") 2x);
      background-image: image-set(url("/images/footer/telegram_active.png") 1x, url("/images/footer/telegram_active@2x.png") 2x)
    }
    
    @-moz-document url-prefix() {
      .vk {
        background: url(/images/footer/vk_default.png) 50% no-repeat
      }
      .vk:active,
      .vk:hover {
        background: url(/images/footer/vk_active.png) 50% no-repeat
      }
      .telegram {
        background: url(/images/footer/telegram_default.png) 50% no-repeat
      }
      .telegram:active,
      .telegram:hover {
        background: url(/images/footer/telegram_active.png) 50% no-repeat
      }
    }
    
    .footer__button.telegram[data-v-2ca6d62e]:hover,
    .footer__button.vk[data-v-2ca6d62e]:hover {
      background-color: #fff
    }
    
    .footer__button.telegram[data-v-2ca6d62e]:active,
    .footer__button.vk[data-v-2ca6d62e]:active {
      background-color: #ffed2a
    }
    
    .footer__button.vk[data-v-2ca6d62e] {
      background-color: #4a76a8
    }
    
    .footer__button.telegram[data-v-2ca6d62e] {
      background-color: #31a8df
    }
    
    .content[data-v-0287a918] {
      margin: 35px 0 0;
      padding: 20px
    }
    
    .content[data-v-0287a918],
    p[data-v-0287a918] {
      text-align: center
    }
    
    p[data-v-0287a918] {
      font-size: 16px;
      line-height: 24px;
      margin-top: 5px;
      margin-bottom: 30px
    }
    
    h3[data-v-0287a918],
    p[data-v-0287a918] {
      color: #fff
    }
    
    h3[data-v-0287a918] {
      margin-top: 15px;
      font-size: 20px;
      line-height: 28px
    }
    
    .content img[data-v-0287a918] {
      width: 120px;
      height: 120px
    }
    
    .content button[data-v-0287a918] {
      max-width: 200px
    }
    
    .popup__content[data-v-af6c4662] {
      margin: 35px 0 0;
      padding: 20px
    }
    
    .popup__content p[data-v-af6c4662] {
      font-size: 16px;
      line-height: 1.44;
      color: #fff;
      margin-bottom: 21px;
      text-align: center
    }
    
    .popup__image[data-v-af6c4662] {
      margin-bottom: 22px;
      text-align: center
    }
    
    .chat_mobile__wrapper .v--modal {
      position: relative;
      padding: 0!important
    }
  </style>
  <style data-vue-ssr-id="0e783494:0">
    .v--modal-block-scroll {
      overflow: hidden;
      width: 100vw;
    }
    
    .v--modal-overlay {
      position: fixed;
      box-sizing: border-box;
      left: 0;
      top: 0;
      width: 100%;
      height: 100vh;
      background: rgba(0, 0, 0, 0.2);
      z-index: 999;
      opacity: 1;
    }
    
    .v--modal-overlay.scrollable {
      height: 100%;
      min-height: 100vh;
      overflow-y: auto;
      -webkit-overflow-scrolling: touch;
    }
    
    .v--modal-overlay .v--modal-background-click {
      width: 100%;
      min-height: 100%;
      height: auto;
    }
    
    .v--modal-overlay .v--modal-box {
      position: relative;
      overflow: hidden;
      box-sizing: border-box;
    }
    
    .v--modal-overlay.scrollable .v--modal-box {
      margin-bottom: 2px;
    }
    
    .v--modal {
      background-color: white;
      text-align: left;
      border-radius: 3px;
      box-shadow: 0 20px 60px -2px rgba(27, 33, 58, 0.4);
      padding: 0;
    }
    
    .v--modal.v--modal-fullscreen {
      width: 100vw;
      height: 100vh;
      margin: 0;
      left: 0;
      top: 0;
    }
    
    .v--modal-top-right {
      display: block;
      position: absolute;
      right: 0;
      top: 0;
    }
    
    .overlay-fade-enter-active,
    .overlay-fade-leave-active {
      transition: all 0.2s;
    }
    
    .overlay-fade-enter,
    .overlay-fade-leave-active {
      opacity: 0;
    }
    
    .nice-modal-fade-enter-active,
    .nice-modal-fade-leave-active {
      transition: all 0.4s;
    }
    
    .nice-modal-fade-enter,
    .nice-modal-fade-leave-active {
      opacity: 0;
      transform: translateY(-20px);
    }
  </style>
  <style type="text/css">
    .__nuxt-error-page {
      padding: 1rem;
      background: #f7f8fb;
      color: #47494e;
      text-align: center;
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center;
      -webkit-box-align: center;
      align-items: center;
      -webkit-box-orient: vertical;
      -webkit-box-direction: normal;
      flex-direction: column;
      font-family: sans-serif;
      font-weight: 100!important;
      -ms-text-size-adjust: 100%;
      -webkit-text-size-adjust: 100%;
      -webkit-font-smoothing: antialiased;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0
    }
    
    .__nuxt-error-page .error {
      max-width: 450px
    }
    
    .__nuxt-error-page .title {
      font-size: 1.5rem;
      margin-top: 15px;
      color: #47494e;
      margin-bottom: 8px
    }
    
    .__nuxt-error-page .description {
      color: #7f828b;
      line-height: 21px;
      margin-bottom: 10px
    }
    
    .__nuxt-error-page a {
      color: #7f828b!important;
      text-decoration: none
    }
    
    .__nuxt-error-page .logo {
      position: fixed;
      left: 12px;
      bottom: 12px
    }
  </style>
  <style type="text/css">
    button[data-v-763fb338] {
      cursor: pointer;
      outline: none;
      width: 100%;
      height: 36px;
      color: #fff;
      font-size: 12px;
      font-weight: 700;
      background: transparent;
      border-radius: 5px;
      border: 2px solid hsla(0, 0%, 100%, .2);
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center;
      -webkit-box-pack: center;
      justify-content: center;
      line-height: 18px;
      padding: 0 20px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
    
    button[data-v-763fb338]:hover {
      border: 2px solid #fff
    }
    
    button[data-v-763fb338]:active {
      border: 2px solid #ffed2a
    }
    
    .is__light[data-v-763fb338] {
      border: none;
      background-color: hsla(0, 0%, 100%, .2)
    }
    
    .is__light[data-v-763fb338]:hover {
      border: none;
      color: #3f2652;
      background-color: #fff
    }
    
    .is__light[data-v-763fb338]:active {
      border: none;
      color: #3f2652;
      background-color: #ffed2a
    }
  </style>
  <style type="text/css">
    .login-buttons[data-v-9c33f3e2] {
      display: -webkit-box;
      display: flex
    }
    
    .login-buttons button[data-v-9c33f3e2]:first-child {
      margin-right: 10px
    }
  </style>
  <style type="text/css">
    @media (max-width:1199px) {
      .login-buttons[data-v-9c33f3e2] {
        max-width: 200px
      }
      .login-buttons button[data-v-9c33f3e2] {
        width: auto
      }
    }
  </style>
  <style type="text/css">
    .footer__wrap[data-v-64bbb08d] {
      padding: 15px;
      margin: 0 auto
    }
    
    .footer__row[data-v-64bbb08d] {
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: justify;
      justify-content: space-between
    }
    
    .footer__row[data-v-64bbb08d]:first-child {
      padding-bottom: 10px;
      margin-bottom: 10px;
      border-bottom: 1px solid hsla(0, 0%, 100%, .09804)
    }
    
    .footer__col[data-v-64bbb08d] {
      width: 50%
    }
    
    .footer__sitename[data-v-64bbb08d] {
      font-size: 14px;
      font-weight: 700;
      color: #fff
    }
    
    .footer__adverts[data-v-64bbb08d] {
      font-size: 14px;
      line-height: 2.08;
      color: #fff
    }
    
    .footer__adverts a[data-v-64bbb08d] {
      font-size: 14px!important
    }
    
    .footer__col[data-v-64bbb08d]:last-child {
      padding-top: 5px;
      margin-right: 0
    }
    
    .footer a[data-v-64bbb08d] {
      font-size: 12px;
      line-height: 1.33
    }
    
    .footer a[data-v-64bbb08d]:active {
      color: #fff
    }
    
    .footer__col a[data-v-64bbb08d] {
      margin-right: 30px
    }
    
    .footer__col:last-child a[data-v-64bbb08d]:first-child {
      display: inline-block
    }
    
    .footer__buttons[data-v-64bbb08d] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center
    }
    
    .footer__button[data-v-64bbb08d] {
      width: 32px;
      height: 32px;
      border-radius: 30px;
      background-repeat: no-repeat;
      background-position: 50%;
      margin-right: 10px!important
    }
    
    .vk[data-v-64bbb08d] {
      background-image: url(/images/footer/vk_default.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .vk[data-v-64bbb08d] {
        background-image: url(/images/footer/vk_default@2x.png)
      }
    }
    
    .vk[data-v-64bbb08d] {
      background-image: -webkit-image-set(url("/images/footer/vk_default.png") 1x, url("/images/footer/vk_default@2x.png") 2x);
      background-image: image-set(url("/images/footer/vk_default.png") 1x, url("/images/footer/vk_default@2x.png") 2x)
    }
    
    .vk[data-v-64bbb08d]:active,
    .vk[data-v-64bbb08d]:hover {
      background-image: url(/images/footer/vk_active.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .vk[data-v-64bbb08d]:active,
      .vk[data-v-64bbb08d]:hover {
        background-image: url(/images/footer/vk_active@2x.png)
      }
    }
    
    .vk[data-v-64bbb08d]:active,
    .vk[data-v-64bbb08d]:hover {
      background-image: -webkit-image-set(url("/images/footer/vk_active.png") 1x, url("/images/footer/vk_active@2x.png") 2x);
      background-image: image-set(url("/images/footer/vk_active.png") 1x, url("/images/footer/vk_active@2x.png") 2x)
    }
    
    .telegram[data-v-64bbb08d] {
      background-image: url(/images/footer/telegram_default.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .telegram[data-v-64bbb08d] {
        background-image: url(/images/footer/telegram_default@2x.png)
      }
    }
    
    .telegram[data-v-64bbb08d] {
      background-image: -webkit-image-set(url("/images/footer/telegram_default.png") 1x, url("/images/footer/telegram_default@2x.png") 2x);
      background-image: image-set(url("/images/footer/telegram_default.png") 1x, url("/images/footer/telegram_default@2x.png") 2x)
    }
    
    .telegram[data-v-64bbb08d]:active,
    .telegram[data-v-64bbb08d]:hover {
      background-image: url(/images/footer/telegram_active.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .telegram[data-v-64bbb08d]:active,
      .telegram[data-v-64bbb08d]:hover {
        background-image: url(/images/footer/telegram_active@2x.png)
      }
    }
    
    .telegram[data-v-64bbb08d]:active,
    .telegram[data-v-64bbb08d]:hover {
      background-image: -webkit-image-set(url("/images/footer/telegram_active.png") 1x, url("/images/footer/telegram_active@2x.png") 2x);
      background-image: image-set(url("/images/footer/telegram_active.png") 1x, url("/images/footer/telegram_active@2x.png") 2x)
    }
    
    @-moz-document url-prefix() {
      .vk {
        background: url(/images/footer/vk_default.png) 50% no-repeat
      }
      .vk:active,
      .vk:hover {
        background: url(/images/footer/vk_active.png) 50% no-repeat
      }
      .telegram {
        background: url(/images/footer/telegram_default.png) 50% no-repeat
      }
      .telegram:active,
      .telegram:hover {
        background: url(/images/footer/telegram_active.png) 50% no-repeat
      }
    }
    
    .footer__button.telegram[data-v-64bbb08d]:hover,
    .footer__button.vk[data-v-64bbb08d]:hover {
      background-color: #fff
    }
    
    .footer__button.telegram[data-v-64bbb08d]:active,
    .footer__button.vk[data-v-64bbb08d]:active {
      background-color: #ffed2a
    }
    
    .footer__button.vk[data-v-64bbb08d] {
      background-color: #4a76a8
    }
    
    .footer__button.telegram[data-v-64bbb08d] {
      background-color: #31a8df
    }
  </style>
  <style type="text/css">
    label[data-v-8924fe4c] {
      font-size: 14px;
      font-weight: 700;
      color: #fff;
      margin-bottom: 12px;
      display: block
    }
    
    label small[data-v-8924fe4c] {
      display: block;
      font-size: 58%;
      color: grey;
      margin-top: 10px
    }
    
    span.error[data-v-8924fe4c] {
      display: inline-block;
      min-height: 25px;
      border-radius: 5px;
      background-color: #ff403d;
      -webkit-box-align: center;
      align-items: center;
      font-size: 13px;
      color: #fff;
      margin-top: 10px;
      padding: 5px 10px
    }
    
    .form__item[data-v-8924fe4c]:not(:last-child) {
      margin-bottom: 20px
    }
    
    @media (max-width:767px) {
      .flex__xs[data-v-8924fe4c] {
        display: -webkit-box;
        display: flex;
        -webkit-box-align: center;
        align-items: center;
        -webkit-box-orient: horizontal;
        -webkit-box-direction: normal;
        flex-direction: row;
        -webkit-box-pack: justify;
        justify-content: space-between
      }
      .flex__xs label[data-v-8924fe4c] {
        margin-bottom: 0;
        margin-right: 15px
      }
      label.hidden__xs[data-v-8924fe4c] {
        display: none
      }
      .form__item[data-v-8924fe4c]:not(:last-child) {
        margin-bottom: 15px
      }
    }
  </style>
  <style type="text/css">
    input[data-v-272bb7bf] {
      width: 100%;
      height: 50px;
      padding: 11px 14px;
      border-radius: 7px;
      border: 1px solid transparent;
      background-color: #000;
      outline: none;
      font-size: 18px;
      color: #fff
    }
    
    @media screen and (min-width:720px) {
      input[data-v-272bb7bf]:not(: focus):hover {
        border: 1px solid hsla(0, 0%, 100%, .75)
      }
    }
    
    input[data-v-272bb7bf]:focus {
      box-shadow: 0 0 9px 0 rgba(255, 237, 42, .35);
      border: 1px solid #ffed2a;
      outline: none;
      border-radius: 4px
    }
    
    input.error[data-v-272bb7bf] {
      box-shadow: 0 0 9px 0 rgba(255, 103, 100, .6);
      border: 1px solid #ff403d
    }
  </style>
  <style type="text/css">
    button[data-v-b1f23028] {
      width: 100%;
      height: 50px;
      border-radius: 5px;
      box-shadow: inset 0 -3px 0 0 rgba(0, 0, 0, .24);
      background-image: -webkit-gradient(linear, left top, left bottom, from(#ffed2a), to(#ffdc2a));
      background-image: linear-gradient(#ffed2a, #ffdc2a);
      font-size: 18px;
      font-weight: 700;
      color: #230b36;
      cursor: pointer;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
      border: none;
      outline: none
    }
    
    @media screen and (min-width:720px) {
      button[data-v-b1f23028]:not(: disabled):not(.loading):hover {
        background-image: -webkit-gradient(linear, left top, left bottom, from(#ffcb00), to(#ffaf00));
        background-image: linear-gradient(#ffcb00, #ffaf00)
      }
    }
    
    button[data-v-b1f23028]:not(:disabled):not(.loading):active {
      box-shadow: inset 0 3px 0 0 rgba(0, 0, 0, .24);
      background-image: none;
      background-color: #fb0
    }
    
    .disabled[data-v-b1f23028] {
      background-color: #2f2149;
      box-shadow: none;
      background-image: none;
      color: hsla(0, 0%, 100%, .15)
    }
    
    .loading[data-v-b1f23028] {
      font-size: 0!important;
      background: #fb0;
      box-shadow: none;
      border: none;
      cursor: default
    }
    
    .loading svg[data-v-b1f23028] {
      display: none
    }
    
    .loading[data-v-b1f23028]:after {
      display: inline-block;
      content: "";
      width: 20px;
      height: 20px;
      border-radius: 50%;
      border: 4px solid rgba(42, 22, 58, .2);
      border-top-color: #231230;
      -webkit-animation: loader_animation-data-v-b1f23028 .8s linear infinite;
      animation: loader_animation-data-v-b1f23028 .8s linear infinite
    }
    
    @-webkit-keyframes loader_animation-data-v-b1f23028 {
      0% {
        -webkit-transform: rotate(0deg);
        transform: rotate(0deg)
      }
      to {
        -webkit-transform: rotate(1turn);
        transform: rotate(1turn)
      }
    }
    
    @keyframes loader_animation-data-v-b1f23028 {
      0% {
        -webkit-transform: rotate(0deg);
        transform: rotate(0deg)
      }
      to {
        -webkit-transform: rotate(1turn);
        transform: rotate(1turn)
      }
    }
  </style>
  <style type="text/css">
    @media screen and (max-width:320px) {
      .recaptcha__container iframe[data-v-843d635e] {
        transform: scale(.95);
        -webkit-transform: scale(.95);
        -webkit-transform-origin: 0 0;
        transform-origin: 0 0
      }
    }
  </style>
  <style type="text/css">
    form[data-v-843d635e] {
      padding: 0 100px
    }
    
    @media screen and (max-width:719px) {
      form[data-v-843d635e] {
        padding: 0 15px
      }
    }
    
    .accept-terms[data-v-843d635e] {
      margin-bottom: 20px;
      font-size: 12px;
      color: #fff
    }
    
    .footer[data-v-843d635e] {
      margin-top: 30px;
      border-top: 1px solid hsla(0, 0%, 100%, .15);
      text-align: center
    }
    
    .footer__link[data-v-843d635e] {
      font-size: 14px;
      color: #ffed2a;
      cursor: pointer;
      position: relative;
      top: 13px
    }
    
    @media screen and (max-width:719px) {
      .footer__link[data-v-843d635e] {
        top: 10px
      }
    }
  </style>
  <style type="text/css">
    form[data-v-89df668a] {
      padding: 0 100px
    }
    
    @media screen and (max-width:719px) {
      form[data-v-89df668a] {
        padding: 0 15px
      }
    }
    
    .footer[data-v-89df668a] {
      margin-top: 30px;
      border-top: 1px solid hsla(0, 0%, 100%, .15);
      text-align: center
    }
    
    .footer__link[data-v-89df668a] {
      font-size: 14px;
      color: #ffed2a;
      cursor: pointer;
      position: relative;
      top: 13px
    }
    
    @media screen and (max-width:719px) {
      .footer__link[data-v-89df668a] {
        top: 10px
      }
    }
  </style>
  <style type="text/css">
    .chat-message__user {
      color: #a698af
    }
    
    .chat-message__user_admin:before {
      display: inline-block;
      content: "";
      width: 11px;
      height: 11px;
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMSIgaGVpZ2h0PSIxMiIgdmlld0JveD0iMCAwIDExIDEyIj4KICAgIDxwYXRoIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTYuMDA0IDguNjI4YzAgLjc1MiAwIDEuNTQzLS4wMDQgMi4zNzJoMWwxIDFIM2wxLTFoMVY4LjEzMXYuMjY1Yy0uOCAxLjAxMi0xLjkyMyAxLjI1LTIuOTAxLjk1OEEyLjk0MyAyLjk0MyAwIDAgMSAuMDA5IDYuMjlDLjI0NyAzLjA1NCA1IDMgNS41LjIyMiA2IDMgMTAuODE1IDMuMTE0IDEwLjk5NSA2LjI5MmMuMTU2IDIuNzgzLTMuMTA0IDQuMzgyLTQuOTkxIDIuMDQ5eiIvPgo8L3N2Zz4K) no-repeat 50%;
      margin-right: 4px
    }
    
    .chat-message__text {
      margin-left: 3px;
      word-wrap: break-word
    }
  </style>
  <style type="text/css">
    .chat-message-withdraw__user {
      color: #a698af
    }
  </style>
  <style type="text/css">
    .chat-message-game__number {
      font-size: 12px;
      color: #a698af;
      margin-top: 10px;
      margin-bottom: 10px
    }
    
    .chat-message-game__values {
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: justify;
      justify-content: space-between
    }
    
    .chat-message-game__panel {
      width: 80px;
      padding: 8px 10px;
      background-color: #361c57;
      font-size: 13px;
      color: #fff;
      border-radius: 5px
    }
    
    .chat-message-game__panel span {
      display: block;
      color: #a597af;
      font-size: 12px;
      margin-bottom: 3px
    }
  </style>
  <style type="text/css">
    .chat-rain[data-v-147d5b6e] {
      position: relative;
      padding-top: 30px;
      line-height: 1.29
    }
    
    .chat-rain[data-v-147d5b6e]:before {
      content: "";
      height: 17px;
      position: absolute;
      left: 0;
      right: 0;
      top: 5px;
      background: url(/_nuxt/img/fc3c791.png) space 0;
      background-size: contain
    }
    
    .chat-rain__user[data-v-147d5b6e] {
      color: #a293ac;
      margin-right: 3px
    }
  </style>
  <style type="text/css">
    .chat-rules__header {
      color: #a698af;
      margin-bottom: 5px
    }
    
    .chat-rules__content {
      color: #fff;
      list-style: none;
      padding: 0
    }
    
    .chat-rules__content li {
      line-height: 1.71
    }
    
    .chat-rules__content li:before {
      content: "";
      width: 11px;
      height: 11px;
      display: inline-block;
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMSIgaGVpZ2h0PSIxMiIgdmlld0JveD0iMCAwIDExIDEyIj4KICAgIDxwYXRoIGZpbGw9IiNBNjk4QUYiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTYuMDA0IDguNDA2YzAgLjc1MiAwIDEuNTQzLS4wMDQgMi4zNzJoMWwxIDFIM2wxLTFoMVY3LjkwOXYuMjY1Yy0uOCAxLjAxMi0xLjkyMyAxLjI1LTIuOTAxLjk1OGEyLjk0MyAyLjk0MyAwIDAgMS0yLjA5LTMuMDYzQy4yNDcgMi44MzIgNSAyLjc3OCA1LjUgMCA2IDIuNzc4IDEwLjgxNSAyLjg5MiAxMC45OTUgNi4wNjljLjE1NiAyLjc4NC0zLjEwNCA0LjM4My00Ljk5MSAyLjA1eiIvPgo8L3N2Zz4K) no-repeat 0 0;
      margin-right: 6px
    }
  </style>
  <style type="text/css">
    .chat-message {
      width: 100%;
      padding: 10px 15px 12px;
      margin-bottom: 10px;
      line-height: 1.14;
      border-radius: 5px;
      color: #fff;
      font-size: 14px;
      background-color: hsla(0, 0%, 100%, .03);
      -webkit-transition: background-color .2s ease-in-out;
      transition: background-color .2s ease-in-out
    }
    
    .chat-message_system {
      background-color: #301552
    }
  </style>
  <script type="text/javascript" async="" src="https://www.gstatic.com/recaptcha/releases/TYDIjJAqCk6g335bFk3AjlC3/recaptcha__ru.js"></script>
  <script charset="utf-8" src="/_nuxt/d0770945ebd2c218ac4a.js"></script>
  <script charset="utf-8" src="/_nuxt/fc7b6cdd3110d3f6c98d.js"></script>
  <script charset="utf-8" src="/_nuxt/cba7e5796a540ab7f005.js"></script>
  <style type="text/css">
    .dice-score[data-v-7b3d2471] {
      width: 237px;
      height: 30px;
      margin: 0 auto;
      position: relative
    }
    
    @media (max-width:767px) {
      .dice-score[data-v-7b3d2471] {
        width: calc(100% - 20px)
      }
    }
    
    .dice-score .dice-score-value[data-v-7b3d2471] {
      position: absolute;
      left: 13px;
      display: inline-block;
      width: 211px;
      height: 30px;
      line-height: 27px;
      border-radius: 5px;
      font-size: 12px;
      color: #a698af;
      text-align: center
    }
    
    @media (max-width:767px) {
      .dice-score .dice-score-value[data-v-7b3d2471] {
        width: calc(100% - 26px)
      }
    }
    
    .dice-score .dice-score-value.default[data-v-7b3d2471] {
      border: 1px solid hsla(0, 0%, 100%, .1)
    }
    
    .dice-score .dice-score-value.default[data-v-7b3d2471],
    .dice-score .dice-score-value.win[data-v-7b3d2471] {
      -webkit-transition: border-color .1s ease-out;
      transition: border-color .1s ease-out
    }
    
    .dice-score .dice-score-value.win[data-v-7b3d2471] {
      border: 1px solid rgba(100, 255, 0, .3)
    }
    
    .dice-score .dice-score-value.lose[data-v-7b3d2471] {
      -webkit-transition: border-color .1s ease-out;
      transition: border-color .1s ease-out;
      border: 1px solid rgba(255, 62, 62, .4)
    }
    
    .dice-score .dice-score-value .value[data-v-7b3d2471] {
      font-size: 12px
    }
    
    .svg-corner.default[data-v-7b3d2471] {
      -webkit-transition: all .1s ease-out;
      transition: all .1s ease-out;
      fill: #fff;
      fill-opacity: .1
    }
    
    .svg-corner.win[data-v-7b3d2471] {
      fill: #64ff00;
      fill-opacity: .3
    }
    
    .svg-corner.lose[data-v-7b3d2471],
    .svg-corner.win[data-v-7b3d2471] {
      -webkit-transition: all .1s ease-out;
      transition: all .1s ease-out
    }
    
    .svg-corner.lose[data-v-7b3d2471] {
      fill: #ff3e3e;
      fill-opacity: .3
    }
    
    .dice-score .dice-score-value .value[data-v-7b3d2471] {
      font-weight: 700;
      color: #fff
    }
    
    .dice-score .left-corner[data-v-7b3d2471],
    .dice-score .right-corner[data-v-7b3d2471] {
      display: inline-block;
      width: 24px;
      height: 30px;
      position: absolute;
      top: 6px
    }
    
    .dice-score .left-corner[data-v-7b3d2471] {
      left: 0
    }
    
    .dice-score .right-corner[data-v-7b3d2471] {
      right: 0
    }
  </style>
  <style type="text/css">
    .dice-user-value[data-v-db33fda0] {
      margin-top: 53px;
      font-size: 28px;
      line-height: 1;
      color: #5e516d
    }
    
    @media (max-width:767px) {
      .dice-user-value[data-v-db33fda0] {
        margin-top: 0;
        margin-bottom: 7px;
        font-size: 16px;
        line-height: 1.75;
        text-align: center
      }
    }
    
    .dice-user-value>*[data-v-db33fda0] {
      font-size: 28px;
      line-height: 1;
      color: #5e516d
    }
    
    @media (max-width:767px) {
      .dice-user-value>*[data-v-db33fda0] {
        font-size: 16px;
        line-height: 1.75
      }
    }
  </style>
  <style type="text/css">
    .dice-honeycomb-wrap[data-v-8c199de0]:after,
    .dice-honeycomb-wrap[data-v-8c199de0]:before {
      content: "";
      display: block;
      position: absolute;
      left: 0;
      right: 0;
      z-index: 2
    }
    
    .dice-honeycomb-wrap[data-v-8c199de0]:before {
      top: 0;
      height: 3vw
    }
    
    .dice-honeycomb-wrap[data-v-8c199de0]:after {
      bottom: 0;
      height: 3.8vw
    }
    
    .dice-honeycomb[data-v-8c199de0] {
      height: 105px;
      margin-top: 15px;
      overflow: hidden
    }
    
    @media (max-width:767px) {
      .dice-honeycomb[data-v-8c199de0] {
        width: 100%;
        height: calc(25vw - 12%);
        margin-top: 12%;
        position: relative;
        z-index: 1
      }
    }
    
    .dice-honeycomb-digit[data-v-8c199de0] {
      position: relative;
      font-size: 65px;
      font-weight: 700;
      color: #fff;
      line-height: 100px;
      text-align: center;
      list-style: none
    }
    
    @media (max-width:767px) {
      .dice-honeycomb-digit[data-v-8c199de0] {
        font-size: 10.52632vw;
        line-height: 20.5vw;
        padding-top: 0
      }
    }
    
    @media (max-width:767px) {
      .dice-honeycomb-digits[data-v-8c199de0] {
        margin-top: 0
      }
    }
    
    .odometr-enter-active[data-v-8c199de0] {
      -webkit-transition: -webkit-transform 1s cubic-bezier(.29, .01, .02, .99);
      transition: -webkit-transform 1s cubic-bezier(.29, .01, .02, .99);
      transition: transform 1s cubic-bezier(.29, .01, .02, .99);
      transition: transform 1s cubic-bezier(.29, .01, .02, .99), -webkit-transform 1s cubic-bezier(.29, .01, .02, .99)
    }
    
    .odometr-enter-active.delay-100[data-v-8c199de0] {
      -webkit-transition-delay: .1s;
      transition-delay: .1s
    }
    
    .odometr-enter-active.delay-200[data-v-8c199de0] {
      -webkit-transition-delay: .2s;
      transition-delay: .2s
    }
    
    .odometr-enter-active.delay-300[data-v-8c199de0] {
      -webkit-transition-delay: .3s;
      transition-delay: .3s
    }
    
    .odometr-enter[data-v-8c199de0] {
      -webkit-transform: translateY(0);
      transform: translateY(0)
    }
    
    .odometr-enter-to[data-v-8c199de0] {
      -webkit-transform: translateY(calc(-100% + 93px));
      transform: translateY(calc(-100% + 93px))
    }
    
    .animated[data-v-8c199de0] {
      -webkit-animation: bounce-data-v-8c199de0 .2s ease-in-out;
      animation: bounce-data-v-8c199de0 .2s ease-in-out
    }
    
    @-webkit-keyframes bounce-data-v-8c199de0 {
      0% {
        -webkit-transform: translateY(-7px);
        transform: translateY(-7px)
      }
      20% {
        -webkit-transform: translateY(-7px);
        transform: translateY(-7px)
      }
      40% {
        -webkit-transform: translateY(-6px);
        transform: translateY(-6px)
      }
      60% {
        -webkit-transform: translateY(-3px);
        transform: translateY(-3px)
      }
      80% {
        -webkit-transform: translateY(3px);
        transform: translateY(3px)
      }
      to {
        -webkit-transform: translateY(0);
        transform: translateY(0)
      }
    }
    
    @keyframes bounce-data-v-8c199de0 {
      0% {
        -webkit-transform: translateY(-7px);
        transform: translateY(-7px)
      }
      20% {
        -webkit-transform: translateY(-7px);
        transform: translateY(-7px)
      }
      40% {
        -webkit-transform: translateY(-6px);
        transform: translateY(-6px)
      }
      60% {
        -webkit-transform: translateY(-3px);
        transform: translateY(-3px)
      }
      80% {
        -webkit-transform: translateY(3px);
        transform: translateY(3px)
      }
      to {
        -webkit-transform: translateY(0);
        transform: translateY(0)
      }
    }
    
    @media (max-width:767px) {
      .odometr-enter-to[data-v-8c199de0] {
        -webkit-transform: translateY(calc(-100% + 17.7vw));
        transform: translateY(calc(-100% + 17.7vw))
      }
      @-webkit-keyframes bounce-data-v-8c199de0 {
        0% {
          -webkit-transform: translateY(-2.6vw);
          transform: translateY(-2.6vw)
        }
        20% {
          -webkit-transform: translateY(-2.6vw);
          transform: translateY(-2.6vw)
        }
        40% {
          -webkit-transform: translateY(-2.4vw);
          transform: translateY(-2.4vw)
        }
        60% {
          -webkit-transform: translateY(-1.7vw);
          transform: translateY(-1.7vw)
        }
        80% {
          -webkit-transform: translateY(1vw);
          transform: translateY(1vw)
        }
        to {
          -webkit-transform: translateY(0);
          transform: translateY(0)
        }
      }
      @keyframes bounce-data-v-8c199de0 {
        0% {
          -webkit-transform: translateY(-2.6vw);
          transform: translateY(-2.6vw)
        }
        20% {
          -webkit-transform: translateY(-2.6vw);
          transform: translateY(-2.6vw)
        }
        40% {
          -webkit-transform: translateY(-2.4vw);
          transform: translateY(-2.4vw)
        }
        60% {
          -webkit-transform: translateY(-1.7vw);
          transform: translateY(-1.7vw)
        }
        80% {
          -webkit-transform: translateY(1vw);
          transform: translateY(1vw)
        }
        to {
          -webkit-transform: translateY(0);
          transform: translateY(0)
        }
      }
    }
  </style>
  <style type="text/css">
    .dice-result[data-v-e5ff7d7e] {
      width: 504px;
      position: relative
    }
    
    @media (max-width:767px) {
      .dice-result[data-v-e5ff7d7e] {
        width: 100%
      }
    }
    
    .dice-result img[data-v-e5ff7d7e] {
      width: 100%;
      -webkit-transition: opacity .1s ease-out;
      transition: opacity .1s ease-out;
      display: none;
      opacity: 0
    }
    
    .dice-honeycomb-wrap[data-v-e5ff7d7e] {
      position: relative;
      width: 117px;
      height: 134px;
      margin-right: 12px;
      float: left
    }
    
    @media (max-width:767px) {
      .dice-honeycomb-wrap[data-v-e5ff7d7e] {
        position: relative;
        width: calc((100vw - 29px)/4);
        height: calc((100vw - 29px)/4 + 17px);
        margin-right: 3px;
        float: left
      }
    }
    
    .dice-honeycomb-wrap[data-v-e5ff7d7e]:nth-child(4) {
      margin-right: 0
    }
    
    .dice-dot-img[data-v-e5ff7d7e],
    .dice-honeycomb-img[data-v-e5ff7d7e] {
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      z-index: 10
    }
    
    .dice-result-dot[data-v-e5ff7d7e] {
      width: 20px;
      height: 22px;
      bottom: 7px;
      left: 50%;
      -webkit-transform: translateX(-50%);
      transform: translateX(-50%);
      position: absolute
    }
    
    @media (max-width:767px) {
      .dice-result-dot[data-v-e5ff7d7e] {
        width: 14px;
        height: 15px
      }
    }
    
    .dice-dot-img.default .yellow[data-v-e5ff7d7e],
    .dice-dot-img.lose .red[data-v-e5ff7d7e],
    .dice-dot-img.win .green[data-v-e5ff7d7e],
    .dice-honeycomb-img.default .yellow[data-v-e5ff7d7e],
    .dice-honeycomb-img.lose .red[data-v-e5ff7d7e],
    .dice-honeycomb-img.win .green[data-v-e5ff7d7e] {
      display: block;
      opacity: 1
    }
    
    .clearfix[data-v-e5ff7d7e] {
      clear: both
    }
  </style>
  <style type="text/css">
    .dice-history[data-v-042618ef] {
      width: 53px;
      max-height: 133px;
      padding-top: 8px;
      overflow: hidden;
      position: relative
    }
    
    @media (max-width:767px) {
      .dice-history[data-v-042618ef] {
        width: 100%;
        height: 22px;
        padding-top: 0;
        overflow: visible
      }
    }
    
    .dice-history-list[data-v-042618ef] {
      height: 165px
    }
    
    @media (max-width:767px) {
      .dice-history-list[data-v-042618ef] {
        display: -webkit-box;
        display: flex;
        height: auto
      }
    }
    
    .dice-history-item[data-v-042618ef] {
      display: block;
      height: 22px;
      padding: 3px;
      margin-bottom: 10px;
      text-align: center;
      color: #91ff4a;
      font-size: 12px;
      line-height: 16px;
      border-radius: 11.5px;
      background-color: hsla(0, 0%, 100%, .1)
    }
    
    @media (max-width:767px) {
      .dice-history-item[data-v-042618ef] {
        -webkit-box-flex: 0;
        flex: none;
        display: inline-block;
        width: 14.28571vw;
        margin-bottom: 0;
        margin-right: 3.7037vw
      }
      .dice-history-item[data-v-042618ef]:last-child {
        margin-right: 0
      }
    }
    
    .dice-history-item.lose[data-v-042618ef] {
      color: #ff6764
    }
    
    .dice-history-item[data-v-042618ef]:first-child {
      opacity: 1
    }
    
    .dice-history-item[data-v-042618ef]:nth-child(2) {
      opacity: .7
    }
    
    .dice-history-item[data-v-042618ef]:nth-child(3) {
      opacity: .3
    }
    
    .dice-history-item[data-v-042618ef]:nth-child(4) {
      opacity: .1
    }
    
    .dice-history-item[data-v-042618ef]:nth-child(5) {
      opacity: 0
    }
    
    .list-enter .dice-history-item[data-v-042618ef]:first-child,
    .list-enter .dice-history-item[data-v-042618ef]:nth-child(2) {
      opacity: 1
    }
    
    .list-enter .dice-history-item[data-v-042618ef]:nth-child(3) {
      opacity: .7
    }
    
    .list-enter .dice-history-item[data-v-042618ef]:nth-child(4) {
      opacity: .3
    }
    
    .list-enter .dice-history-item[data-v-042618ef]:nth-child(5) {
      opacity: .1
    }
    
    .list-enter-to .dice-history-item[data-v-042618ef]:first-child {
      opacity: 1
    }
    
    .list-enter-to .dice-history-item[data-v-042618ef]:nth-child(2) {
      opacity: .7
    }
    
    .list-enter-to .dice-history-item[data-v-042618ef]:nth-child(3) {
      opacity: .3
    }
    
    .list-enter-to .dice-history-item[data-v-042618ef]:nth-child(4) {
      opacity: .1
    }
    
    .list-enter-to .dice-history-item[data-v-042618ef]:nth-child(5) {
      opacity: 0
    }
    
    .list-enter-active .dice-history-item[data-v-042618ef] {
      -webkit-transition: opacity .25s ease-out 1.3s;
      transition: opacity .25s ease-out 1.3s
    }
    
    .list-enter-active[data-v-042618ef] {
      -webkit-transition: -webkit-transform .25s ease-out 1.3s;
      transition: -webkit-transform .25s ease-out 1.3s;
      transition: transform .25s ease-out 1.3s;
      transition: transform .25s ease-out 1.3s, -webkit-transform .25s ease-out 1.3s
    }
    
    .list-enter[data-v-042618ef] {
      -webkit-transform: translate3d(0, -32px, 0);
      transform: translate3d(0, -32px, 0)
    }
    
    .list-enter-to[data-v-042618ef] {
      -webkit-transform: translateZ(0);
      transform: translateZ(0)
    }
    
    @media (max-width:767px) {
      .dice-history-item[data-v-042618ef]:first-child {
        opacity: 1
      }
      .dice-history-item[data-v-042618ef]:nth-child(2) {
        opacity: .8
      }
      .dice-history-item[data-v-042618ef]:nth-child(3) {
        opacity: .6
      }
      .dice-history-item[data-v-042618ef]:nth-child(4) {
        opacity: .4
      }
      .dice-history-item[data-v-042618ef]:nth-child(5) {
        opacity: .2
      }
      .dice-history-item[data-v-042618ef]:nth-child(6) {
        opacity: 0
      }
      .list-enter .dice-history-item[data-v-042618ef]:first-child,
      .list-enter .dice-history-item[data-v-042618ef]:nth-child(2) {
        opacity: 1
      }
      .list-enter .dice-history-item[data-v-042618ef]:nth-child(3) {
        opacity: .8
      }
      .list-enter .dice-history-item[data-v-042618ef]:nth-child(4) {
        opacity: .6
      }
      .list-enter .dice-history-item[data-v-042618ef]:nth-child(5) {
        opacity: .4
      }
      .list-enter .dice-history-item[data-v-042618ef]:nth-child(6) {
        opacity: .2
      }
      .list-enter-to .dice-history-item[data-v-042618ef]:first-child {
        opacity: 1
      }
      .list-enter-to .dice-history-item[data-v-042618ef]:nth-child(2) {
        opacity: .8
      }
      .list-enter-to .dice-history-item[data-v-042618ef]:nth-child(3) {
        opacity: .6
      }
      .list-enter-to .dice-history-item[data-v-042618ef]:nth-child(4) {
        opacity: .4
      }
      .list-enter-to .dice-history-item[data-v-042618ef]:nth-child(5) {
        opacity: .2
      }
      .list-enter-to .dice-history-item[data-v-042618ef]:nth-child(6) {
        opacity: .1
      }
      .list-enter[data-v-042618ef] {
        -webkit-transform: translateX(-17.98942vw);
        transform: translateX(-17.98942vw)
      }
      .list-enter-to[data-v-042618ef] {
        -webkit-transform: translateX(0);
        transform: translateX(0)
      }
    }
  </style>
  <style type="text/css">
    .dice-slider[data-v-42a41913] {
      height: 80px;
      border-radius: 5px;
      background-color: rgba(0, 0, 0, .25);
      padding: 12px 19px 0 20px;
      position: relative
    }
    
    @media (max-width:767px) {
      .dice-slider[data-v-42a41913] {
        height: 74px;
        border-radius: 0;
        padding: 9px 10px 0;
        overflow: hidden
      }
    }
    
    .dice-slider .caption[data-v-42a41913] {
      position: relative;
      height: 16px;
      list-style: none
    }
    
    .dice-slider .caption .caption-item[data-v-42a41913] {
      position: absolute;
      font-size: 12px;
      line-height: 16px;
      color: #a698af;
      opacity: .5;
      -webkit-transform: translateX(-50%);
      transform: translateX(-50%)
    }
    
    .dice-slider .caption .caption-item[data-v-42a41913]:first-child {
      -webkit-transform: translateX(0);
      transform: translateX(0)
    }
    
    .dice-slider .caption .caption-item[data-v-42a41913]:last-child {
      -webkit-transform: translateX(-100%);
      transform: translateX(-100%)
    }
    
    .dice-slider .rule-line[data-v-42a41913] {
      position: absolute;
      top: 0;
      width: 2px;
      height: 80px;
      background-color: #50cc00;
      -webkit-transition: all .2s ease-out 1.3s;
      transition: all .2s ease-out 1.3s
    }
    
    @media (max-width:767px) {
      .dice-slider .rule-line[data-v-42a41913] {
        height: 74px
      }
    }
    
    .dice-slider .rule-wrapper[data-v-42a41913] {
      position: relative;
      margin-top: 12px;
      z-index: 5
    }
    
    .dice-slider .rule-wrapper .rule[data-v-42a41913] {
      position: relative;
      width: 100%;
      height: 23px;
      top: -6px;
      white-space: nowrap
    }
    
    .dice-slider .rule-wrapper .rule[data-v-42a41913]:hover {
      cursor: pointer
    }
    
    .dice-slider .rule-wrapper .rule .rule-item[data-v-42a41913] {
      display: inline-block;
      position: relative;
      margin-right: 5px;
      top: 0;
      width: 2px;
      height: 8px;
      background-color: #50cc00
    }
    
    @media (max-width:767px) {
      .dice-slider .rule-wrapper .rule .rule-item[data-v-42a41913] {
        margin-right: 4px
      }
    }
    
    .dice-slider .rule-wrapper .rule .rule-item[data-v-42a41913]:last-child {
      margin-right: 0
    }
    
    .runner-touch-wrap[data-v-42a41913] {
      width: 28px;
      height: 48px;
      position: absolute;
      top: -40px;
      -webkit-transform: translateX(-50%);
      transform: translateX(-50%);
      z-index: 1
    }
    
    .dice-slider .rule-wrapper .runner[data-v-42a41913] {
      position: absolute;
      bottom: 0;
      width: 28px;
      height: 28px;
      line-height: 28px;
      font-size: 12px;
      border-radius: 100%;
      color: #291944;
      text-align: center;
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSI4IiB2aWV3Qm94PSIwIDAgMjAgOCI+CiAgICA8ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIHN0cm9rZT0iIzFGMTQzMyI+CiAgICAgICAgPHBhdGggZD0iTTUgMEwxIDRsNCA0TTE1IDBsNCA0LTQgNCIvPgogICAgPC9nPgo8L3N2Zz4K) no-repeat #fff;
      background-position: 4px 10px;
      z-index: 10
    }
    
    @media (min-width:767px) {
      .dice-slider .rule-wrapper .runner[data-v-42a41913]:hover {
        background-color: #ffef00;
        cursor: pointer
      }
    }
    
    .dice-slider .rule-wrapper .runner.dragged[data-v-42a41913] {
      background-color: #ffef00;
      cursor: pointer;
      background-image: none
    }
    
    .dice-slider .rule-wrapper .runner-pad[data-v-42a41913] {
      position: absolute;
      top: -120px;
      bottom: -100px;
      left: -56px;
      right: -55px;
      z-index: 15
    }
    
    .fade-leave-active[data-v-42a41913],
    .line-fade-enter-active[data-v-42a41913] {
      -webkit-transition: opacity .2s ease-out 1.3s;
      transition: opacity .2s ease-out 1.3s
    }
    
    .line-fade-enter[data-v-42a41913] {
      opacity: 0
    }
    
    .line-fade-enter-to[data-v-42a41913] {
      opacity: 1
    }
  </style>
  <style type="text/css">
    .dice-reverse[data-v-db5ba99e] {
      width: 34px;
      height: 34px;
      border: 5px solid #291a43;
      border-radius: 100%;
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxOCIgaGVpZ2h0PSIxOCIgdmlld0JveD0iMCAwIDE4IDE4Ij4KICAgIDxwYXRoIGZpbGw9IiNCMEFBQjMiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTYuOTcgOUw4IDkuNzc3IDYuMTE0IDEySDEzdjFINi4xMTRMOCAxNS4yMjMgNi45NyAxNiA0IDEyLjUgNi45NyA5em00LjA2LTdMMTQgNS41IDExLjAzIDkgMTAgOC4yMjMgMTEuODg1IDZINVY1aDYuODg1TDEwIDIuNzc3IDExLjAzIDJ6Ii8+Cjwvc3ZnPgo=) no-repeat #3e3156;
      background-position: 3px 3px
    }
    
    @media (min-width:767px) {
      .dice-reverse[data-v-db5ba99e]:hover {
        cursor: pointer;
        background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxOCIgaGVpZ2h0PSIxOCIgdmlld0JveD0iMCAwIDE4IDE4Ij4KICAgIDxwYXRoIGZpbGw9IiMyRjIxNDkiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTYuOTcgOUw4IDkuNzc3IDYuMTE0IDEySDEzdjFINi4xMTRMOCAxNS4yMjMgNi45NyAxNiA0IDEyLjUgNi45NyA5em00LjA2LTdMMTQgNS41IDExLjAzIDkgMTAgOC4yMjMgMTEuODg1IDZINVY1aDYuODg1TDEwIDIuNzc3IDExLjAzIDJ6Ii8+Cjwvc3ZnPgo=) no-repeat #fff;
        background-position: 3px 3px
      }
    }
    
    .dice-reverse.clicked[data-v-db5ba99e] {
      cursor: pointer;
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxOCIgaGVpZ2h0PSIxOCIgdmlld0JveD0iMCAwIDE4IDE4Ij4KICAgIDxwYXRoIGZpbGw9IiMyRjIxNDkiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTYuOTcgOUw4IDkuNzc3IDYuMTE0IDEySDEzdjFINi4xMTRMOCAxNS4yMjMgNi45NyAxNiA0IDEyLjUgNi45NyA5em00LjA2LTdMMTQgNS41IDExLjAzIDkgMTAgOC4yMjMgMTEuODg1IDZINVY1aDYuODg1TDEwIDIuNzc3IDExLjAzIDJ6Ii8+Cjwvc3ZnPgo=) no-repeat #ffed2a;
      background-position: 3px 3px
    }
  </style>
  <style type="text/css">
    .form__input_icon[data-v-65dd4ae2] {
      display: -webkit-box;
      display: flex;
      flex-wrap: wrap;
      -webkit-box-align: center;
      align-items: center;
      position: relative
    }
    
    .form__input_icon input[data-v-65dd4ae2] {
      padding-right: 34px
    }
    
    .form__icon[data-v-65dd4ae2] {
      width: 24px;
      height: 24px;
      position: absolute;
      top: 13px;
      right: 10px;
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center;
      -webkit-box-align: center;
      align-items: center;
      background: #1a1a1a;
      border-radius: 30px;
      color: #7a6e7f;
      font-size: 18px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
    
    .form__icon svg[data-v-65dd4ae2] {
      width: 13px;
      fill: #7a6e7f;
      color: #7a6e7f
    }
  </style>
  <style type="text/css">
    .bet__container[data-v-57c9556b] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center
    }
    
    .bet__input[data-v-57c9556b] {
      width: 100%
    }
    
    @media (max-width:767px) {
      .bet__input[data-v-57c9556b] {
        width: calc(100% - 105px)
      }
    }
    
    .bet__controls[data-v-57c9556b] {
      margin-left: 10px
    }
    
    .bet__controls .row[data-v-57c9556b] {
      display: -webkit-box;
      display: flex
    }
    
    .bet__controls .row[data-v-57c9556b]:first-child {
      margin-bottom: 6px
    }
    
    .bet__btn[data-v-57c9556b] {
      display: inline-block;
      width: 45px;
      line-height: 22px;
      border-radius: 11px;
      background-color: hsla(0, 0%, 100%, .1);
      border: none;
      font-size: 12px;
      text-align: center;
      color: #a698af;
      cursor: pointer;
      outline: none;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
    
    .bet__btn[data-v-57c9556b]:hover {
      background-color: hsla(0, 0%, 100%, .25);
      color: #fff
    }
    
    .bet__btn[data-v-57c9556b]:active {
      background-color: #ffed2a;
      color: #3f2652
    }
    
    .bet__btn[data-v-57c9556b]:first-child {
      margin-right: 5px
    }
  </style>
  <style type="text/css">
    .form__input_icon[data-v-3ae7472f] {
      display: -webkit-box;
      display: flex;
      flex-wrap: wrap;
      -webkit-box-align: center;
      align-items: center;
      position: relative
    }
    
    .form__input_icon input[data-v-3ae7472f] {
      padding-right: 34px
    }
    
    .form__icon[data-v-3ae7472f] {
      width: 24px;
      height: 24px;
      position: absolute;
      top: 13px;
      right: 10px;
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center;
      -webkit-box-align: center;
      align-items: center;
      background: #1a1a1a;
      border-radius: 30px;
      color: #7a6e7f;
      font-size: 18px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
  </style>
  <style type="text/css">
    .dice__form[data-v-544c8958] {
      display: -webkit-box;
      display: flex;
      justify-content: space-around;
      -webkit-box-align: end;
      align-items: flex-end
    }
    
    .dice__form__item[data-v-544c8958] {
      width: 128px;
      margin-right: 20px
    }
    
    .dice__form__item[data-v-544c8958]:last-child {
      margin-right: 0
    }
    
    .dice__form__bet[data-v-544c8958] {
      width: 285px
    }
    
    .dice__form__submit[data-v-544c8958] {
      width: 135px
    }
  </style>
  <style type="text/css">
    @media screen and (max-width:1199px) {
      .dice__form[data-v-544c8958] {
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        flex-direction: column
      }
      .dice__form__item[data-v-544c8958] {
        width: 100%;
        margin-right: 0;
        margin-bottom: 20px;
        -webkit-box-ordinal-group: 4;
        order: 3
      }
      .dice__form__item.dice__form__submit[data-v-544c8958] {
        -webkit-box-ordinal-group: 2;
        order: 1
      }
      .dice__form__item.dice__form__bet[data-v-544c8958] {
        -webkit-box-ordinal-group: 3;
        order: 2
      }
      .dice__form__bet label[data-v-544c8958] {
        display: none
      }
    }
  </style>
  <style type="text/css">
    .dice-game[data-v-090c8aae] {
      max-width: 813px;
      padding: 18px 35px 35px;
      background-color: #291a43;
      border: 1px solid #000;
      border-radius: 7px;
      font-family: Source Sans Pro, sans-serif;
      font-weight: 400;
      font-stretch: normal;
      font-style: normal;
      letter-spacing: normal
    }
    
    .dice-game-bottom[data-v-090c8aae],
    .dice-game-top[data-v-090c8aae] {
      -webkit-box-flex: 0;
      flex: none
    }
    
    .dice-score-wrapper[data-v-090c8aae] {
      margin-bottom: 29px
    }
    
    @media (max-width:767px) {
      .dice-score-wrapper[data-v-090c8aae] {
        margin-bottom: 16px
      }
    }
    
    .dice-result-block[data-v-090c8aae] {
      margin-bottom: 45px
    }
    
    @media (max-width:767px) {
      .dice-result-block[data-v-090c8aae] {
        margin-bottom: 18px
      }
    }
    
    .dice-game-wrapper[data-v-090c8aae] {
      display: inline-block;
      white-space: normal;
      vertical-align: middle;
      text-align: left
    }
    
    @media (max-width:767px) {
      .dice-game[data-v-090c8aae],
      .dice-game-wrapper[data-v-090c8aae] {
        width: 100%;
        height: 100%
      }
      .dice-game[data-v-090c8aae] {
        display: -webkit-box;
        display: flex;
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        flex-direction: column;
        -webkit-box-pack: center;
        justify-content: center;
        padding: 15px 0 20px;
        border: 0;
        border-radius: 0;
        position: relative
      }
    }
    
    .dice-result-wrapper[data-v-090c8aae] {
      width: 504px;
      float: left
    }
    
    @media (max-width:767px) {
      .dice-result-wrapper[data-v-090c8aae] {
        width: 100%;
        padding: 0 9px 64px 10px;
        float: none
      }
    }
    
    .dice-game-center[data-v-090c8aae] {
      position: relative
    }
    
    .dice-user-value-wrapper[data-v-090c8aae] {
      width: 121px;
      float: left
    }
    
    @media (max-width:767px) {
      .dice-user-value-wrapper[data-v-090c8aae] {
        width: 100%
      }
    }
    
    .dice-history-wrapper[data-v-090c8aae] {
      width: 53px;
      float: right;
      margin-left: 63px
    }
    
    @media (max-width:767px) {
      .dice-history-wrapper[data-v-090c8aae] {
        width: calc(100% - 40px);
        float: none;
        padding-left: 10px;
        position: absolute;
        top: calc(100% - 37px);
        left: 0;
        overflow: hidden;
        margin-left: 0
      }
    }
    
    .dice-history-wrapper .dice-reverse-wrapper[data-v-090c8aae] {
      display: none
    }
    
    .dice-slider-wrapper[data-v-090c8aae] {
      position: relative;
      margin-bottom: 44px
    }
    
    @media (max-width:767px) {
      .dice-slider-wrapper[data-v-090c8aae] {
        margin-bottom: 15px
      }
    }
    
    .dice-slider-wrapper .dice-reverse-wrapper[data-v-090c8aae] {
      width: 34px;
      height: 34px;
      position: absolute;
      left: 50%;
      bottom: 0;
      -webkit-transform: translate(-50%, 50%);
      transform: translate(-50%, 50%)
    }
    
    @media (max-width:767px) {
      .dice-slider-wrapper .dice-reverse-wrapper[data-v-090c8aae] {
        left: auto;
        right: -11px;
        bottom: calc(100% + 26px)
      }
    }
    
    @media (max-width:767px) {
      .dice-play-button-wrapper[data-v-090c8aae] {
        padding: 0 10px
      }
    }
    
    .clearfix[data-v-090c8aae] {
      clear: both
    }
  </style>
  <style type="text/css">
    .wrapper[data-v-170b8266] {
      display: -webkit-box;
      display: flex
    }
    
    .left[data-v-170b8266] {
      width: 814px
    }
    
    .right[data-v-170b8266] {
      width: 306px;
      margin-left: 20px;
      height: calc(100vh - 71px)
    }
    
    @media screen and (max-width:767px) {
      .wrapper[data-v-170b8266] {
        display: block
      }
      .left[data-v-170b8266] {
        width: 100%
      }
      .right[data-v-170b8266] {
        display: none
      }
    }
  </style>
  <script charset="utf-8" src="/_nuxt/a74af29395c72082fb38.js"></script>
  <style type="text/css">
    .ribbon[data-v-87672964] {
      box-sizing: border-box;
      font-size: 20px;
      font-weight: 700;
      letter-spacing: 1.05px;
      color: #3f2652;
      text-transform: uppercase;
      text-align: center;
      line-height: 50px;
      border-radius: 4px;
      position: relative
    }
    
    .ribbon[data-v-87672964]:after,
    .ribbon[data-v-87672964]:before {
      content: "";
      display: inline-block;
      width: 30px;
      height: 50px;
      position: absolute;
      top: 5px;
      z-index: 0
    }
    
    .ribbon[data-v-87672964]:before {
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyOSIgaGVpZ2h0PSI1MCIgdmlld0JveD0iMCAwIDI5IDUwIj4KICAgIDxwYXRoIGZpbGw9IiNGRkNGMDUiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTIuNjU1IDBIMjVhNCA0IDAgMCAxIDQgNHY0MmE0IDQgMCAwIDEtNCA0SDIuNjU1QTIgMiAwIDAgMSAuOTcgNDYuOTIyTDE1IDI1IC45NyAzLjA3OEEyIDIgMCAwIDEgMi42NTUgMHoiLz4KPC9zdmc+Cg==) no-repeat;
      left: -20px
    }
    
    .ribbon[data-v-87672964]:after {
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyOSIgaGVpZ2h0PSI1MCIgdmlld0JveD0iMCAwIDI5IDUwIj4KICAgIDxwYXRoIGZpbGw9IiNGRkNGMDUiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTI2LjM0NSAwSDRhNCA0IDAgMCAwLTQgNHY0MmE0IDQgMCAwIDAgNCA0aDIyLjM0NWEyIDIgMCAwIDAgMS42ODUtMy4wNzhMMTQgMjUgMjguMDMgMy4wNzhBMiAyIDAgMCAwIDI2LjM0NSAweiIvPgo8L3N2Zz4K) no-repeat;
      right: -20px
    }
    
    .ribbon__text[data-v-87672964] {
      position: relative;
      z-index: 1;
      display: block;
      width: 100%;
      height: 100%;
      background-color: #ffed2a;
      border-radius: 4px
    }
    
    @media (max-width:767px) {
      .ribbon[data-v-87672964] {
        margin: 0 auto 29px;
        width: calc(100% - 60px);
        font-size: 14px;
        letter-spacing: .74px;
        line-height: 40px
      }
      .ribbon[data-v-87672964]:after,
      .ribbon[data-v-87672964]:before {
        height: 40px;
        width: 28px
      }
      .ribbon[data-v-87672964]:before {
        background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNiIgaGVpZ2h0PSI0MCIgdmlld0JveD0iMCAwIDI2IDQwIj4KICAgIDxwYXRoIGZpbGw9IiNGRkNGMDUiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTIuMDQzIDBIMjJhNCA0IDAgMCAxIDQgNHYzMmE0IDQgMCAwIDEtNCA0SDIuMDQzYTIgMiAwIDAgMS0xLjU5LTMuMjE0TDEzLjI2NyAyMCAuNDUzIDMuMjE0QTIgMiAwIDAgMSAyLjA0MyAweiIvPgo8L3N2Zz4K) no-repeat;
        left: -22px
      }
      .ribbon[data-v-87672964]:after {
        background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNiIgaGVpZ2h0PSI0MCIgdmlld0JveD0iMCAwIDI2IDQwIj4KICAgIDxwYXRoIGZpbGw9IiNGRkNGMDUiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTIzLjQwNyAwSDRhNCA0IDAgMCAwLTQgNHYzMmE0IDQgMCAwIDAgNCA0aDE5LjQwN2EyIDIgMCAwIDAgMS43LTMuMDU0TDE0LjYgMjAgMjUuMTA3IDMuMDU0QTIgMiAwIDAgMCAyMy40MDcgMHoiLz4KPC9zdmc+Cg==) no-repeat;
        right: -22px
      }
    }
  </style>
  <style type="text/css">
    .faucet__form[data-v-9354549c] {
      width: 304px;
      margin: auto
    }
    
    @media (max-width:767px) {
      .faucet__form[data-v-9354549c] {
        width: calc(100% - 60px)
      }
    }
    
    .recaptcha[data-v-9354549c] {
      margin-top: 45px;
      margin-bottom: 25px
    }
    
    @media screen and (max-width:320px) {
      .recaptcha__container iframe[data-v-9354549c] {
        transform: scale(.95);
        -webkit-transform: scale(.95);
        -webkit-transform-origin: 0 0;
        transform-origin: 0 0
      }
    }
    
    .balance-info[data-v-9354549c] {
      background-color: hsla(0, 0%, 100%, .1);
      border-radius: 5px;
      font-size: 14px;
      line-height: 1.43;
      text-align: center;
      color: #a698af;
      padding: 10px 30px;
      margin-top: 50px;
      margin-bottom: 20px
    }
  </style>
  <style type="text/css">
    .cell[data-v-7619dbb8] {
      position: relative;
      width: 33.3%;
      height: 33.3%;
      outline: none;
      -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
      -moz-tap-highlight-color: transparent
    }
    
    .round[data-v-7619dbb8] {
      position: absolute;
      top: 10%;
      left: 10%;
      width: 80%;
      height: 80%;
      border-radius: 44.5px;
      box-shadow: inset 0 0 23px 0 hsla(0, 0%, 100%, .17), inset 0 -3px 0 0 #3e2f56;
      background-color: #463958;
      -webkit-transition: box-shadow .1s, background-color .1s, -webkit-transform .1s;
      transition: box-shadow .1s, background-color .1s, -webkit-transform .1s;
      transition: box-shadow .1s, background-color .1s, transform .1s;
      transition: box-shadow .1s, background-color .1s, transform .1s, -webkit-transform .1s;
      will-change: transform
    }
    
    .round.is__loading[data-v-7619dbb8] {
      background: #7f7193 url(/images/mines/loader.svg) 50% no-repeat;
      background-size: 150px;
      box-shadow: inset 0 0 23px 0 hsla(0, 0%, 100%, .47), inset 0 -3px 0 0 #857995
    }
    
    .round-leave-active[data-v-7619dbb8] {
      position: relative;
      z-index: 3;
      -webkit-animation: round-data-v-7619dbb8 .25s ease-out;
      animation: round-data-v-7619dbb8 .25s ease-out
    }
    
    @media(min-width:768px) {
      .cell:not(.is__opened) .round[data-v-7619dbb8]:hover {
        box-shadow: inset 0 0 23px 0 hsla(0, 0%, 100%, .47), inset 0 -3px 0 0 #857995;
        background-color: #7f7193;
        cursor: pointer
      }
    }
    
    .icon[data-v-7619dbb8] {
      position: absolute;
      top: 10%;
      left: 10%;
      width: 80%;
      height: 80%;
      z-index: 2;
      background-repeat: no-repeat;
      background-position: 50%;
      will-change: transform
    }
    
    @media(max-width:767px) {
      .icon[data-v-7619dbb8],
      .round[data-v-7619dbb8] {
        top: 5%;
        left: 5%;
        width: 90%;
        height: 90%
      }
    }
    
    .is__opacity .icon[data-v-7619dbb8] {
      opacity: .3
    }
    
    .icon-enter-active[data-v-7619dbb8] {
      -webkit-animation: object-data-v-7619dbb8 .25s ease-in-out forwards;
      animation: object-data-v-7619dbb8 .25s ease-in-out forwards;
      -webkit-animation-delay: .1s;
      animation-delay: .1s
    }
    
    @-webkit-keyframes round-data-v-7619dbb8 {
      0% {
        -webkit-transform: scale(1);
        transform: scale(1)
      }
      50% {
        -webkit-transform: scale(1.1);
        transform: scale(1.1)
      }
      to {
        -webkit-transform: scale(0);
        transform: scale(0)
      }
    }
    
    @keyframes round-data-v-7619dbb8 {
      0% {
        -webkit-transform: scale(1);
        transform: scale(1)
      }
      50% {
        -webkit-transform: scale(1.1);
        transform: scale(1.1)
      }
      to {
        -webkit-transform: scale(0);
        transform: scale(0)
      }
    }
    
    @-webkit-keyframes object-data-v-7619dbb8 {
      0% {
        -webkit-transform: scale(.2);
        transform: scale(.2)
      }
      to {
        -webkit-transform: scale(1);
        transform: scale(1)
      }
    }
    
    @keyframes object-data-v-7619dbb8 {
      0% {
        -webkit-transform: scale(.2);
        transform: scale(.2)
      }
      to {
        -webkit-transform: scale(1);
        transform: scale(1)
      }
    }
  </style>
  <style type="text/css">
    .field[data-v-8ad8d56a] {
      display: -webkit-box;
      display: flex;
      margin: 0 auto;
      flex-wrap: wrap;
      justify-content: space-around;
      width: 230px;
      height: 230px;
      padding: 10px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
  </style>
  <style type="text/css">
    .wrapper[data-v-37389b4b] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center;
      width: 100%;
      min-height: 500px;
      background-color: #291a43;
      border-radius: 7px;
      border: 1px solid #000
    }
    
    .content[data-v-37389b4b] {
      margin: 0 auto;
      background-color: #180d2c;
      width: 378px;
      min-height: 320px;
      border-radius: 10px;
      padding: 25px 0;
      border: none
    }
    
    @media (min-width:768px) {
      .ribbon[data-v-37389b4b] {
        width: 414px;
        margin-left: -18px
      }
    }
    
    @media (max-width:767px) {
      .content[data-v-37389b4b] {
        width: calc(100% - 20px)
      }
    }
  </style>
  <script charset="utf-8" src="/_nuxt/be10ccc7e0b462932ad0.js"></script>
  <script charset="utf-8" src="/_nuxt/85b8b9a174ead9933c44.js"></script>
  <style type="text/css">
    .tabs {
      list-style: none;
      color: #a698af;
      font-size: 25px;
      line-height: 81px;
      display: -webkit-box;
      display: flex;
      cursor: pointer
    }
    
    .tabs li {
      margin-right: 35px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
      -webkit-transition: color .5s ease;
      transition: color .5s ease
    }
    
    .tabs li.active {
      color: #fff;
      border-bottom: 4px solid #ffed2a
    }
    
    @media (max-width:767px) {
      .tabs {
        font-size: 20px;
        line-height: 61px;
        padding-left: 10px
      }
      .tabs li {
        margin-right: 25px
      }
    }
  </style>
  <style type="text/css">
    .input__container[data-v-a93b1494] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center
    }
    
    .input__input[data-v-a93b1494] {
      width: 100%
    }
    
    @media (max-width:767px) {
      .input__input[data-v-a93b1494] {
        width: calc(100% - 105px)
      }
    }
    
    .input__controls[data-v-a93b1494] {
      margin-left: 10px
    }
    
    .input__controls .row[data-v-a93b1494] {
      display: -webkit-box;
      display: flex
    }
    
    .input__controls .row[data-v-a93b1494]:first-child {
      margin-bottom: 6px
    }
    
    .input__btn[data-v-a93b1494] {
      display: inline-block;
      width: 45px;
      line-height: 22px;
      border-radius: 11px;
      background-color: hsla(0, 0%, 100%, .1);
      border: none;
      font-size: 12px;
      text-align: center;
      color: #a698af;
      cursor: pointer;
      outline: none;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
    
    .input__btn[data-v-a93b1494]:hover {
      background-color: hsla(0, 0%, 100%, .25);
      color: #fff
    }
    
    .input__btn[data-v-a93b1494]:active {
      background-color: #ffed2a;
      color: #3f2652
    }
    
    .input__btn[data-v-a93b1494]:first-child {
      margin-right: 5px
    }
  </style>
  <style type="text/css">
    .deposit-form[data-v-5916d354] {
      display: -webkit-box;
      display: flex;
      margin: 0 auto;
      width: 600px;
      border-radius: 7px;
      box-shadow: 0 15px 35px 0 rgba(0, 0, 0, .2549);
      background-color: hsla(0, 0%, 100%, .09804)
    }
    
    .deposit-form__form[data-v-5916d354] {
      width: 340px;
      padding: 25px 35px 35px
    }
    
    .deposit-form__fee[data-v-5916d354] {
      margin-top: 10px;
      padding: 6px;
      font-size: 12px;
      border-radius: 7px;
      background-color: #33254c;
      text-align: center;
      color: #a698af
    }
    
    .deposit-form__fee span[data-v-5916d354] {
      color: #ffed2a
    }
    
    .deposit-form__info[data-v-5916d354] {
      width: 260px;
      padding: 0 25px;
      border-radius: 0 7px 7px 0;
      background-color: #33254c;
      color: #a698af;
      font-size: 14px
    }
    
    .deposit-form__info ul[data-v-5916d354] {
      margin-top: 25px;
      list-style: none
    }
    
    .deposit-form__info li[data-v-5916d354] {
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMSIgaGVpZ2h0PSIxMiIgdmlld0JveD0iMCAwIDExIDEyIj4KICAgIDxwYXRoIGZpbGw9IiM4NTc3OTMiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTYuMDA0IDguNjI4YzAgLjc1MiAwIDEuNTQzLS4wMDQgMi4zNzJoMWwxIDFIM2wxLTFoMVY4LjM5NmMtLjggMS4wMTItMS45MjMgMS4yNS0yLjkwMS45NThBMi45NDMgMi45NDMgMCAwIDEgLjAwOSA2LjI5Qy4yNDcgMy4wNTQgNSAzIDUuNS4yMjIgNiAzIDEwLjgxNSAzLjExNCAxMC45OTUgNi4yOTJjLjE1NiAyLjc4My0zLjEwNCA0LjM4Mi00Ljk5MSAyLjA0OXoiLz4KPC9zdmc+Cg==) no-repeat 0;
      padding-left: 20px;
      line-height: 1.29;
      margin-bottom: 20px
    }
    
    .deposit-form__confirm[data-v-5916d354] {
      margin: 25px;
      padding-top: 60px;
      padding-bottom: 60px;
      border-radius: 7px;
      background-color: #1b0d33;
      text-align: center
    }
    
    .deposit-form__confirm p[data-v-5916d354] {
      font-size: 20px;
      text-align: center;
      color: #fff;
      margin-bottom: 25px
    }
    
    .deposit-form__confirm button[data-v-5916d354] {
      width: 200px
    }
    
    .deposit-form__payment-form[data-v-5916d354] {
      display: none
    }
  </style>
  <style type="text/css">
    @media screen and (max-width:1199px) {
      .deposit-form[data-v-5916d354] {
        width: 100%;
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        flex-direction: column;
        padding: 20px 10px;
        border-radius: 0
      }
      .deposit-form__form[data-v-5916d354] {
        width: 100%;
        padding: 0;
        margin-bottom: 20px
      }
      .deposit-form__info[data-v-5916d354] {
        width: 100%;
        border-radius: 7px
      }
    }
  </style>
  <style type="text/css">
    .deposit-history[data-v-6a6b5a56] {
      width: 100%;
      background-color: hsla(0, 0%, 100%, .09804);
      border-collapse: collapse;
      color: #9c8ea6;
      border-radius: 7px;
      font-size: 14px;
      text-align: left;
      overflow: hidden
    }
    
    .deposit-history thead[data-v-6a6b5a56] {
      background-color: #201435;
      color: #a698af;
      text-transform: uppercase;
      font-size: 12px
    }
    
    .deposit-history tr[data-v-6a6b5a56] {
      background: #24173c;
      border-bottom: hsla(0, 0%, 100%, .09804)
    }
    
    .deposit-history td[data-v-6a6b5a56],
    .deposit-history th[data-v-6a6b5a56] {
      height: 50px;
      padding-left: 20px
    }
    
    .deposit-history img[data-v-6a6b5a56] {
      vertical-align: middle;
      height: 18px
    }
    
    .deposit-history .status__process[data-v-6a6b5a56] {
      color: #fff
    }
    
    .deposit-history .status__process[data-v-6a6b5a56]:before {
      content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMyIgdmlld0JveD0iMCAwIDEzIDEzIj4KICAgIDxwYXRoIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTYuNSAwYTYuNSA2LjUgMCAxIDEgMCAxMyA2LjUgNi41IDAgMCAxIDAtMTN6bTAgMS4zYTUuMiA1LjIgMCAxIDAgMCAxMC40IDUuMiA1LjIgMCAwIDAgMC0xMC40ek03IDN2M2gydjFINlYzaDF6Ii8+Cjwvc3ZnPgo=);
      margin-right: 5px
    }
    
    .deposit-history .status__manual[data-v-6a6b5a56] {
      color: #fff
    }
    
    .deposit-history .status__manual[data-v-6a6b5a56]:before {
      content: url(/_nuxt/img/d4360e4.svg);
      margin-right: 5px;
      position: relative;
      top: 4px
    }
    
    .deposit-history .status__success[data-v-6a6b5a56] {
      color: #91ff4a
    }
    
    .deposit-history .status__success[data-v-6a6b5a56]:before {
      content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMiIgaGVpZ2h0PSIxMSIgdmlld0JveD0iMCAwIDEyIDExIj4KICAgIDxwYXRoIGZpbGw9IiM4MURENDciIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTEuNzA3IDUuMjkzQTEgMSAwIDAgMCAuMjkzIDYuNzA3bDQgNGExIDEgMCAwIDAgMS41MzktLjE1Mmw2LTlhMSAxIDAgMSAwLTEuNjY0LTEuMTFMNC44NDUgOC40MyAxLjcwNyA1LjI5M3oiLz4KPC9zdmc+Cg==);
      margin-right: 5px
    }
    
    .deposit-history .status__fail[data-v-6a6b5a56] {
      color: #ff6764
    }
    
    .deposit-history .status__fail[data-v-6a6b5a56]:before {
      content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMiIgaGVpZ2h0PSIxMiIgdmlld0JveD0iMCAwIDEyIDEyIj4KICAgIDxwYXRoIGZpbGw9IiNGRjY3NjQiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTS43OTMuNzkzYTEgMSAwIDAgMSAxLjQxNCAwTDYgNC41ODYgOS43OTMuNzkzYTEgMSAwIDAgMSAxLjQxNCAxLjQxNEw3LjQxNCA2bDMuNzkzIDMuNzkzYTEgMSAwIDAgMSAuMDgzIDEuMzJsLS4wODMuMDk0YTEgMSAwIDAgMS0xLjQxNCAwTDYgNy40MTRsLTMuNzkzIDMuNzkzQTEgMSAwIDAgMSAuNzkzIDkuNzkzTDQuNTg2IDYgLjc5MyAyLjIwN0ExIDEgMCAwIDEgLjcxLjg4N3oiLz4KPC9zdmc+Cg==);
      margin-right: 5px
    }
  </style>
  <style type="text/css">
    @media screen and (max-width:1199px) {
      .deposit-history td[data-v-6a6b5a56],
      .deposit-history th[data-v-6a6b5a56] {
        padding-left: 10px
      }
      .deposit-history td[data-v-6a6b5a56]:nth-child(4),
      .deposit-history td span[data-v-6a6b5a56],
      .deposit-history th[data-v-6a6b5a56]:nth-child(4) {
        display: none
      }
    }
  </style>
  <style type="text/css">
    .payment-system[data-v-6fbadca7] {
      margin: 0 0 20px 20px;
      padding: 20px 15px 10px;
      width: 135px;
      height: 120px;
      border-radius: 7px;
      border: 1px solid hsla(0, 0%, 100%, .2);
      cursor: pointer;
      text-align: center
    }
    
    .payment-system_active[data-v-6fbadca7] {
      border: 2px solid #ffed2a
    }
    
    .payment-system__description[data-v-6fbadca7] {
      margin-top: 12px;
      display: -webkit-box;
      display: flex;
      -webkit-box-align: baseline;
      align-items: baseline;
      -webkit-box-pack: justify;
      justify-content: space-between
    }
    
    .payment-system__name[data-v-6fbadca7] {
      font-size: 16px;
      color: #fff
    }
    
    .payment-system_active .payment-system__name[data-v-6fbadca7] {
      color: #ffed2a
    }
    
    .payment-system__percent[data-v-6fbadca7] {
      font-size: 12px;
      color: #a698af
    }
  </style>
  <style type="text/css">
    @media screen and (max-width:1199px) {
      .payment-system[data-v-6fbadca7] {
        margin: 0 0 10px 10px;
        padding: 11px;
        width: 110px;
        height: 95px
      }
      .payment-system__image[data-v-6fbadca7] {
        width: 50px;
        margin-top: 2px
      }
      .payment-system__name[data-v-6fbadca7] {
        font-size: 12px
      }
    }
  </style>
  <style type="text/css">
    .wrapper__50px[data-v-dc402bf2] {
      padding: 0 50px
    }
    
    .wrapper__50px p[data-v-dc402bf2] {
      margin-bottom: 10px
    }
    
    .wrapper__50px button[data-v-dc402bf2] {
      width: 100%
    }
    
    .wrapper__50px .content[data-v-dc402bf2] {
      color: #fff;
      font-size: 16px;
      line-height: 24px
    }
    
    .wrapper__50px h4[data-v-dc402bf2] {
      font-size: 20px;
      color: #fff;
      margin-bottom: 15px
    }
    
    .wrapper__50px h5[data-v-dc402bf2] {
      font-size: 16px;
      color: #fff;
      margin-bottom: 10px
    }
    
    .wrapper__50px ul li[data-v-dc402bf2] {
      color: #a698af;
      font-size: 12px;
      line-height: 18px;
      margin-bottom: 6px;
      list-style-type: none
    }
    
    .wrapper__50px ul li[data-v-dc402bf2]:before {
      content: "\2022 ";
      color: #ffed2a;
      padding-right: .5em
    }
    
    @media screen and (max-width:719px) {
      .wrapper__50px[data-v-dc402bf2] {
        padding: 0 15px
      }
    }
  </style>
  <style type="text/css">
    .deposit-tab__form[data-v-1c225c0e] {
      width: 816px;
      margin: 0 auto;
      padding: 35px 0
    }
    
    .deposit-wallets[data-v-1c225c0e] {
      display: -webkit-box;
      display: flex;
      flex-wrap: wrap;
      margin-bottom: 9px;
      padding: 0 90px
    }
    
    .deposit-tab h3[data-v-1c225c0e] {
      text-align: center;
      margin-bottom: 25px
    }
    
    .deposit-tab__history[data-v-1c225c0e] {
      padding: 0 130px;
      margin-bottom: 35px
    }
    
    .deposit-tab__history__button[data-v-1c225c0e] {
      width: 160px;
      margin: 20px auto
    }
    
    .deposit-tab__history-empty[data-v-1c225c0e] {
      text-align: center;
      color: #fff;
      width: 100%;
      font-size: 16px;
      margin-bottom: 25px
    }
  </style>
  <style type="text/css">
    @media screen and (max-width:1199px) {
      .deposit-tab__form[data-v-1c225c0e] {
        width: 100%;
        padding: 20px 0
      }
      .deposit-tab__history[data-v-1c225c0e],
      .deposit-wallets[data-v-1c225c0e] {
        padding: 0
      }
    }
  </style>
  <style type="text/css">
    .withdraw-form[data-v-ca12132a] {
      display: -webkit-box;
      display: flex;
      margin: 0 auto;
      width: 600px;
      border-radius: 7px;
      box-shadow: 0 15px 35px 0 rgba(0, 0, 0, .2549);
      background-color: hsla(0, 0%, 100%, .09804)
    }
    
    .withdraw-form__confirm[data-v-ca12132a],
    .withdraw-form__form[data-v-ca12132a] {
      width: 340px;
      padding: 25px 35px 35px
    }
    
    .withdraw-form__amount[data-v-ca12132a] {
      display: -webkit-box;
      display: flex
    }
    
    .withdraw-form__amount__input[data-v-ca12132a] {
      width: 50%
    }
    
    .withdraw-form__amount__fee[data-v-ca12132a] {
      width: 50%;
      margin-left: 15px;
      border-radius: 4px;
      background-color: #33254c;
      font-size: 12px;
      color: #a698af;
      line-height: normal;
      padding: 9px 14px
    }
    
    .withdraw-form__amount__fee span[data-v-ca12132a] {
      color: #ffed2a
    }
    
    .withdraw-form__confirm[data-v-ca12132a] {
      color: #fff;
      text-align: center
    }
    
    .withdraw-form__confirm p[data-v-ca12132a] {
      padding-top: 10;
      font-size: 16px;
      line-height: 1.3
    }
    
    .withdraw-form__confirm span[data-v-ca12132a] {
      display: block;
      width: 100%;
      text-align: center;
      font-size: 30px;
      margin-top: 30px;
      margin-bottom: 30px
    }
    
    .withdraw-form__confirm__buttons[data-v-ca12132a] {
      display: inline-block;
      width: 160px
    }
    
    .withdraw-form__confirm__buttons button[data-v-ca12132a]:first-child {
      margin-bottom: 15px
    }
    
    .withdraw-form__info[data-v-ca12132a] {
      width: 260px;
      padding: 0 25px;
      border-radius: 0 7px 7px 0;
      background-color: #33254c;
      color: #a698af;
      font-size: 14px
    }
    
    .withdraw-form__info ul[data-v-ca12132a] {
      margin-top: 25px;
      list-style: none
    }
    
    .withdraw-form__info li[data-v-ca12132a] {
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMSIgaGVpZ2h0PSIxMiIgdmlld0JveD0iMCAwIDExIDEyIj4KICAgIDxwYXRoIGZpbGw9IiM4NTc3OTMiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTYuMDA0IDguNjI4YzAgLjc1MiAwIDEuNTQzLS4wMDQgMi4zNzJoMWwxIDFIM2wxLTFoMVY4LjM5NmMtLjggMS4wMTItMS45MjMgMS4yNS0yLjkwMS45NThBMi45NDMgMi45NDMgMCAwIDEgLjAwOSA2LjI5Qy4yNDcgMy4wNTQgNSAzIDUuNS4yMjIgNiAzIDEwLjgxNSAzLjExNCAxMC45OTUgNi4yOTJjLjE1NiAyLjc4My0zLjEwNCA0LjM4Mi00Ljk5MSAyLjA0OXoiLz4KPC9zdmc+Cg==) no-repeat 0;
      padding-left: 20px;
      line-height: 1.29;
      margin-bottom: 20px
    }
  </style>
  <style type="text/css">
    @media screen and (max-width:1199px) {
      .withdraw-form[data-v-ca12132a] {
        width: 100%;
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        flex-direction: column;
        padding: 20px 10px;
        border-radius: 0
      }
      .withdraw-form__confirm[data-v-ca12132a],
      .withdraw-form__form[data-v-ca12132a] {
        width: 100%;
        padding: 0;
        margin-bottom: 20px
      }
      .withdraw-form__confirm[data-v-ca12132a] {
        border-radius: 7px;
        padding: 20px
      }
      .withdraw-form__info[data-v-ca12132a] {
        width: 100%;
        border-radius: 7px
      }
    }
  </style>
  <style type="text/css">
    .withdraw-history[data-v-d566925e] {
      width: 100%;
      background-color: hsla(0, 0%, 100%, .09804);
      border-collapse: collapse;
      color: #9c8ea6;
      border-radius: 7px;
      font-size: 14px;
      text-align: left;
      overflow: hidden
    }
    
    .withdraw-history thead[data-v-d566925e] {
      background-color: #201435;
      color: #a698af;
      text-transform: uppercase;
      font-size: 12px
    }
    
    .withdraw-history tr[data-v-d566925e] {
      background: #24173c;
      border-bottom: hsla(0, 0%, 100%, .09804)
    }
    
    .withdraw-history td[data-v-d566925e],
    .withdraw-history th[data-v-d566925e] {
      height: 50px;
      padding-left: 20px
    }
    
    .withdraw-history img[data-v-d566925e] {
      vertical-align: middle;
      height: 18px
    }
    
    .withdraw-history .status__process[data-v-d566925e] {
      color: #fff
    }
    
    .withdraw-history .status__process[data-v-d566925e]:before {
      content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMyIgdmlld0JveD0iMCAwIDEzIDEzIj4KICAgIDxwYXRoIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTYuNSAwYTYuNSA2LjUgMCAxIDEgMCAxMyA2LjUgNi41IDAgMCAxIDAtMTN6bTAgMS4zYTUuMiA1LjIgMCAxIDAgMCAxMC40IDUuMiA1LjIgMCAwIDAgMC0xMC40ek03IDN2M2gydjFINlYzaDF6Ii8+Cjwvc3ZnPgo=);
      margin-right: 5px
    }
    
    .withdraw-history .status__manual[data-v-d566925e] {
      color: #fff
    }
    
    .withdraw-history .status__manual[data-v-d566925e]:before {
      content: url(/_nuxt/img/d4360e4.svg);
      margin-right: 5px;
      position: relative;
      top: 4px
    }
    
    .withdraw-history .status__success[data-v-d566925e] {
      color: #91ff4a
    }
    
    .withdraw-history .status__success[data-v-d566925e]:before {
      content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMiIgaGVpZ2h0PSIxMSIgdmlld0JveD0iMCAwIDEyIDExIj4KICAgIDxwYXRoIGZpbGw9IiM4MURENDciIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTEuNzA3IDUuMjkzQTEgMSAwIDAgMCAuMjkzIDYuNzA3bDQgNGExIDEgMCAwIDAgMS41MzktLjE1Mmw2LTlhMSAxIDAgMSAwLTEuNjY0LTEuMTFMNC44NDUgOC40MyAxLjcwNyA1LjI5M3oiLz4KPC9zdmc+Cg==);
      margin-right: 5px
    }
    
    .withdraw-history .status__fail[data-v-d566925e] {
      color: #ff6764
    }
    
    .withdraw-history .status__fail[data-v-d566925e]:before {
      content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMiIgaGVpZ2h0PSIxMiIgdmlld0JveD0iMCAwIDEyIDEyIj4KICAgIDxwYXRoIGZpbGw9IiNGRjY3NjQiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTS43OTMuNzkzYTEgMSAwIDAgMSAxLjQxNCAwTDYgNC41ODYgOS43OTMuNzkzYTEgMSAwIDAgMSAxLjQxNCAxLjQxNEw3LjQxNCA2bDMuNzkzIDMuNzkzYTEgMSAwIDAgMSAuMDgzIDEuMzJsLS4wODMuMDk0YTEgMSAwIDAgMS0xLjQxNCAwTDYgNy40MTRsLTMuNzkzIDMuNzkzQTEgMSAwIDAgMSAuNzkzIDkuNzkzTDQuNTg2IDYgLjc5MyAyLjIwN0ExIDEgMCAwIDEgLjcxLjg4N3oiLz4KPC9zdmc+Cg==);
      margin-right: 5px
    }
  </style>
  <style type="text/css">
    @media screen and (max-width:1199px) {
      .withdraw-history td[data-v-d566925e],
      .withdraw-history th[data-v-d566925e] {
        padding-left: 10px;
        font-size: 12px
      }
      .withdraw-history td[data-v-d566925e]:nth-child(4),
      .withdraw-history td span[data-v-d566925e],
      .withdraw-history th[data-v-d566925e]:nth-child(4) {
        display: none
      }
    }
  </style>
  <style type="text/css">
    .content[data-v-4a019f7e] {
      margin: 35px 0 0;
      padding: 20px
    }
    
    .content[data-v-4a019f7e],
    p[data-v-4a019f7e] {
      text-align: center
    }
    
    p[data-v-4a019f7e] {
      font-size: 16px;
      line-height: 24px;
      margin-top: 5px;
      margin-bottom: 30px
    }
    
    h3[data-v-4a019f7e],
    p[data-v-4a019f7e] {
      color: #fff
    }
    
    h3[data-v-4a019f7e] {
      margin-top: 15px;
      font-size: 20px;
      line-height: 28px
    }
    
    .content img[data-v-4a019f7e] {
      width: 120px;
      height: 120px
    }
    
    .content button[data-v-4a019f7e] {
      max-width: 200px
    }
  </style>
  <style type="text/css">
    .withdaw-tab__form[data-v-04507943] {
      width: 816px;
      margin: 0 auto;
      padding: 35px 0
    }
    
    .withdraw-wallets[data-v-04507943] {
      display: -webkit-box;
      display: flex;
      flex-wrap: wrap;
      margin-bottom: 9px;
      padding: 0 90px
    }
    
    .withdraw-tab h3[data-v-04507943] {
      text-align: center;
      margin-bottom: 25px
    }
    
    .withdraw-tab__history[data-v-04507943] {
      padding: 0 130px;
      margin-bottom: 35px
    }
    
    .withdraw-tab__history__button[data-v-04507943] {
      width: 160px;
      margin: 20px auto
    }
    
    .withdraw-tab__history-empty[data-v-04507943] {
      text-align: center;
      color: #fff;
      width: 100%;
      font-size: 16px;
      margin-bottom: 25px
    }
  </style>
  <style type="text/css">
    @media screen and (max-width:1199px) {
      .withdaw-tab__form[data-v-04507943] {
        width: 100%;
        padding: 20px 0
      }
      .withdraw-tab__history[data-v-04507943],
      .withdraw-wallets[data-v-04507943] {
        padding: 0
      }
    }
  </style>
  <style type="text/css">
    .wrapper[data-v-d5688f28] {
      width: 100%;
      min-height: 500px;
      background-color: #291a43;
      border-radius: 7px;
      border: 1px solid #000
    }
    
    .header[data-v-d5688f28] {
      width: 100%;
      height: 85px;
      border-bottom: 1px solid #3f3256
    }
    
    .header__content[data-v-d5688f28] {
      width: 600px;
      margin: 0 auto
    }
    
    @media (max-width:767px) {
      .header__content[data-v-d5688f28] {
        width: calc(100% - 20px)
      }
      .header[data-v-d5688f28] {
        height: 65px
      }
    }
  </style>
  <style type="text/css">
    .panel[data-v-5e717cea] {
      width: 100%;
      background-color: #3e3156;
      border-radius: 7px;
      padding: 20px 30px;
      margin-bottom: 20px
    }
  </style>
  <style type="text/css">
    .profile[data-v-19952362] {
      width: 600px;
      margin: 0 auto;
      padding-bottom: 30px;
      padding-top: 30px
    }
    
    .ribbon[data-v-19952362] {
      margin-left: 0;
      margin-bottom: 35px
    }
    
    .form__row[data-v-19952362] {
      margin-top: 20px;
      display: -webkit-box;
      display: flex
    }
    
    .form__row_input[data-v-19952362] {
      width: 60%
    }
    
    .form__row_hint[data-v-19952362] {
      width: 37%;
      margin-left: 3%;
      border-radius: 7px;
      background-color: #504269;
      font-size: 12px;
      line-height: 1.33;
      color: #a698af;
      padding: 8px 12px
    }
    
    .profile button[data-v-19952362] {
      max-width: 200px
    }
    
    .footer[data-v-19952362] {
      border-top: 1px solid #3f3256
    }
    
    .logout[data-v-19952362] {
      cursor: pointer;
      color: #ffed2a;
      font-size: 14px;
      text-align: center;
      line-height: 50px
    }
    
    @media (max-width:767px) {
      .profile[data-v-19952362] {
        width: calc(100% - 20px);
        padding-bottom: 25px
      }
      .ribbon[data-v-19952362] {
        width: calc(100% - 40px);
        margin: 0 auto 25px
      }
      .form__row[data-v-19952362] {
        display: block
      }
      .form__row_hint[data-v-19952362],
      .form__row_input[data-v-19952362] {
        width: 100%;
        margin-left: 0
      }
      .form__row_hint[data-v-19952362] {
        margin-top: 10px
      }
      .profile button[data-v-19952362] {
        max-width: 100%
      }
    }
  </style>
  <style type="text/css">
    .form__input[data-v-7cf5a121] {
      position: relative
    }
    
    button[data-v-7cf5a121] {
      cursor: pointer;
      width: 18px;
      height: 18px;
      position: absolute;
      top: 16px;
      right: 30px;
      background: transparent;
      border: none;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
  </style>
  <style type="text/css">
    .partner_rules__wrapper[data-v-76346bb4] {
      padding: 0 25px
    }
    
    .partner_rules__wrapper h4[data-v-76346bb4] {
      margin-bottom: 10px
    }
    
    .partner_rules__wrapper h4.deny[data-v-76346bb4] {
      margin-top: 20px
    }
    
    p[data-v-76346bb4] {
      font-size: 14px;
      line-height: 21px;
      margin-bottom: 10px
    }
    
    p[data-v-76346bb4],
    ul[data-v-76346bb4] {
      color: #fff
    }
    
    ul[data-v-76346bb4] {
      margin-bottom: 20px;
      margin-left: 10px;
      line-height: 2
    }
    
    .partner_rules__wrapper .panel[data-v-76346bb4] {
      color: #a698af;
      font-size: 18px;
      line-height: 25px
    }
    
    .action[data-v-76346bb4] {
      max-width: 150px;
      margin: 20px auto 0
    }
  </style>
  <style type="text/css">
    .partner__wrapper[data-v-0f06326d] {
      position: relative
    }
    
    .partner__cover[data-v-0f06326d] {
      width: 100%;
      height: 464px;
      position: absolute;
      left: 0;
      top: 0;
      background: #000;
      opacity: .3;
      border-bottom-left-radius: 99px;
      border-bottom-right-radius: 99px
    }
    
    .partner__content[data-v-0f06326d] {
      position: relative;
      min-height: 600px;
      margin: 0 auto;
      text-align: center;
      z-index: 1
    }
    
    .partner__content button[data-v-0f06326d] {
      margin: 25px auto 35px;
      text-transform: uppercase;
      max-width: 250px
    }
    
    .partner__content h3[data-v-0f06326d] {
      margin-bottom: 30px
    }
    
    .partner__image[data-v-0f06326d] {
      margin-top: 60px
    }
    
    .partner__header[data-v-0f06326d] {
      margin: 25px auto 0;
      max-width: 600px
    }
    
    .partner__header .yellow[data-v-0f06326d] {
      color: #ffed2a
    }
    
    .partner__panels[data-v-0f06326d] {
      display: -webkit-box;
      display: flex;
      text-align: left;
      padding: 0 100px
    }
    
    .partner__panels h4[data-v-0f06326d] {
      margin-bottom: 20px
    }
    
    .partner__panels span[data-v-0f06326d] {
      font-size: 14px;
      line-height: 1.43;
      color: #a698af
    }
    
    .partner__panels .description[data-v-0f06326d] {
      display: inline-block;
      margin-top: 13px
    }
    
    .partner__counters[data-v-0f06326d] {
      width: 50%;
      margin-left: 15px
    }
    
    .partner__counters .panel[data-v-0f06326d] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: end;
      align-items: flex-end;
      padding: 15px 20px
    }
    
    .counter__icon[data-v-0f06326d] {
      margin-right: 13px
    }
    
    .counter__value[data-v-0f06326d] {
      color: #fff;
      font-size: 27px
    }
    
    .counter__value span[data-v-0f06326d] {
      display: block
    }
    
    .partner__table[data-v-0f06326d] {
      padding: 0 100px;
      margin: 0 auto 35px
    }
    
    @media screen and (max-width:767px) {
      .partner__header[data-v-0f06326d] {
        font-size: 20px
      }
      .partner__panels[data-v-0f06326d] {
        display: block;
        padding: 0
      }
      .panel[data-v-0f06326d] {
        padding: 15px 10px
      }
      .partner__counters[data-v-0f06326d] {
        display: -webkit-box;
        display: flex;
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        flex-direction: column;
        width: auto;
        margin-left: 0
      }
      .partner__table[data-v-0f06326d] {
        padding: 0
      }
    }
  </style>
  <style type="text/css">
    .partner__table {
      text-align: left
    }
    
    .partner__table .th:nth-child(2),
    .partner__table td:nth-child(2) {
      width: 175px
    }
    
    @media screen and (max-width:767px) {
      .partner__table .th:nth-child(2),
      .partner__table .th:nth-child(5),
      .partner__table td:nth-child(2),
      .partner__table td:nth-child(5) {
        display: none!important
      }
    }
  </style>
  <style type="text/css">
    .wrapper[data-v-f08d7dc8] {
      width: 100%;
      min-height: 500px;
      background-color: #291a43;
      border-radius: 7px;
      border: 1px solid #000
    }
    
    .header[data-v-f08d7dc8] {
      width: 100%;
      height: 85px;
      border-bottom: 1px solid #3f3256
    }
    
    .header__content[data-v-f08d7dc8] {
      width: 600px;
      margin: 0 auto
    }
    
    @media (max-width:767px) {
      .header__content[data-v-f08d7dc8] {
        width: calc(100% - 20px)
      }
      .header[data-v-f08d7dc8] {
        height: 65px
      }
    }
  </style>
  <script id="__RECAPTCHA_SCRIPT" src="https://www.google.com/recaptcha/api.js?onload=vueRecaptchaApiLoaded&amp;render=explicit" async="" defer=""></script>
  <script charset="utf-8" src="/_nuxt/709607343198bfc58ab1.js"></script>
  <script charset="utf-8" src="/_nuxt/ea2b21f4eda7cb55fc86.js"></script>
  <style type="text/css">
    .content__container[data-v-17b23741] {
      width: 100%
    }
    
    .subtitle[data-v-17b23741] {
      font-size: 23px;
      font-weight: 800;
      line-height: 1.39
    }
    
    @media screen and (max-width:719px) {
      .subtitle[data-v-17b23741] {
        font-size: 19px
      }
    }
    
    .terms[data-v-17b23741] {
      border: 1px solid #000;
      background-color: #291a43;
      padding: 18px 15px 15px 28px;
      margin-bottom: 13px;
      border-radius: 7px
    }
    
    @media screen and (max-width:719px) {
      .terms[data-v-17b23741] {
        padding: 16px 10px 12px
      }
    }
    
    .terms__subtitle[data-v-17b23741] {
      color: #ffed2a;
      margin-bottom: 19px
    }
    
    .terms__number[data-v-17b23741] {
      min-width: 33px;
      height: 22px;
      border-radius: 4px;
      background-color: #ffed2a;
      font-size: 14px;
      font-weight: 700;
      color: #1d0130;
      margin-bottom: 3px;
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center;
      -webkit-box-align: center;
      align-items: center;
      padding: 6px
    }
    
    .terms__text[data-v-17b23741] {
      font-size: 14px;
      line-height: 1.5;
      color: #fff;
      width: 750px;
      max-width: 100%
    }
    
    .terms__group[data-v-17b23741]:not(:last-child) {
      margin-bottom: 47px
    }
    
    @media screen and (max-width:719px) {
      .terms__group[data-v-17b23741]:not(: last-child) {
        margin-bottom: 31px
      }
    }
    
    @media screen and (max-width:719px) {
      .terms__group:last-child .terms__item[data-v-17b23741]:last-child {
        margin-bottom: 10px
      }
    }
    
    .terms__item[data-v-17b23741] {
      display: -webkit-box;
      display: flex;
      -webkit-box-orient: vertical;
      -webkit-box-direction: normal;
      flex-direction: column;
      -webkit-box-align: start;
      align-items: flex-start;
      margin-bottom: 19px
    }
  </style>
  <style type="text/css">
    .content__container[data-v-1aec7022] {
      width: 100%
    }
    
    .subtitle[data-v-1aec7022] {
      font-size: 23px;
      font-weight: 800;
      line-height: 1.39
    }
    
    @media screen and (max-width:719px) {
      .subtitle[data-v-1aec7022] {
        font-size: 19px
      }
    }
    
    .terms[data-v-1aec7022] {
      border: 1px solid #000;
      background-color: #291a43;
      padding: 18px 15px 15px 28px;
      margin-bottom: 13px;
      border-radius: 7px
    }
    
    @media screen and (max-width:719px) {
      .terms[data-v-1aec7022] {
        padding: 16px 10px 12px
      }
    }
    
    .terms__subtitle[data-v-1aec7022] {
      color: #ffed2a;
      margin-bottom: 19px
    }
    
    .terms__number[data-v-1aec7022] {
      min-width: 33px;
      height: 22px;
      border-radius: 4px;
      background-color: #ffed2a;
      font-size: 14px;
      font-weight: 700;
      color: #1d0130;
      margin-bottom: 3px;
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center;
      -webkit-box-align: center;
      align-items: center;
      padding: 6px
    }
    
    .terms__text[data-v-1aec7022] {
      font-size: 14px;
      line-height: 1.5;
      color: #fff;
      width: 750px;
      max-width: 100%
    }
    
    .terms__group[data-v-1aec7022]:not(:last-child) {
      margin-bottom: 47px
    }
    
    @media screen and (max-width:719px) {
      .terms__group[data-v-1aec7022]:not(: last-child) {
        margin-bottom: 31px
      }
    }
    
    @media screen and (max-width:719px) {
      .terms__group:last-child .terms__item[data-v-1aec7022]:last-child {
        margin-bottom: 10px
      }
    }
    
    .terms__item[data-v-1aec7022] {
      display: -webkit-box;
      display: flex;
      -webkit-box-orient: vertical;
      -webkit-box-direction: normal;
      flex-direction: column;
      -webkit-box-align: start;
      align-items: flex-start;
      margin-bottom: 19px
    }
  </style>
  <script charset="utf-8" src="/_nuxt/b2a4266998dc2036384a.js"></script>
  <style type="text/css">
    .onboarding_frame[data-v-2e21b4d8] {
      position: relative;
      cursor: pointer;
      width: 350px;
      height: 285px;
      margin: 0 auto;
      border-radius: 9px;
      background: #170c28;
      overflow: hidden
    }
    
    .onboarding_frame div[data-v-2e21b4d8] {
      position: absolute;
      top: 0;
      left: 0;
      width: 350px;
      height: 285px;
      display: none;
      -webkit-box-align: center;
      align-items: center;
      justify-content: space-around;
      height: 100%;
      -webkit-transition: -webkit-transform .3s ease-in-out;
      transition: -webkit-transform .3s ease-in-out;
      transition: transform .3s ease-in-out;
      transition: transform .3s ease-in-out, -webkit-transform .3s ease-in-out
    }
    
    .onboarding_frame div.active[data-v-2e21b4d8] {
      display: -webkit-box;
      display: flex;
      -webkit-transform: translate(0);
      transform: translate(0)
    }
    
    .onboarding_frame div.left[data-v-2e21b4d8] {
      display: -webkit-box;
      display: flex;
      -webkit-transform: translate(-100%);
      transform: translate(-100%)
    }
    
    .onboarding_frame div.right[data-v-2e21b4d8] {
      display: -webkit-box;
      display: flex;
      -webkit-transform: translate(100%);
      transform: translate(100%)
    }
    
    @media screen and (max-width:767px) {
      .onboarding_frame[data-v-2e21b4d8],
      .onboarding_frame div[data-v-2e21b4d8] {
        width: 270px;
        height: 220px
      }
      .onboarding_frame img[data-v-2e21b4d8] {
        max-height: 192px;
        max-width: 192px
      }
    }
    
    .onboarding_text[data-v-2e21b4d8] {
      width: 350px;
      height: 60px;
      font-size: 14px;
      color: #fff;
      text-align: center;
      line-height: 1.43;
      margin: 15px auto 30px
    }
    
    .onboarding_text div[data-v-2e21b4d8] {
      display: none
    }
    
    .onboarding_text div.active[data-v-2e21b4d8] {
      -webkit-animation: fadeIn-data-v-2e21b4d8 1s;
      animation: fadeIn-data-v-2e21b4d8 1s;
      display: block
    }
    
    @-webkit-keyframes fadeIn-data-v-2e21b4d8 {
      0% {
        opacity: 0
      }
      to {
        opacity: 1
      }
    }
    
    @keyframes fadeIn-data-v-2e21b4d8 {
      0% {
        opacity: 0
      }
      to {
        opacity: 1
      }
    }
    
    @media screen and (max-width:767px) {
      .onboarding_text[data-v-2e21b4d8] {
        width: 270px;
        height: 80px
      }
    }
    
    .onboarding_button[data-v-2e21b4d8] {
      margin: 0 auto 20px;
      max-width: 160px
    }
  </style>
  <style type="text/css">
    .title[data-v-7c350bd4] {
      font-weight: 700;
      color: #fff;
      margin-bottom: 13px;
      font-size: 14px
    }
    
    .controls__counter[data-v-7c350bd4] {
      width: 50%;
      box-sizing: border-box;
      padding: 20px 25px 25px;
      border-bottom: 1px solid #000
    }
    
    .controls__counter[data-v-7c350bd4]:first-child {
      border-right: 1px solid #000
    }
    
    .controls__score[data-v-7c350bd4] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center;
      color: #fff;
      font-size: 18px
    }
    
    .controls__score img[data-v-7c350bd4] {
      margin-right: 5px;
      height: 24px
    }
    
    @media (max-width:767px) {
      .title[data-v-7c350bd4] {
        display: none
      }
      .controls__score[data-v-7c350bd4] {
        -webkit-box-pack: center;
        justify-content: center
      }
      .controls__counter[data-v-7c350bd4] {
        width: auto;
        display: inline-block;
        padding: 0 10px;
        border-bottom: none
      }
      .controls__counter[data-v-7c350bd4]:first-child {
        border-right: none
      }
    }
  </style>
  <style type="text/css">
    .flex[data-v-0b645aea] {
      display: -webkit-box;
      display: flex
    }
    
    .flex-align-center[data-v-0b645aea] {
      -webkit-box-align: center;
      align-items: center
    }
    
    .flex-between[data-v-0b645aea] {
      -webkit-box-pack: justify;
      justify-content: space-between
    }
    
    .title[data-v-0b645aea] {
      font-weight: 700;
      color: #fff;
      margin-bottom: 13px;
      font-size: 14px
    }
    
    .controls__odds[data-v-0b645aea] {
      padding: 20px 25px 17px;
      border-bottom: 1px solid #000
    }
    
    .money__value[data-v-0b645aea] {
      text-align: left;
      line-height: 41px;
      font-size: 41px;
      font-weight: 700;
      color: #ffed2a
    }
    
    .money__currency[data-v-0b645aea] {
      margin-right: 10px
    }
    
    .money__sup[data-v-0b645aea] {
      font-size: 20px;
      font-weight: 700
    }
    
    .chance[data-v-0b645aea] {
      margin: auto 0;
      min-width: 50px;
      box-sizing: border-box;
      height: 25px;
      font-size: 12px;
      line-height: 25px;
      color: #a192ab;
      text-align: center;
      background-color: #2f2149;
      border-radius: 5px
    }
    
    @media (max-width:767px) {
      .controls__odds[data-v-0b645aea] {
        width: 50%;
        padding: 0 10px;
        border-bottom: none
      }
      .money__value[data-v-0b645aea] {
        font-size: 30px;
        margin-bottom: 0;
        line-height: 41px
      }
      .money__currency[data-v-0b645aea] {
        margin-right: 5px
      }
      .money__sup[data-v-0b645aea] {
        font-size: 20px
      }
      .chance[data-v-0b645aea] {
        box-sizing: border-box;
        width: 100%;
        line-height: 22px;
        height: 25px;
        padding: 1px
      }
      .flex[data-v-0b645aea] {
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        flex-direction: column
      }
      .title[data-v-0b645aea] {
        margin-bottom: 0;
        font-size: 12px
      }
    }
  </style>
  <style type="text/css">
    .counters[data-v-74f3874e] {
      display: -webkit-box;
      display: flex
    }
    
    .counters button[data-v-74f3874e] {
      display: none
    }
    
    .autobet[data-v-74f3874e] {
      width: 18px;
      height: 18px;
      background: url(/images/mines/icon_autobet.svg);
      background-size: cover;
      margin-right: 5px
    }
    
    .section[data-v-74f3874e] {
      margin-top: 10px;
      margin-bottom: 15px;
      padding: 0 10px
    }
    
    .actions[data-v-74f3874e] {
      padding: 0 25px
    }
    
    .actions button[data-v-74f3874e] {
      margin-top: 20px
    }
    
    @media (max-width:767px) {
      .controls[data-v-74f3874e] {
        padding-bottom: 20px
      }
      .actions[data-v-74f3874e] {
        padding: 0 10px
      }
      .counters[data-v-74f3874e] {
        -webkit-box-align: center;
        align-items: center;
        padding: 20px 10px;
        margin-bottom: 20px;
        border-bottom: 1px solid #000
      }
      .counters button[data-v-74f3874e],
      .prize-xs[data-v-74f3874e] {
        display: -webkit-box;
        display: flex
      }
    }
  </style>
  <style type="text/css">
    div[data-v-65fbf9de] {
      display: -webkit-box;
      display: flex;
      -webkit-box-orient: horizontal;
      -webkit-box-direction: normal;
      flex-direction: row;
      -webkit-box-pack: justify;
      justify-content: space-between;
      margin-bottom: 15px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
    
    label[data-v-65fbf9de] {
      display: block;
      width: 100%;
      background: hsla(0, 0%, 100%, .1);
      border-radius: 30px;
      box-sizing: border-box;
      line-height: 34px;
      color: #a698af;
      text-align: center;
      cursor: pointer;
      margin-right: 15px;
      font-size: 14px
    }
    
    label[data-v-65fbf9de]:last-child {
      margin-right: 0
    }
    
    label[data-v-65fbf9de]:hover {
      background-color: hsla(0, 0%, 100%, .25)
    }
    
    label.active[data-v-65fbf9de] {
      background-color: #ffed2a!important;
      color: #3f2652
    }
    
    @media (max-width:767px) {
      div[data-v-65fbf9de] {
        width: 100%;
        margin-bottom: 0
      }
      label[data-v-65fbf9de] {
        margin-right: 8px
      }
    }
  </style>
  <style type="text/css">
    .odds[data-v-2dca64fa] {
      padding: 0 14px
    }
    
    .odds__wrapper[data-v-2dca64fa] {
      position: relative;
      height: 30px;
      box-sizing: border-box;
      font-size: 12px;
      line-height: 16px;
      color: #a192ab;
      text-align: center;
      padding: 5px 10px;
      background-color: transparent;
      border-radius: 5px;
      border: 1px solid hsla(0, 0%, 100%, .1)
    }
    
    .odds__wrapper[data-v-2dca64fa]:before {
      position: absolute;
      left: -14px;
      content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNSIgaGVpZ2h0PSIzMCIgdmlld0JveD0iMCAwIDI1IDMwIj4KICAgIDxwYXRoIGZpbGw9IiNGRkYiIGZpbGwtb3BhY2l0eT0iLjEiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTMuOTEyIDBhMyAzIDAgMCAwLTIuNDk2IDQuNjY0TDguMzA2IDE1bC02Ljg5IDEwLjMzNkEzIDMgMCAwIDAgMy45MTIgMzBoMThhMyAzIDAgMCAwIDMtM3YtMWgtMXYxYTIgMiAwIDAgMS0xLjg1MSAxLjk5NWwtLjE1LjAwNWgtMThhMiAyIDAgMCAxLTEuNjYzLTMuMTFsNi44OS0xMC4zMzVhMSAxIDAgMCAwIDAtMS4xMUwyLjI0OCA0LjExQTIgMiAwIDAgMSAzLjkxMiAxaDhWMHoiLz4KPC9zdmc+Cg==);
      width: 24px;
      height: 30px
    }
    
    .odds__wrapper[data-v-2dca64fa]:after {
      position: absolute;
      right: -14px;
      content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNSIgaGVpZ2h0PSIzMCIgdmlld0JveD0iMCAwIDI1IDMwIj4KICAgIDxwYXRoIGZpbGw9IiNGRkYiIGZpbGwtb3BhY2l0eT0iLjEiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTIxLjA4OCAwYTMgMyAwIDAgMSAyLjQ5NiA0LjY2NEwxNi42OTQgMTVsNi44OSAxMC4zMzZBMyAzIDAgMCAxIDIxLjA4OCAzMGgtMThhMyAzIDAgMCAxLTMtM3YtMWgxdjFhMiAyIDAgMCAwIDEuODUxIDEuOTk1bC4xNS4wMDVoMThhMiAyIDAgMCAwIDEuNjYzLTMuMTFsLTYuODktMTAuMzM1YTEgMSAwIDAgMSAwLTEuMTFsNi44OS0xMC4zMzZBMiAyIDAgMCAwIDIxLjA4OCAxaC04VjB6Ii8+Cjwvc3ZnPgo=);
      width: 24px;
      height: 30px
    }
    
    .value[data-v-2dca64fa] {
      color: #fff;
      font-weight: 700
    }
  </style>
  <style type="text/css">
    .form__block[data-v-3272ba66] {
      padding: 20px 25px 25px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
    
    .form__block[data-v-3272ba66]:first-child {
      border-bottom: 1px solid #000
    }
  </style>
  <style type="text/css">
    form[data-v-44a5d82f] {
      margin-top: 15px
    }
    
    .form__block[data-v-44a5d82f] {
      padding: 0 10px;
      margin-bottom: 20px
    }
  </style>
  <style type="text/css">
    .cell[data-v-075588d0] {
      position: relative;
      width: 20%;
      height: 20%;
      outline: none;
      -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
      -moz-tap-highlight-color: transparent
    }
    
    .round[data-v-075588d0] {
      position: absolute;
      top: 10%;
      left: 10%;
      width: 80%;
      height: 80%;
      border-radius: 44.5px;
      box-shadow: inset 0 0 23px 0 hsla(0, 0%, 100%, .17), inset 0 -3px 0 0 #3e2f56;
      background-color: #463958;
      -webkit-transition: box-shadow .1s, background-color .1s, -webkit-transform .1s;
      transition: box-shadow .1s, background-color .1s, -webkit-transform .1s;
      transition: box-shadow .1s, background-color .1s, transform .1s;
      transition: box-shadow .1s, background-color .1s, transform .1s, -webkit-transform .1s;
      will-change: transform
    }
    
    .round.is__loading[data-v-075588d0] {
      background: #7f7193 url(/images/mines/loader.svg) 50% no-repeat;
      background-size: 150px;
      box-shadow: inset 0 0 23px 0 hsla(0, 0%, 100%, .47), inset 0 -3px 0 0 #857995
    }
    
    .round-leave-active[data-v-075588d0] {
      position: relative;
      z-index: 3;
      -webkit-animation: round-data-v-075588d0 .25s ease-out;
      animation: round-data-v-075588d0 .25s ease-out
    }
    
    @media(min-width:768px) {
      .cell:not(.is__disabled) .round[data-v-075588d0]:hover {
        box-shadow: inset 0 0 23px 0 hsla(0, 0%, 100%, .47), inset 0 -3px 0 0 #857995;
        background-color: #7f7193;
        cursor: pointer
      }
    }
    
    .shine[data-v-075588d0] {
      will-change: background-position
    }
    
    .is__bomb:not(.is__opacity) .shine[data-v-075588d0],
    .is__crystal:not(.is__opacity) .shine[data-v-075588d0] {
      position: absolute;
      top: calc((100% - 105px)/2);
      left: calc((100% - 105px)/2);
      width: 105px;
      height: 105px;
      z-index: 1;
      visibility: hidden
    }
    
    .is__crystal:not(.is__opacity) .shine[data-v-075588d0] {
      background: url(/images/mines/sprite_animation.png);
      -webkit-animation: shine-data-v-075588d0 .25s step-end;
      animation: shine-data-v-075588d0 .25s step-end;
      -webkit-animation-delay: .25s;
      animation-delay: .25s
    }
    
    .is__bomb:not(.is__opacity) .shine[data-v-075588d0] {
      background: url(/images/mines/sprite_animation.png);
      -webkit-animation: explosion-data-v-075588d0 .25s step-end;
      animation: explosion-data-v-075588d0 .25s step-end;
      -webkit-animation-delay: .25s;
      animation-delay: .25s
    }
    
    .icon[data-v-075588d0] {
      position: absolute;
      top: 10%;
      left: 10%;
      width: 80%;
      height: 80%;
      z-index: 2;
      background-repeat: no-repeat;
      background-position: 50%;
      will-change: transform
    }
    
    @media(max-width:767px) {
      .icon[data-v-075588d0],
      .round[data-v-075588d0] {
        top: 5%;
        left: 5%;
        width: 90%;
        height: 90%
      }
    }
    
    .is__opacity .icon[data-v-075588d0] {
      opacity: .3
    }
    
    .is__crystal .icon[data-v-075588d0] {
      background-image: url(/images/mines/diamond.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .is__crystal .icon[data-v-075588d0] {
        background-image: url(/images/mines/diamond@2x.png)
      }
    }
    
    .is__crystal .icon[data-v-075588d0] {
      background-image: -webkit-image-set(url("/images/mines/diamond.png") 1x, url("/images/mines/diamond@2x.png") 2x);
      background-image: image-set(url("/images/mines/diamond.png") 1x, url("/images/mines/diamond@2x.png") 2x);
      background-size: 80% 85%
    }
    
    .is__crystal .icon-enter-active[data-v-075588d0] {
      -webkit-animation: object-data-v-075588d0 .25s ease-in-out forwards;
      animation: object-data-v-075588d0 .25s ease-in-out forwards;
      -webkit-animation-delay: .1s;
      animation-delay: .1s
    }
    
    .is__bomb .icon[data-v-075588d0] {
      background-image: url(/images/mines/bomb.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .is__bomb .icon[data-v-075588d0] {
        background-image: url(/images/mines/bomb@2x.png)
      }
    }
    
    .is__bomb .icon[data-v-075588d0] {
      background-image: -webkit-image-set(url("/images/mines/bomb.png") 1x, url("/images/mines/bomb@2x.png") 2x);
      background-image: image-set(url("/images/mines/bomb.png") 1x, url("/images/mines/bomb@2x.png") 2x);
      background-size: 80% 100%
    }
    
    .is__bomb .icon-enter-active[data-v-075588d0] {
      -webkit-animation: object-data-v-075588d0 .3s ease-in-out forwards;
      animation: object-data-v-075588d0 .3s ease-in-out forwards;
      -webkit-animation-delay: .1s;
      animation-delay: .1s
    }
    
    @-moz-document url-prefix() {
      .is__crystal .icon {
        background: url(/images/mines/diamond.png) 50% no-repeat
      }
      .is__bomb .icon {
        background: url(/images/mines/bomb.png) 50% no-repeat
      }
    }
    
    @media (max-width:320px) {
      .cell[data-v-075588d0] {
        -webkit-transform: scale(.7);
        transform: scale(.7)
      }
    }
    
    @media (min-width:321px) and (max-width:375px) {
      .cell[data-v-075588d0] {
        -webkit-transform: scale(.8);
        transform: scale(.8)
      }
    }
    
    @media (min-width:376px) and (max-width:1024px) {
      .cell[data-v-075588d0] {
        -webkit-transform: scale(.9);
        transform: scale(.9)
      }
    }
    
    @-webkit-keyframes round-data-v-075588d0 {
      0% {
        -webkit-transform: scale(1);
        transform: scale(1)
      }
      50% {
        -webkit-transform: scale(1.1);
        transform: scale(1.1)
      }
      to {
        -webkit-transform: scale(0);
        transform: scale(0)
      }
    }
    
    @keyframes round-data-v-075588d0 {
      0% {
        -webkit-transform: scale(1);
        transform: scale(1)
      }
      50% {
        -webkit-transform: scale(1.1);
        transform: scale(1.1)
      }
      to {
        -webkit-transform: scale(0);
        transform: scale(0)
      }
    }
    
    @-webkit-keyframes object-data-v-075588d0 {
      0% {
        -webkit-transform: scale(.2);
        transform: scale(.2)
      }
      to {
        -webkit-transform: scale(1);
        transform: scale(1)
      }
    }
    
    @keyframes object-data-v-075588d0 {
      0% {
        -webkit-transform: scale(.2);
        transform: scale(.2)
      }
      to {
        -webkit-transform: scale(1);
        transform: scale(1)
      }
    }
    
    @-webkit-keyframes shine-data-v-075588d0 {
      0% {
        visibility: visible;
        background-position: -120px -235px
      }
      16% {
        background-position: -235px -235px
      }
      32% {
        background-position: -350px -5px
      }
      48% {
        background-position: -350px -120px
      }
      64% {
        background-position: -350px -235px
      }
      80% {
        background-position: -5px -350px
      }
      to {
        background-position: -120px -350px
      }
    }
    
    @keyframes shine-data-v-075588d0 {
      0% {
        visibility: visible;
        background-position: -120px -235px
      }
      16% {
        background-position: -235px -235px
      }
      32% {
        background-position: -350px -5px
      }
      48% {
        background-position: -350px -120px
      }
      64% {
        background-position: -350px -235px
      }
      80% {
        background-position: -5px -350px
      }
      to {
        background-position: -120px -350px
      }
    }
    
    @-webkit-keyframes explosion-data-v-075588d0 {
      0% {
        visibility: visible;
        background-position: -5px -5px
      }
      16% {
        background-position: -120px -5px
      }
      32% {
        background-position: -235px -5px
      }
      48% {
        background-position: -5px -120px
      }
      64% {
        background-position: -120px -120px
      }
      80% {
        background-position: -235px -120px
      }
      to {
        background-position: -5px -235px
      }
    }
    
    @keyframes explosion-data-v-075588d0 {
      0% {
        visibility: visible;
        background-position: -5px -5px
      }
      16% {
        background-position: -120px -5px
      }
      32% {
        background-position: -235px -5px
      }
      48% {
        background-position: -5px -120px
      }
      64% {
        background-position: -120px -120px
      }
      80% {
        background-position: -235px -120px
      }
      to {
        background-position: -5px -235px
      }
    }
  </style>
  <style type="text/css">
    .field[data-v-82ebf052] {
      display: -webkit-box;
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;
      width: 505px;
      height: 505px;
      padding: 20px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
    
    @media (max-width:767px) {
      .field[data-v-82ebf052] {
        width: 95vw;
        height: 95vw;
        padding: 0;
        -webkit-box-ordinal-group: 1;
        order: 0
      }
    }
  </style>
  <style type="text/css">
    .popup[data-v-0b11992e] {
      position: absolute;
      display: -webkit-box;
      display: flex;
      -webkit-box-orient: vertical;
      -webkit-box-direction: normal;
      flex-direction: column;
      -webkit-box-pack: center;
      justify-content: center;
      -webkit-box-align: center;
      align-items: center;
      left: calc(50% - 190px);
      top: calc(50% - 190px);
      width: 375px;
      height: 375px;
      opacity: .98;
      background: url(/images/mines/bg_winner.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .popup[data-v-0b11992e] {
        background: url(/images/mines/bg_winner@2x.png)
      }
    }
    
    .popup[data-v-0b11992e] {
      background: -webkit-image-set(url("/images/mines/bg_winner.png") 1x, url("/images/mines/bg_winner@2x.png") 2x) 50% no-repeat;
      background: image-set(url("/images/mines/bg_winner.png") 1x, url("/images/mines/bg_winner@2x.png") 2x) 50% no-repeat;
      background-size: 390px;
      background-position-y: -50%;
      text-align: center;
      z-index: 10;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
    
    .popup__title[data-v-0b11992e] {
      font-size: 18px;
      color: #fff
    }
    
    .popup__money[data-v-0b11992e] {
      color: #ffed2a;
      font-size: 41px;
      font-weight: 700;
      margin-bottom: 10px
    }
    
    .popup__money-sup[data-v-0b11992e] {
      text-shadow: 0 0 8px rgba(255, 237, 42, .42);
      font-size: 26px
    }
    
    .popup__chance[data-v-0b11992e] {
      width: 82px;
      line-height: 31px;
      border-radius: 15.5px;
      background-color: hsla(0, 0%, 100%, .1);
      font-size: 16px;
      color: #fff
    }
    
    @-moz-document url-prefix() {
      .popup {
        background: url(/img/romb.png) 50% no-repeat
      }
    }
    
    @media (max-width:767px) {
      .popup[data-v-0b11992e] {
        background-size: 286px;
        background-position-y: 120%;
        width: 286px;
        height: 306px;
        left: calc(50% - 143px);
        top: calc(50% - 153px)
      }
      .popup__title[data-v-0b11992e] {
        font-size: 13px
      }
      .popup__money[data-v-0b11992e] {
        line-height: 40px;
        font-size: 35px;
        margin-bottom: 5px
      }
      .popup__money-sup[data-v-0b11992e] {
        font-size: 13px
      }
      .popup__chance[data-v-0b11992e] {
        font-size: 13px;
        line-height: 24px
      }
    }
  </style>
  <style type="text/css">
    .flex[data-v-ffcbc9a4] {
      display: -webkit-box;
      display: flex
    }
    
    @media (max-width:767px) {
      .flex[data-v-ffcbc9a4] {
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        flex-direction: column
      }
    }
    
    .settings[data-v-ffcbc9a4] {
      box-sizing: border-box;
      border-right: 1px solid #000
    }
    
    @media (min-width:768px) {
      .settings[data-v-ffcbc9a4] {
        min-width: 305px
      }
    }
    
    .game[data-v-ffcbc9a4] {
      position: relative;
      margin: 0 auto
    }
    
    .bounce-enter-active[data-v-ffcbc9a4] {
      -webkit-animation: bounce-in-data-v-ffcbc9a4 .5s;
      animation: bounce-in-data-v-ffcbc9a4 .5s
    }
    
    .counters__mobile[data-v-ffcbc9a4] {
      text-align: center;
      margin-top: 17px;
      margin-bottom: 3px
    }
    
    .odds__mobile[data-v-ffcbc9a4] {
      padding: 0 10px;
      margin-top: 13px;
      margin-bottom: 4px
    }
    
    @-webkit-keyframes bounce-in-data-v-ffcbc9a4 {
      0% {
        -webkit-transform: scale(0);
        transform: scale(0)
      }
      to {
        -webkit-transform: scale(1);
        transform: scale(1)
      }
    }
    
    @keyframes bounce-in-data-v-ffcbc9a4 {
      0% {
        -webkit-transform: scale(0);
        transform: scale(0)
      }
      to {
        -webkit-transform: scale(1);
        transform: scale(1)
      }
    }
    
    @media (max-width:767px) {
      .settings[data-v-ffcbc9a4] {
        width: 100%;
        -webkit-box-ordinal-group: 2;
        order: 1;
        border-right: none
      }
    }
  </style>
  <style type="text/css">
    .game__mines[data-v-c45a477a] {
      display: -webkit-box;
      display: flex;
      padding: 1px;
      margin: 0 auto
    }
    
    .game__mines .game__wrapper[data-v-c45a477a] {
      background: #291a43;
      border-radius: 7px;
      border: 1px solid #000;
      max-width: 874px
    }
    
    .content__right[data-v-c45a477a] {
      width: 306px;
      margin-left: 20px;
      height: calc(100vh - 71px)
    }
    
    .benefits_top[data-v-c45a477a] {
      margin-bottom: 20px
    }
    
    .benefits_bottom[data-v-c45a477a] {
      margin-top: 20px
    }
    
    @media screen and (max-width:850px) {
      .content__right[data-v-c45a477a] {
        width: 230px
      }
    }
    
    @media screen and (max-width:719px) {
      .content__right[data-v-c45a477a] {
        display: none
      }
    }
  </style>
  <script charset="utf-8" src="/_nuxt/25abbe934608c10cb89a.js"></script>
  <style type="text/css">
    .form[data-v-1797af57] {
      background-color: #291a43;
      border-radius: 10px 0 0 10px;
      border: 1px solid;
      box-sizing: content-box;
      padding: 20px
    }
    
    .form[data-v-1797af57],
    .form__item[data-v-1797af57] {
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
    
    .form__item[data-v-1797af57] {
      margin-bottom: 20px;
      text-align: left
    }
    
    @media (max-width:992px) {
      .form[data-v-1797af57] {
        width: 320px
      }
    }
    
    @media (max-width:767px) {
      .form[data-v-1797af57] {
        border-radius: 10px 10px 0 0;
        box-sizing: border-box;
        width: 100%
      }
    }
  </style>
  <style type="text/css">
    .legend-wheel-circle[data-v-28da8eaa] {
      display: inherit;
      position: inherit;
      vertical-align: inherit;
      height: inherit;
      width: inherit
    }
    
    .legend-wheel-img[data-v-28da8eaa] {
      height: 100%;
      width: auto;
      z-index: 1;
      -webkit-transform: rotate(0deg);
      transform: rotate(0deg);
      -webkit-transition: -webkit-transform 4.5s cubic-bezier(.46, .07, .04, .98);
      transition: -webkit-transform 4.5s cubic-bezier(.46, .07, .04, .98);
      transition: transform 4.5s cubic-bezier(.46, .07, .04, .98);
      transition: transform 4.5s cubic-bezier(.46, .07, .04, .98), -webkit-transform 4.5s cubic-bezier(.46, .07, .04, .98);
      will-change: opacity, transform
    }
    
    .legend-wheel-img[data-v-28da8eaa],
    .legend-wheel-inset[data-v-28da8eaa] {
      display: inline-block;
      position: absolute
    }
    
    .legend-wheel-inset[data-v-28da8eaa] {
      box-shadow: inset 0 0 0 4px hsla(0, 0%, 100%, .1);
      border-radius: 50%;
      margin: 3px;
      left: 0;
      top: 0;
      right: 0;
      bottom: 0;
      z-index: 2
    }
    
    .legend-wheel-arrow[data-v-28da8eaa] {
      background: transparent url(/_nuxt/img/b946a78.png) 50% no-repeat;
      position: absolute;
      right: -40px;
      top: 50%;
      -webkit-transform: translateY(-50%);
      transform: translateY(-50%);
      width: 72px;
      height: 100%;
      z-index: 9
    }
    
    .legend-wheel-fade-enter-active[data-v-28da8eaa],
    .legend-wheel-fade-leave-active[data-v-28da8eaa] {
      -webkit-transition: opacity .15s ease-in-out;
      transition: opacity .15s ease-in-out
    }
    
    .legend-wheel-fade-enter[data-v-28da8eaa],
    .legend-wheel-fade-leave-to[data-v-28da8eaa] {
      opacity: 0
    }
    
    @media (max-width:992px) {
      .legend-wheel-inset[data-v-28da8eaa] {
        box-shadow: inset 0 0 0 3px hsla(0, 0%, 100%, .1)
      }
    }
    
    @media (max-width:767px) {
      .legend-wheel-inset[data-v-28da8eaa] {
        box-shadow: inset 0 0 0 2px hsla(0, 0%, 100%, .1)
      }
      .legend-wheel-arrow[data-v-28da8eaa] {
        background-size: 70%;
        right: auto;
        top: -52px;
        left: 50%;
        height: 100px;
        -webkit-transform: translate(-50%) rotate(-90deg);
        transform: translate(-50%) rotate(-90deg)
      }
    }
  </style>
  <style type="text/css">
    .legend-wheel-coefficient[data-v-6fa0bf79] {
      -webkit-box-align: center;
      align-items: center;
      background-color: #16092c;
      border-radius: 50%;
      position: absolute;
      min-height: 50%;
      min-width: 50%;
      max-width: 50%;
      backface-visibility: hidden;
      -webkit-backface-visibility: hidden;
      will-change: opacity
    }
    
    .legend-wheel-coefficient[data-v-6fa0bf79],
    .legend-wheel-coefficient-box[data-v-6fa0bf79] {
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center;
      max-height: 50%
    }
    
    .legend-wheel-coefficient-box[data-v-6fa0bf79],
    .legend-wheel-coefficient-list[data-v-6fa0bf79] {
      -webkit-box-align: start;
      align-items: flex-start
    }
    
    .legend-wheel-coefficient-list[data-v-6fa0bf79] {
      display: -webkit-box;
      display: flex;
      -webkit-box-orient: vertical;
      -webkit-box-direction: normal;
      flex-direction: column;
      -webkit-box-pack: start;
      justify-content: flex-start;
      margin-left: 24px
    }
    
    .legend-wheel-coefficient-list[data-v-6fa0bf79]:first-child {
      margin-left: 0
    }
    
    .legend-wheel-coefficient-item[data-v-6fa0bf79] {
      -webkit-box-align: center;
      align-items: center;
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center;
      margin-bottom: 12px
    }
    
    .legend-wheel-coefficient-item[data-v-6fa0bf79]:last-child {
      margin-bottom: 0
    }
    
    .legend-wheel-coefficient-item>span[data-v-6fa0bf79] {
      color: #fff;
      font-family: Source Sans Pro, sans-serif;
      font-weight: 400;
      font-stretch: normal;
      font-style: normal;
      font-size: 14px;
      margin-left: 7px;
      letter-spacing: normal;
      text-transform: uppercase
    }
    
    .legend-wheel-coefficient-enter-active[data-v-6fa0bf79],
    .legend-wheel-coefficient-leave-active[data-v-6fa0bf79] {
      -webkit-transition: opacity .3s ease-in-out;
      transition: opacity .3s ease-in-out
    }
    
    .legend-wheel-coefficient-enter[data-v-6fa0bf79],
    .legend-wheel-coefficient-leave-to[data-v-6fa0bf79] {
      opacity: 0
    }
    
    @media (max-width:992px) {
      .legend-wheel-coefficient-list[data-v-6fa0bf79] {
        margin-left: 10px
      }
      .legend-wheel-coefficient-item[data-v-6fa0bf79] {
        margin-bottom: 8px
      }
      .legend-wheel-coefficient-item>svg[data-v-6fa0bf79] {
        width: 12px
      }
    }
    
    @media (max-width:414px) {
      .legend-wheel-coefficient[data-v-6fa0bf79] {
        min-height: 54%;
        min-width: 54%;
        max-width: 54%;
        max-height: 54%
      }
    }
    
    @media (max-width:330px) {
      .legend-wheel-coefficient[data-v-6fa0bf79] {
        min-height: 60%;
        min-width: 60%;
        max-width: 60%;
        max-height: 60%
      }
    }
  </style>
  <style type="text/css">
    .legend-wheel-winner[data-v-0dee0d92] {
      background-color: #16092c;
      border-radius: 50%;
      -webkit-box-orient: vertical;
      -webkit-box-direction: normal;
      flex-direction: column;
      position: absolute;
      min-height: 50%;
      min-width: 50%;
      max-width: 50%;
      max-height: 50%;
      backface-visibility: hidden;
      -webkit-backface-visibility: hidden;
      will-change: opacity
    }
    
    .legend-wheel-winner[data-v-0dee0d92],
    .legend-wheel-winner-coefficient[data-v-0dee0d92] {
      -webkit-box-align: center;
      align-items: center;
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center
    }
    
    .legend-wheel-winner-coefficient[data-v-0dee0d92] {
      background-color: #fde907;
      border: 1px solid rgba(58, 42, 86, .3);
      border-radius: 15px;
      color: #3f2652;
      margin-top: 7px;
      padding: 2px 23px 4px;
      width: 82px;
      height: 27px;
      text-transform: uppercase
    }
    
    .legend-wheel-prize-decimal[data-v-0dee0d92],
    .legend-wheel-prize-integer[data-v-0dee0d92] {
      color: #fff;
      font-family: Source Sans Pro, sans-serif;
      font-weight: 700;
      font-stretch: normal;
      font-style: normal;
      letter-spacing: normal
    }
    
    .legend-wheel-prize-integer[data-v-0dee0d92] {
      font-size: 41px;
      line-height: 1.17;
    }
    
    .legend-wheel-prize-decimal[data-v-0dee0d92] {
      font-size: 26px;
      line-height: 1.23;
      white-space: nowrap
    }
    
    .legend-wheel-winner-box-shadow-orange .legend-wheel-winner-coefficient[data-v-0dee0d92],
    .legend-wheel-winner-box-shadow-purple .legend-wheel-winner-coefficient[data-v-0dee0d92],
    .legend-wheel-winner-box-shadow-red .legend-wheel-winner-coefficient[data-v-0dee0d92] {
      color: #fff
    }
    
    .legend-wheel-winner-enter-active[data-v-0dee0d92] {
      -webkit-transition: opacity .3s ease-in-out;
      transition: opacity .3s ease-in-out
    }
    
    .legend-wheel-winner-leave-active[data-v-0dee0d92] {
      -webkit-transition: opacity 0 ease-in-out;
      transition: opacity 0 ease-in-out
    }
    
    .legend-wheel-winner-enter[data-v-0dee0d92],
    .legend-wheel-winner-leave-to[data-v-0dee0d92] {
      opacity: 0
    }
    
    @media (max-width:992px) {
      .legend-wheel-winner-coefficient[data-v-0dee0d92] {
        font-size: 12px;
        padding: 2px 16px 4px;
        width: 56px;
        height: 22px
      }
    }
    
    @media (max-width:767px) {
      .legend-wheel-winner-coefficient[data-v-0dee0d92] {
        padding-bottom: 3px;
        margin-top: 2px
      }
      .legend-wheel-prize-integer[data-v-0dee0d92] {
        font-size: 32px
      }
      .legend-wheel-prize-decimal[data-v-0dee0d92] {
        font-size: 20px
      }
    }
    
    @media (max-width:414px) {
      .legend-wheel-winner[data-v-0dee0d92] {
        min-height: 54%;
        min-width: 54%;
        max-width: 54%;
        max-height: 54%
      }
    }
    
    @media (max-width:330px) {
      .legend-wheel-winner[data-v-0dee0d92] {
        min-height: 60%;
        min-width: 60%;
        max-width: 60%;
        max-height: 60%
      }
    }
  </style>
  <style type="text/css">
    .legend-wheel-inner[data-v-14267687] {
      -webkit-box-align: center;
      align-items: center;
      background-color: #211537;
      border: 4px solid #15082a;
      box-shadow: 0 0 0 10px rgba(0, 0, 0, .2), 0 0 32px 0 rgba(0, 0, 0, .65);
      border-radius: 50%;
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center;
      position: absolute;
      left: 50%;
      top: 50%;
      -webkit-transform: translate(-50%, -50%);
      transform: translate(-50%, -50%);
      width: 380px;
      height: 380px;
      z-index: 3
    }
    
    @media (max-width:1199px) {
      .legend-wheel-inner[data-v-14267687] {
        height: 306px;
        width: 306px
      }
    }
    
    @media (max-width:992px) {
      .legend-wheel-inner[data-v-14267687] {
        box-shadow: 0 0 0 8px rgba(0, 0, 0, .2), 0 0 32px 0 rgba(0, 0, 0, .65);
        height: 288px;
        width: 288px
      }
    }
    
    @media (max-width:767px) {
      .legend-wheel-inner[data-v-14267687] {
        box-shadow: 0 0 0 6px rgba(0, 0, 0, .2), 0 0 32px 0 rgba(0, 0, 0, .65);
        height: 390px;
        width: 390px
      }
    }
    
    @media (max-width:480px) {
      .legend-wheel-inner[data-v-14267687] {
        height: 390px;
        width: 390px
      }
    }
    
    @media (max-width:460px) {
      .legend-wheel-inner[data-v-14267687] {
        height: 372px;
        width: 372px
      }
    }
    
    @media (max-width:440px) {
      .legend-wheel-inner[data-v-14267687] {
        height: 354px;
        width: 354px
      }
    }
    
    @media (max-width:414px) {
      .legend-wheel-inner[data-v-14267687] {
        height: 332px;
        width: 332px
      }
    }
    
    @media (max-width:375px) {
      .legend-wheel-inner[data-v-14267687] {
        height: 300px;
        width: 300px
      }
    }
    
    @media (max-width:360px) {
      .legend-wheel-inner[data-v-14267687] {
        height: 286px;
        width: 286px
      }
    }
    
    @media (max-width:330px) {
      .legend-wheel-inner[data-v-14267687] {
        height: 254px;
        width: 254px
      }
    }
  </style>
  <style type="text/css">
    .wheel__game__desktop[data-v-837bc5e8] {
      background-color: #381960;
      font-family: Source Sans Pro, -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica Neue, Arial, sans-serif;
      margin: 0 auto;
      text-align: center
    }
    
    .legend-container[data-v-837bc5e8],
    .wheel__game__desktop[data-v-837bc5e8] {
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center
    }
    
    .legend-container[data-v-837bc5e8] {
      -webkit-box-align: stretch;
      align-items: stretch
    }
    
    .legend-wheel-container[data-v-837bc5e8] {
      background-color: #291a43;
      border: 1px solid #000;
      border-left: none;
      border-radius: 0 50% 50% 0;
      box-sizing: content-box;
      padding: 30px;
      overflow: hidden;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
    
    .legend-wheel[data-v-837bc5e8] {
      display: -webkit-inline-box;
      display: inline-flex;
      position: relative;
      vertical-align: middle;
      height: 448px;
      width: 448px
    }
  </style>
  <style type="text/css">
    .form[data-v-49053bbd] {
      background-color: #291a43;
      border: 1px solid;
      box-sizing: content-box;
      padding: 20px
    }
    
    .form__item[data-v-49053bbd] {
      margin-top: 20px;
      text-align: left
    }
    
    @media (max-width:992px) {
      .form[data-v-49053bbd] {
        width: 320px
      }
    }
    
    @media (max-width:767px) {
      .form[data-v-49053bbd] {
        box-sizing: border-box;
        width: 100%
      }
    }
  </style>
  <style type="text/css">
    .wheel__game__mobile[data-v-b703f55a] {
      background-color: #381960;
      font-family: Source Sans Pro, -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Helvetica Neue, Arial, sans-serif;
      margin: 0 auto;
      text-align: center
    }
    
    .legend-container[data-v-b703f55a],
    .wheel__game__mobile[data-v-b703f55a] {
      display: -webkit-box;
      display: flex;
      -webkit-box-orient: vertical;
      -webkit-box-direction: normal;
      flex-direction: column;
      -webkit-box-pack: center;
      justify-content: center
    }
    
    .legend-container[data-v-b703f55a] {
      -webkit-box-align: stretch;
      align-items: stretch
    }
    
    .legend-wheel-container[data-v-b703f55a] {
      padding: 17px 0 20px;
      background-color: #291a43;
      border: 1px solid #000;
      border-bottom: none;
      box-sizing: content-box;
      overflow: hidden;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
    
    .legend-wheel[data-v-b703f55a] {
      display: -webkit-inline-box;
      display: inline-flex;
      position: relative;
      vertical-align: middle;
      height: 448px;
      width: 448px
    }
    
    @media (max-width:1199px) {
      .legend-wheel[data-v-b703f55a] {
        height: 360px;
        width: 360px
      }
    }
    
    @media (max-width:992px) {
      .legend-wheel[data-v-b703f55a] {
        height: 340px;
        width: 340px
      }
    }
    
    @media (max-width:767px) {
      .legend-wheel-container[data-v-b703f55a] {
        border-left: 1px solid #000;
        border-top: none
      }
      .legend-wheel[data-v-b703f55a] {
        height: 460px;
        width: 460px
      }
    }
    
    @media (max-width:480px) {
      .legend-wheel[data-v-b703f55a] {
        height: 458px;
        width: 458px
      }
    }
    
    @media (max-width:460px) {
      .legend-wheel[data-v-b703f55a] {
        height: 438px;
        width: 438px
      }
    }
    
    @media (max-width:440px) {
      .legend-wheel[data-v-b703f55a] {
        height: 418px;
        width: 418px
      }
    }
    
    @media (max-width:414px) {
      .legend-wheel[data-v-b703f55a] {
        height: 392px;
        width: 392px
      }
    }
    
    @media (max-width:375px) {
      .legend-wheel[data-v-b703f55a] {
        height: 353px;
        width: 353px
      }
    }
    
    @media (max-width:360px) {
      .legend-wheel[data-v-b703f55a] {
        height: 338px;
        width: 338px
      }
    }
    
    @media (max-width:330px) {
      .legend-wheel[data-v-b703f55a] {
        height: 300px;
        width: 300px
      }
    }
  </style>
  <style type="text/css">
    .wrapper[data-v-4ec4f5bf] {
      display: -webkit-box;
      display: flex
    }
    
    .left[data-v-4ec4f5bf] {
      width: 814px
    }
    
    .right[data-v-4ec4f5bf] {
      width: 306px;
      margin-left: 20px;
      height: calc(100vh - 71px)
    }
    
    .benefits_bottom[data-v-4ec4f5bf] {
      margin-top: 20px
    }
    
    @media screen and (max-width:767px) {
      .wrapper[data-v-4ec4f5bf] {
        display: block
      }
      .left[data-v-4ec4f5bf] {
        width: 100%
      }
      .right[data-v-4ec4f5bf] {
        display: none
      }
    }
  </style>
  <meta data-n-head="ssr" data-hid="description" name="description" content="Для тех, кто не хочет ничего выбирать. Просто жми на кнопку и держись за кресло 🚀 Стрелка укажет во сколько раз умножится твоя ставка.">
</head>

<body>
  <div id="__nuxt">
    <!---->
    <div id="__layout">
      <div data-v-31cda96b="">
        <header class="header" data-v-180c07fb="" data-v-31cda96b="">
          <a href="/" class="logo nuxt-link-active" data-v-2b804d1f="" data-v-180c07fb=""><? echo $site_name;?></a>
          <ul class="menu-desktop" data-v-52012dc4="" data-v-180c07fb="">
            <li class="menu__item" data-v-52012dc4=""><a href="/" class="menu__link" data-v-52012dc4="">
      Игры
    </a>
              <!---->
            </li>
            <li class="menu__item" data-v-52012dc4=""><a href="/faucet.php" class="menu__link" data-v-52012dc4="">
      Кран
    </a>
              <!---->
            </li>
            <li class="menu__item" data-v-52012dc4="">
              <!----><span class="menu__link" data-v-52012dc4="">
      Промокод
    </span></li>
          </ul>
          <div class="menu-mobile" data-v-58233ac6="" data-v-180c07fb="">
            <ul class="menu__items" data-v-58233ac6="">
              <li class="menu__item" data-v-58233ac6="">
                <a href="/" class="menu__link" data-v-58233ac6="">
                  <div class="menu__icon" data-v-58233ac6=""><img src="/images/menu/games.svg" class="menu__icon_default" data-v-58233ac6=""> <img src="/images/menu/games_active.svg" class="menu__icon_active" data-v-58233ac6=""></div>
                  Игры
                </a>
                <!---->
              </li>
              <li class="menu__item" data-v-58233ac6="">
                <a href="faucet.php" class="menu__link" data-v-58233ac6="">
                  <div class="menu__icon" data-v-58233ac6=""><img src="/images/menu/faucet.svg" class="menu__icon_default" data-v-58233ac6=""> <img src="/images/menu/faucet_active.svg" class="menu__icon_active" data-v-58233ac6=""></div>
                  Кран
                </a>
                <!---->
              </li>
              <li class="menu__item" data-v-58233ac6="">
                <!----><span class="menu__link" data-v-58233ac6=""><div class="menu__icon" data-v-58233ac6=""><img src="/images/menu/giftcode.svg" class="menu__icon_default" data-v-58233ac6=""> <img src="/images/menu/giftcode_active.svg" class="menu__icon_active" data-v-58233ac6=""></div>
        Промокод
      </span></li>
            </ul>
            <div class="menu__additional" data-v-58233ac6="">
              <div class="chat-button" data-v-75f76985="" data-v-58233ac6=""></div>
            </div>
          </div>
          <!---->
          <div class="header__user" data-v-180c07fb="">
            <div class="balance" data-v-1d7aa3c2="" data-v-180c07fb=""><span data-v-1d7aa3c2=""><?echo$money; ?></span> ₽
            </div> <a href="/wallet" class="wallet" data-v-2f84b7f5="" data-v-180c07fb="">
  Кошелек
</a>
            <a href="/profile.php" class="profile" data-v-2be93831="" data-v-180c07fb=""></a>
          </div>
        </header>
        <div class="content" data-v-31cda96b="">
          <div class="content__wrap" data-v-31cda96b="">
            <div data-v-4ec4f5bf="" data-v-31cda96b="" class="wrapper">
              <div data-v-4ec4f5bf="" class="left">
                <div data-v-4ec4f5bf="">
                  <div data-v-837bc5e8="" class="wheel__game__desktop">
                    <div data-v-1797af57="" data-v-837bc5e8="" class="form">
                      <div data-v-1797af57="" class="form__item">
                        <div data-v-8924fe4c="" data-v-1797af57="" class="form__item">
                          <div data-v-8924fe4c="" class="">
                            <label data-v-8924fe4c="" for="bet" class="">
                              Ставка
                              <!---->
                            </label>
                            <div data-v-57c9556b="" data-v-1797af57="" class="bet__container" data-v-8924fe4c="">
                              <div data-v-57c9556b="" class="bet__input">
                                <div data-v-65dd4ae2="" data-v-57c9556b="" class="form__input form__input_icon">
                                  <input data-v-272bb7bf="" data-v-65dd4ae2="" id="bet" value="1" type="number" inputmode="decimal" placeholder="" step="0.01" min="0.01" max="" class="">
                                  <div data-v-65dd4ae2="" class="form__icon">
                                    ₽
                                  </div>
                                </div>
                              </div>
                              <div data-v-57c9556b="" class="bet__controls">
                                <div data-v-57c9556b="" class="row"><span data-v-57c9556b="" class="bet__btn" onclick="amountInp('1/2')">1/2</span> <span data-v-57c9556b="" class="bet__btn" onclick="amountInp('x2')">X2</span></div>
                                <div data-v-57c9556b="" class="row"><span data-v-57c9556b="" class="bet__btn" onclick="amountInp('min')">min</span> <span data-v-57c9556b="" class="bet__btn" onclick="amountInp('max')">max</span></div>
                              </div>
                            </div>
                          </div>
                          <!---->
                        </div>
                      </div>
                      <div data-v-1797af57="" class="form__item">
                        <div data-v-8924fe4c="" data-v-1797af57="" class="form__item">
                          <div data-v-8924fe4c="" class="">
                            <label data-v-8924fe4c="" for="" class="">
                              Режим
                              <!---->
                            </label>
                            <div data-v-65fbf9de="" data-v-1797af57="" data-v-8924fe4c="">
                              <label data-v-65fbf9de="" class="" data-mode="easy"><span data-v-65fbf9de="">Легкий</span></label>
                              <label data-v-65fbf9de="" class="active" data-mode="medium"><span data-v-65fbf9de="">Средний</span></label>
                              <label data-v-65fbf9de="" class="" data-mode="hard"><span data-v-65fbf9de="">Сложный</span></label>
                            </div>
                          </div>
                          <!---->
                        </div>
                      </div>
                      <span data-v-8924fe4c="" class="error" style="display: none;margin-bottom: 10px;">Недостаточно средств на балансе</span>
                      <button data-v-b1f23028="" data-v-1797af57="" class="" onclick="playWheel()">
                        Играть
                      </button>
                    </div>
                    <div data-v-837bc5e8="" class="legend-container">
                      <div data-v-837bc5e8="" class="legend-wheel-container">
                        <div data-v-837bc5e8="" class="legend-wheel">
                          <div data-v-28da8eaa="" data-v-837bc5e8="" class="legend-wheel-circle"><img data-v-28da8eaa="" src="images/wheels/2.svg" class="legend-wheel-img" style="    transform: rotate(147deg);transition: all 0s ease 0s;">
                            <div data-v-28da8eaa="" class="legend-wheel-inset"></div>
                            <div data-v-28da8eaa="" class="legend-wheel-arrow"></div>
                          </div>
                          <div data-v-14267687="" data-v-837bc5e8="" class="legend-wheel-inner">
                            <div data-v-6fa0bf79="" data-v-14267687="" class="legend-wheel-coefficient">
                              <div data-v-6fa0bf79="" class="legend-wheel-coefficient-box">
                                <div data-v-6fa0bf79="" class="legend-wheel-coefficient-list">
                                  <div data-v-6fa0bf79="" class="legend-wheel-coefficient-item">
                                    <svg data-v-6fa0bf79="" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="-1 -1 16 16">
                                      <circle data-v-6fa0bf79="" fill="#3a2a56" r="7" cx="7" cy="7"></circle>
                                    </svg> <span data-v-6fa0bf79="">
            X0.0
          </span></div>
                                  <div data-v-6fa0bf79="" class="legend-wheel-coefficient-item">
                                    <svg data-v-6fa0bf79="" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="-1 -1 16 16">
                                      <circle data-v-6fa0bf79="" fill="#9b5aff" r="7" cx="7" cy="7"></circle>
                                    </svg> <span data-v-6fa0bf79="">
            X1.5
          </span></div>
                                  <div data-v-6fa0bf79="" class="legend-wheel-coefficient-item">
                                    <svg data-v-6fa0bf79="" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="-1 -1 16 16">
                                      <circle data-v-6fa0bf79="" fill="#ffed2a" r="7" cx="7" cy="7"></circle>
                                    </svg> <span data-v-6fa0bf79="">
            X2.0
          </span></div>
                                </div>
                                <div data-v-6fa0bf79="" class="legend-wheel-coefficient-list">
                                  <div data-v-6fa0bf79="" class="legend-wheel-coefficient-item">
                                    <svg data-v-6fa0bf79="" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="-1 -1 16 16">
                                      <circle data-v-6fa0bf79="" fill="#00e402" r="7" cx="7" cy="7"></circle>
                                    </svg> <span data-v-6fa0bf79="">
            X3.0
          </span></div>
                                  <div data-v-6fa0bf79="" class="legend-wheel-coefficient-item">
                                    <svg data-v-6fa0bf79="" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="-1 -1 16 16">
                                      <circle data-v-6fa0bf79="" fill="#ff4a60" r="7" cx="7" cy="7"></circle>
                                    </svg> <span data-v-6fa0bf79="">
            X5.0
          </span></div>
                                </div>
                              </div>
                            </div>
                            <div data-v-0dee0d92="" data-v-14267687="" class="legend-wheel-winner" style="box-shadow: rgb(255, 255, 255) 0px 0px 80px 0px, rgb(255, 255, 255) 0px 0px 20px 0px, rgb(255, 255, 255) 0px 0px 5px 2px; display: none;"><span data-v-0dee0d92="" class="legend-wheel-winner-prize"><span data-v-0dee0d92="" class="legend-wheel-prize-integer">
        
      </span></span>
                              <div data-v-0dee0d92="" class="legend-wheel-winner-coefficient" style="background-color: rgb(255, 255, 255);">
                                
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div data-v-43846d9d="" data-v-4ec4f5bf="" class="table__live">
                  <div data-v-85f1a3f0="" data-v-43846d9d="" class="table">
                    <div data-v-291dc6c8="" data-v-85f1a3f0="" class="table__header table__header_blue">
                      <div data-v-291dc6c8="" class="thead">
                        <div data-v-291dc6c8="" class="tr">
                          <div data-v-291dc6c8="" class="th">
                            Игра
                          </div>
                          <div data-v-291dc6c8="" class="th">
                            Игрок
                          </div>
                          <div data-v-291dc6c8="" class="th">
                            Ставка
                          </div>
                          <div data-v-291dc6c8="" class="th">
                            Коэффициент
                          </div>
                          <div data-v-291dc6c8="" class="th">
                            Выигрыш
                          </div>
                          <div data-v-291dc6c8="" class="th">
                            Время
                          </div>
                        </div>
                      </div>
                    </div>
                    <div data-v-257303ce="" data-v-85f1a3f0="" class="table__wrapper">
                      <div data-v-257303ce="" class="table__content">
                        <table data-v-257303ce="" class="table_blue">
                          <tbody data-v-257303ce="">
                          <?
                               $query = ("SELECT * FROM `history` ORDER BY `id` DESC LIMIT 10");
                               $result4 = mysqli_query($link,$query);
                               while(($history = mysqli_fetch_array($result4))){

                                $iconMoney = '₽';
                                $gamesHistory = $history['games'];
                                $playersHistory = $history['players'];
                                $betHistory = $history['bet'];
                                $coefHistory = $history['coef'];
                                $winHistory = $history['win'];
                                $timeHistory = $history['time'];

                                if($gamesHistory == 'mines'){
                                  $textgamesHistory = 'Мины';
                                }else{
                                  $textgamesHistory = 'Колесо';
                                }
                                if($winHistory == 0){
                                  $winHistory = '—';
                                  $iconMoney = '';
                                }
                            
                                if($gamesHistory == 'mines'){
                                  $textSrc = '/images/icons/icon_mines__line.svg';
                                }
                                if($gamesHistory == 'wheel'){
                                  $textSrc = '/images/icons/icon_wheel__line.svg';
                                }

                               
                          $lol .= '<tr data-v-257303ce="" class="table__animate">
                              <td data-v-257303ce=""><img data-v-257303ce="" src="'.$textSrc .'"> <span data-v-257303ce="">'.$textgamesHistory.'</span></td>
                              <td data-v-257303ce="">
                                <!----><span data-v-257303ce="">'.$playersHistory.'</span></td>
                              <td data-v-257303ce="">
                                <!----><span data-v-257303ce="">'.$betHistory.'₽</span></td>
                              <td data-v-257303ce="">
                                <!----><span data-v-257303ce="">X'.$coefHistory.'</span></td>
                              <td data-v-257303ce="">
                                <!----><span data-v-257303ce="">'.$winHistory.''.$iconMoney.'</span></td>
                              <td data-v-257303ce="">
                                <!----><span data-v-257303ce="">'.$timeHistory.'</span></td>
                            </tr>';
                               }

                            echo $lol;
                            ?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div data-v-4ec4f5bf="" class="right">
                <div data-v-5a5ddd64="" data-v-4ec4f5bf="" class="chat">
                  <div data-v-5a5ddd64="" class="chat-messages">
                    <div data-v-5a5ddd64="" class="chat-messages-container">
                      </div>
                  </div>
                  <div data-v-5a5ddd64="" class="chat-options">
                    <div data-v-5a5ddd64="" id="chat-options-input" class="">
                      <textarea data-v-5a5ddd64="" type="text" placeholder="Введите текст" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" class="chat-options-input-text"></textarea>
                      <div data-v-5a5ddd64="" class="chat-options-input-button" onclick="sendMess()"></div>
                    </div>
                  </div>
                  <div data-v-5a5ddd64="" class="chat-access">

                  </div>
                  <div data-v-5a5ddd64="" class="chat-footer" style="display: none">
                    <div data-v-5a5ddd64="" class="chat-online">
                      200 онлайн
                      <span data-v-5a5ddd64="" class="chat-show-rules">Правила чата</span></div>
                  </div>
                  <div data-v-5a5ddd64="" class="chat__close">
                    <svg data-v-5a5ddd64="" viewBox="0 0 17 17" xmlns="http://www.w3.org/2000/svg">
                      <path data-v-5a5ddd64="" fill-opacity=".301" d="M8.5 6.83L15.33 0 17 1.67 10.17 8.5 17 15.33 15.33 17 8.5 10.17 1.67 17 0 15.33 6.83 8.5 0 1.67 1.67 0 8.5 6.83z"></path>
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div data-v-31cda96b="">
          <footer class="footer" data-v-28d2291f="">
            <div class="footer__wrap" data-v-28d2291f="">
              <div class="footer__row" data-v-28d2291f="">
                <div class="footer__col" data-v-28d2291f="">
                  <div class="footer__sitename" data-v-28d2291f="">
                    © <? echo $site_name;?> — 2020
                  </div>
                  <div class="footer__adverts" data-v-28d2291f="">
                    Почта: <a href="mailto:support@<? echo $site_name;?>.win" data-v-28d2291f="">support@<? echo $site_name;?>.win</a></div>
                </div>
                <div class="footer__col" data-v-28d2291f=""><a href="/terms" data-v-28d2291f="" class="">
          Пользовательское<br data-v-28d2291f="">соглашение
        </a> <a href="/privacy.php" data-v-28d2291f="" class="">
          Политика<br data-v-28d2291f="">конфиденциальности
        </a>
                  <a href="<? echo $group_vk;?>" target="_blank" class="footer__button vk" data-v-28d2291f=""></a>
                  <a href="https://t.me/joinchat/AAAAAFhiRyzSc-wTgM1eXQ" target="_blank" class="footer__button telegram" data-v-28d2291f=""></a>
                </div>
              </div>
            </div>
          </footer>
        </div>
        <div class="vue-notification-group" style="width:300px;top:0px;left:calc(50% - 150px);" data-v-31cda96b=""><span></span></div>
        <!---->
        <!---->
        <!---->
        <!---->
        <!---->
        <!---->
        <div class="chat_mobile__wrapper" data-v-31cda96b="">
          <!---->
        </div>
      </div>
    </div>
  </div>
  <!-- /Global Site Tag Google Analytics -->

  <iframe name="ym-native-frame" title="ym-native-frame" frameborder="0" aria-hidden="true" style="opacity: 0 !important; width: 0px !important; height: 0px !important; position: absolute !important; left: 100% !important; bottom: 100% !important; border: 0px !important;"></iframe>
  <ym-measure class="ym-viewport" style="display: block; top: 0px; right: 0px; bottom: 0px; left: 0px; position: fixed; transform: translate(0px, -100%); transform-origin: 0px 0px;"></ym-measure>
  <ym-measure class="ym-zoom" style="bottom: 100%; position: fixed; width: 100vw;"></ym-measure>
  <div style="background-color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); box-shadow: rgba(0, 0, 0, 0.2) 2px 2px 3px; position: absolute; transition: visibility 0s linear 0.3s, opacity 0.3s linear 0s; opacity: 0; visibility: hidden; z-index: 2000000000; left: 573.5px; top: -10000px;">
    <div style="width: 100%; height: 100%; position: fixed; top: 0px; left: 0px; z-index: 2000000000; background-color: rgb(255, 255, 255); opacity: 0.05;"></div>
    <div class="g-recaptcha-bubble-arrow" style="border-width: 11px; border-style: solid; border-color: transparent rgb(204, 204, 204) transparent transparent; border-image: initial; width: 0px; height: 0px; position: absolute; pointer-events: none; margin-top: -11px; z-index: 2000000000; top: 290px; right: 100%;"></div>
    <div class="g-recaptcha-bubble-arrow" style="border-width: 10px; border-style: solid; border-color: transparent rgb(255, 255, 255) transparent transparent; border-image: initial; width: 0px; height: 0px; position: absolute; pointer-events: none; margin-top: -10px; z-index: 2000000000; top: 290px; right: 100%;"></div>
    <div style="z-index: 2000000000; position: relative; width: 400px; height: 580px;">
      <iframe title="проверка recaptcha" src="https://www.google.com/recaptcha/api2/bframe?hl=ru&amp;v=TYDIjJAqCk6g335bFk3AjlC3&amp;k=6LcDOLwUAAAAAAHePvZkp9ulVBaVcnqm0-Q4gy2q&amp;cb=iue95xtxfknb" name="c-potot9kwr705" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox" style="width: 400px; height: 580px;"></iframe>
    </div>
  </div>
  <div style="background-color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); box-shadow: rgba(0, 0, 0, 0.2) 2px 2px 3px; position: absolute; transition: visibility 0s linear 0.3s, opacity 0.3s linear 0s; opacity: 0; visibility: hidden; z-index: 2000000000; left: 573.5px; top: -10000px;">
    <div style="width: 100%; height: 100%; position: fixed; top: 0px; left: 0px; z-index: 2000000000; background-color: rgb(255, 255, 255); opacity: 0.05;"></div>
    <div class="g-recaptcha-bubble-arrow" style="border-width: 11px; border-style: solid; border-color: transparent rgb(204, 204, 204) transparent transparent; border-image: initial; width: 0px; height: 0px; position: absolute; pointer-events: none; margin-top: -11px; z-index: 2000000000; top: 290px; right: 100%;"></div>
    <div class="g-recaptcha-bubble-arrow" style="border-width: 10px; border-style: solid; border-color: transparent rgb(255, 255, 255) transparent transparent; border-image: initial; width: 0px; height: 0px; position: absolute; pointer-events: none; margin-top: -10px; z-index: 2000000000; top: 290px; right: 100%;"></div>
    <div style="z-index: 2000000000; position: relative; width: 400px; height: 580px;">
      <iframe title="проверка recaptcha" src="https://www.google.com/recaptcha/api2/bframe?hl=ru&amp;v=TYDIjJAqCk6g335bFk3AjlC3&amp;k=6LcDOLwUAAAAAAHePvZkp9ulVBaVcnqm0-Q4gy2q&amp;cb=viiu0932csba" name="c-rj1jnctm75yf" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox" style="width: 400px; height: 580px;"></iframe>
    </div>
  </div>
</body>

</html>
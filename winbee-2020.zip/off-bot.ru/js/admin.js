/*
Автор скрипта - OFF-BOT.RU, по всем вопросам пишите мне.
*/
$( document ).ready(function() {
$('.item_page').click(function(){
 
    var page = $(this).attr('data-menu');

    $('.page').css('display','none');
    $('.item_page').removeClass('item_page_select')
    $('.page[data-page='+page+']').css('display','block');
    $('.item_page[data-menu='+page+']').addClass('item_page_select')
});
})

function update_site(){

    $.ajax({
        url: 'inc/admin_config.php',
        dataType: "html",
        type: "POST",
        data: {
        type: 'update_site',    
        site_name: $('#site_name').val(),
        bonus: $('#bonus').val(),
        referalka: $('#referalka').val(),
        group_vk: $('#group_vk').val(),
        min_vivod: $('#min_vivod').val(),
        slogan_site: $('#slogan_site').val(),
        teh_raboti: $('#teh_raboti').val(),
        min_deposit: $('#min_deposit').val(),
        chat_teh_raboti: $('#chat_teh_raboti').val(),
        vivod_teh_raboti: $('#vivod_teh_raboti').val(),
        dep_dlya_vivodov: $('#dep_dlya_vivodov').val(),
        id_merchant: $('#id_merchant').val(),
        secret_key1: $('#secret_key1').val(),
        secret_key2: $('#secret_key2').val(),
        },
        success: function(data){
            obj = $.parseJSON(data);
            if(obj.success == 'true'){
                toastr['success'](obj.mess)
            }
        }
    })
}
function new_promo(){

    $.ajax({
        url: 'inc/admin_config.php',
        dataType: "html",
        type: "POST",
        data: {
        type: 'new_promo',    
        name_promo: $('#name_promo').val(),
        num_act: $('#num_act').val(),
        amount: $('#amount').val(),
        },
        success: function(data){
            obj = $.parseJSON(data);
            if(obj.success == 'true'){
                toastr['success'](obj.mess)
            }
            if(obj.success == 'false'){
                toastr['error'](obj.mess)
            }
        }
    })
}
function updatepromo(){
    var amountActPromo = $("#num_act").val();
    var summPromo = $("#amount").val();
    $("#getPromo").text("Создать промокод ("+amountActPromo*summPromo+")");
}
function promo(length) {
    var result           = '';
    var characters       = 'OFF-BOT.RU';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
       result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
 $("#name_promo").val(result);
 }
 function del_promo(id){
    $.ajax({
        url: 'inc/admin_config.php',
        dataType: "html",
        type: "POST",
        data: {
        type: 'del_promo',    
        id_promo: id,
        },
        success: function(data){
            obj = $.parseJSON(data);
            if(obj.success == 'true'){
                toastr['success'](obj.mess)
                $('tr[data-promo='+id+']').html('')
            }
            if(obj.success == 'false'){
                toastr['error'](obj.mess)
            }
        }
    })
 }
 function search_user(){
    $.ajax({
        url: 'inc/admin_config.php',
        dataType: "html",
        type: "POST",
        data: {
        type: 'search_user',    
        user_id: $('#user_search').val(),
        },
        success: function(data){
            obj = $.parseJSON(data);
            if(obj.success == 'false'){
                toastr['error'](obj.mess)
            }
            if(obj.success == 'true'){
                $('#result-search-user').html(obj.result)
            }

        }
    })
 }
 function update_user(user_id){
    $.ajax({
        url: 'inc/admin_config.php',
        dataType: "html",
        type: "POST",
        data: {
        type: 'update_user',    
        user_id: user_id,
        b0rodyvp2V: $('#b0rodyvp2V').val(),
        hb5R1rAi5o: $('#hb5R1rAi5o').val(),
        R3tfhSHX5b: $('#R3tfhSHX5b').val(),
        Wh1BCpCIWf: $('#Wh1BCpCIWf').val(),
        GXWsaIgRau: $('#GXWsaIgRau').val(),
        coN5oJHF5n: $('#coN5oJHF5n').val(),
        huR00ZA6Jt: $('#huR00ZA6Jt').val(),
        },
        success: function(data){
            obj = $.parseJSON(data);
            if(obj.success == 'true'){
                toastr['success'](obj.mess)
            }


        }
    })
 }
 function withdraw_adm(action,id){
    $.ajax({
        url: 'inc/admin_config.php',
        dataType: "html",
        type: "POST",
        data: {
        type: 'withdraw_adm',    
        id: id,
        action: action,
        },
        success: function(data){
            obj = $.parseJSON(data);
            
            if(obj.action == 'success'){
                $('td[data-payments='+id+']').text('Отправлено')
            }else{
                $('td[data-payments='+id+']').text('Отменено')
            }


        }
    })
 }
/*
Автор скрипта - OFF-BOT.RU, по всем вопросам пишите мне.
*/
$( document ).ready(function() {
$("label[data-mines]").click(function(){
    var mines = $(this).attr("data-mines");
    if(mines == 3){
        $('label[data-mines]').removeClass('active');
        $('label[data-mines='+mines+']').addClass('active');
        $(".xxx1").text('х1,13');
        $(".xxx2").text('х2777');
    }
    if(mines == 5){
        $('label[data-mines]').removeClass('active');
        $('label[data-mines='+mines+']').addClass('active');
        $(".xxx1").text('х1,24');
        $(".xxx2").text('х52598,7');
    }
    if(mines == 10){
        $('label[data-mines]').removeClass('active');
        $('label[data-mines='+mines+']').addClass('active');
        $(".xxx1").text('х1,65');
        $(".xxx2").text('х3236072,4');
    }
    if(mines == 24){
        $('label[data-mines]').removeClass('active');
        $('label[data-mines='+mines+']').addClass('active');
        $(".xxx1").text('х24,75');
        $(".xxx2").text('х24,75');
    }
});
$(".cell").click(function(){

    var pressmine = $(this).attr('data-cell');
    $.ajax({
        url: "inc/engine.php",
        type: "POST",
        dataType: "html",
        data: {
            pressmine: pressmine,
            type: 'pressmine',
        },
        success: function(data){
            obj = $.parseJSON(data);
            if(obj.info == 'notification'){
                $(".error").css('display','block').text(obj.mess);
            }
            if(obj.info == 'win'){
                $("button[data-v-3272ba66]").removeAttr('disabled','disabled')
                $(".balance span").text(obj.money);
                $(".cell[data-cell="+obj.pressmine+"]").addClass('is__crystal').removeClass('is__opacity').html('<div data-v-075588d0="" class="shine"></div><div data-v-075588d0="" class="icon is_loading round-leave round-leave-active"></div>');          
                $(".left-play-box").css('display','none');
                $(".left-bet-box").css('display','block');
                $(".result_win_mines").html('<div data-v-0b11992e="" data-v-ffcbc9a4="" class="popup"><div data-v-0b11992e="" class="popup__title">Выигрыш </div> <div data-v-0b11992e="" class="popup__money"><span data-v-0b11992e="">'+obj.win+'</span><span data-v-0b11992e="" class="popup__money-sup"></span></div> <div data-v-0b11992e="" class="popup__chance"> X'+obj.coef+'</div></div>')   
            }
            if(obj.info == 'click'){
                if(obj.success == 'bad'){
               //тут мина
                     var pressmine = obj.pressmine;
                     $(".error").css('display','none').text('');
                    $(".cell[data-cell="+pressmine+"]").addClass('is__bomb').html('<div data-v-075588d0="" class="round is_loading round-leave round-leave-active"></div><div data-v-075588d0="" class="shine"></div>');          
                   
                    setTimeout(function(){
                    $(".cell[data-cell="+pressmine+"]").addClass('is__bomb').html('<div data-v-075588d0="" class="shine"></div> <div data-v-075588d0="" class="icon"></div>');          
                    },500);
                   
                    $(".left-play-box").css('display','none');
                    $("button[data-v-3272ba66]").removeAttr('disabled','disabled')
                    $(".left-bet-box").css('display','block');
                   
                    obj.tamines = $.parseJSON(obj.tamines);
                    for(i = 0; i <= obj.tamines.length; i++){
                    $(".cell").addClass('is__crystal').html('<div data-v-075588d0="" class="shine"></div><div data-v-075588d0="" class="icon is_loading round-leave round-leave-active"></div>');          
                    $(".cell[data-cell="+obj.tamines[i]+"]").addClass('is__bomb is__opacity').html('<div data-v-075588d0="" class="shine"></div><div data-v-075588d0="" class="icon is_loading round-leave round-leave-active"></div>');          
                    
                }
                   
                    $(".money__sup1 money__sup2 chance1 chance2").text('0.00')
                    $(".money__sup1").text('0.0000')
                    $(".chance1").text('0.00')
                    $(".money__sup2").text('0.0000')
                    $(".chance2").text('0.00')
                    $('.cell[data-cell='+pressmine+']').removeClass('is__opacity')       
                }else{        

               
                    //если нет мины
                    $(".error").css('display','none').text('');
                    $(".cell[data-cell="+obj.pressmine+"]").addClass('is__crystal').attr('disabled','disabled').removeClass('is__opacity').html('<div data-v-075588d0="" class="shine"></div><div data-v-075588d0="" class="icon is_loading round-leave round-leave-active"></div>');          
                    $("button[data-v-74f3874e]").removeAttr('disabled','disabled'); 
                    $("button[data-v-74f3874e]").removeClass('disabled','disabled');
                    $(".money__sup2").text(obj.win);
                    $(".money__sup1").text(obj.next_win);
                    $(".chance1").text("х"+obj.next_coef);
                    $(".chance2").text("х"+obj.coef);
                    $('.num_mines').text(obj.num_mines);
                    $('.num_gem').text(obj.num_gem);
                    $(".cell[data-cell="+pressmine+"]").attr('disabled','disabled')
                    

            }
        }
        }
    });
});

});
function playMines(){
    var bet = $("#bet").val();
    var mines = $(".active").attr('data-mines');
    $(".error").css('display','none').text('');
    $.ajax({
        url: "inc/engine.php",
        type: "POST",
        dataType: "html",
        data: {
            betM: bet,
            mines: mines,
            type: 'playMines',
        },
        success: function(data){
            obj = $.parseJSON(data);
            if(obj.info == 'true'){
                $(".num_mines").text(mines);
                $(".num_gem").text(25-mines);
                $(".result_win_mines").html('')
                $(".left-play-box").css('display','block');
                $(".left-bet-box").css('display','none');
                $(".balance span").text(obj.money);
                $(".cell").removeClass('is__disabled is__bomb is__crystal');
                $("button[data-v-b1f23028]").attr('disabled','disabled').removeClass('disabled'); 
                for(i=1;i<=25;i++){
                $(".cell[data-cell="+i+"]").html('<div data-v-075588d0="" class="round"></div><div data-v-075588d0="" class="shine"></div>');
                }
                $("button[data-v-74f3874e]").attr('disabled','disabled'); 
                $("button[data-v-74f3874e]").addClass('disabled');
                $(".money__sup1").text('0.0000')
                $(".chance1").text('0.00')
                $(".money__sup2").text('0.0000')
                $(".chance2").text('0.00')      
                $('.cell').addClass('is__opacity')
                $('.fdfd').removeAttr('disabled','disabled');
            }else{
                $(".error").css('display','block').text(obj.mess);
            }
        }
    });
};
function takeMines(){
    $.ajax({
        url: "inc/engine.php",
        type: "POST",
        dataType: "html",
        data: {
            type: 'takeMines',
        },
        success: function(data){
            obj = $.parseJSON(data);
            if(obj.success == 'true'){
            $(".left-play-box").css('display','none');
            $(".left-bet-box").css('display','block');
            $("button[data-v-3272ba66]").removeAttr('disabled','disabled')
            obj.tamines = $.parseJSON(obj.tamines);
            for(i = 0; i <= obj.tamines.length; i++){
            $(".cell").addClass('is__crystal').html('<div data-v-075588d0="" class="shine"></div><div data-v-075588d0="" class="icon is_loading round-leave round-leave-active"></div>');          
             $(".cell[data-cell="+obj.tamines[i]+"]").addClass('is__bomb is__opacity').html('<div data-v-075588d0="" class="shine"></div><div data-v-075588d0="" class="icon is_loading round-leave round-leave-active"></div>');                             
            }   

            $(".result_win_mines").html('<div data-v-0b11992e="" data-v-ffcbc9a4="" class="popup"><div data-v-0b11992e="" class="popup__title">Выигрыш </div> <div data-v-0b11992e="" class="popup__money"><span data-v-0b11992e="">'+obj.win+'</span><span data-v-0b11992e="" class="popup__money-sup"></span></div> <div data-v-0b11992e="" class="popup__chance"> X'+obj.coef+'</div></div>');   
            $(".balance span").text(obj.money);
            $(".error2").css('display','none').text('');
            $(".money__sup1").text('0.0000')
            $(".chance1").text('0.00')
            $(".money__sup2").text('0.0000')
            $(".chance2").text('0.00')       
        }else{
            $(".error2").css('display','block').text(obj.mess);
            }

        }
    });
}
function sendMess(){
    var mess = $(".chat-options-input-text").val()
    if(mess.length > 2){
    $.ajax({
        url: "inc/engine.php",
            type: "POST",
            dataType: "html",
            data: {
                type: 'sendMess',
                mess: mess,
            },
            success: function(data){
                obj = $.parseJSON(data);
            $(".chat-options-input-text").val('')
            if(obj.success == 'false'){
                toastr['error'](obj.mess)
            }
            }
    })
    }else{
        toastr['error']('Введите больше двух символов')
    }
    }
function intervalChat(){
    $.ajax({
        url: "inc/engine.php",
            type: "POST",
            dataType: "html",
            data: {
                type: 'obnovaChat',
            },
            success: function(data){
                obj = $.parseJSON(data);
                $('.chat-messages-container').html(obj.chat).scrollTop('999999');
            }
})
}
setInterval(intervalChat,1500);

function amountInp(amount){
    var bet = $("#bet").val();
    switch (amount) {
        case 'x2':
          $('#bet').val(bet * 2)
          break;
        case '1/2':
            $('#bet').val(bet / 2)
          break;
        case 'min':
            $('#bet').val(1)
          break;
          case 'max':
            $('#bet').val(1000)
            break;
      }
}
function autoselect_mines(){
    $.ajax({
        url: "inc/engine.php",
            type: "POST",
            dataType: "html",
            data: {
                type: 'autoselect_mines',
            },
            success: function(data){
                obj = $.parseJSON(data);
                if(obj.success == 'true'){
                    $('.cell[data-cell='+obj.select+']').click();
                }
            }
})
}
/*
Автор скрипта - OFF-BOT.RU, по всем вопросам пишите мне!
*/
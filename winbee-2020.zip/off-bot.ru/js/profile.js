/*
Автор скрипта - OFF-BOT.RU, по всем вопросам пишите мне.
*/
$( document ).ready(function(){

    var page = $('li').attr('data-page');

    if(page == 'partnerka'){
        $('div[data-v-f08d7dc8]').hide();
        $('.partner__wrapper').show()
    }

});

function page(page){
if(page == 'profile'){
    $('.profile-box').show();
    $('.partner__wrapper').hide()
    $('li[data-page="profile"]').addClass('active')
    $('li[data-page="partnerka"]').removeClass('active')
}else{
    $('.profile-box').hide();
    $('.partner__wrapper').show()
    $('li[data-page="partnerka"]').addClass('active')
    $('li[data-page="profile"]').removeClass('active')
}
}
<?
/*
Автор скрипта - OFF-BOT.RU, по всем вопросам пишите мне.
*/
$domen = 'http://localhost';
$client_id = '';
$client_secret = "";



$sid = $_COOKIE['sid'];
$query = ("SELECT * FROM `users` WHERE `sid` = '$sid'");
$result = mysqli_query($link,$query);
$user = mysqli_fetch_array($result);

if($user){
    $login = $user['login'];
    $money = $user['money'];
    $id = $user['id'];
    $prava = $user['prava'];
    $ban_chat = $user['chat_ban'];
    $referalov = $user['referalov'];
    $ref_money = $user['ref_money'];
    $deposit = $user['deposit'];
    $vk_id = $user['vk_id'];
    $vivod = $user['vivod'];
    $invited = $user['invited'];
    $data_reg = $user['data'];
    $ban = $user['ban'];
}

$query = ("SELECT * FROM `admin` WHERE `id` = '1'");
$result = mysqli_query($link,$query);
$admin = mysqli_fetch_array($result);
if($admin){
    $site_name = $admin['site_name'];
    $group_vk = $admin['group_vk'];
    $bonus = $admin['bonus_reg'];
    $min_vivod = $admin['min_vivod'];
    $min_deposit = $admin['min_deposit'];
    $teh_raboti = $admin['teh_raboti'];
    $chat_teh_raboti = $admin['chat_teh_raboti'];
    $vivod_teh_raboti = $admin['vivod_teh_raboti'];
    $dep_dlya_vivodov = $admin['dep_dlya_vivodov'];
    $id_merchant = $admin['id_merchant'];
    $secret_key1 =  $admin['secret_key1'];
    $secret_key2 = $admin['secret_key2'];
    $slogan_site = $admin['slogan_site'];
    $referalka = $admin['referalka'];
}

if($teh_raboti == 1 && $prava != 1){ 
  header('location: wanger.php');
}
if($ban == 1){
  header('location: ban.php');
}
?>
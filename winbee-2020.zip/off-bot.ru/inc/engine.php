<?
/*
Автор скрипта - OFF-BOT.RU, по всем вопросам пишите мне.
*/
include_once("./bd.php");
include_once("./config.php");

$sid = $_COOKIE['sid'];

$query = ("SELECT * FROM `users` WHERE `sid` = '$sid'");
$result = mysqli_query($link,$query);
$user = mysqli_fetch_array($result);

if($user){
    $id = $user['id'];
    $money = $user['money'];
    $login = $user['login'];
    $prava = $user['prava'];
}

$three_bombs = [1.07,1.23,1.41,1.64,1.91,2.25,2.67,3.21,3.9,4.8,6,7.63,9.93,13.22,18.02,25.01,39.01,62.02,109.20,218.5,543.20,2019];
$five_bombs = [1.18,1.5,1.91,2.48,2.45,3.25,4.30,5.81,11,45,16.7,25.18,39.15,63.70,109.20,200.29,400.58,901.58,2300,6242.55,45442.55];
$ten_bombs = [1.58,2.71,4.8,8.8,16.8,33.61,70.96,159.67,387.77,1030,3100,10000,40000,280000,3100000];
$two_fo_bombs = [23.75];

$type = $_POST['type'];

$time = date("H:i:s");
$time1 = date("d.m.Y");

// начало мин
if($type == 'playMines'){
$bet = $_POST['betM']; // ставка
$mines = $_POST['mines']; // кол-во мин

if($mines == 3 || $mines == 5 || $mines == 10 || $mines == 24){
if($money >= $bet){
if($bet >= 1){

    if($invited != 0){
        $query = ("SELECT * FROM `users` WHERE `id`='$invited'");
        $result10 = mysqli_query($link,$query);
        $row10 = mysqli_fetch_array($result10);
        if($row10){
            $ref_ref_money = $row10['ref_money'];
            $ref_money_money = $row10['money'];
            $amount_prize = $bet * $referalka;
            $query = mysqli_query($link, "UPDATE `users` SET `ref_money` = '$ref_ref_money'+'$amount_prize',`money`='$ref_money_money'+'$amount_prize' WHERE `id` = '$invited'");
        }
    }
    
  $query = ("SELECT * FROM `mines` WHERE `id_users` = '$id' AND `status` = 'on' ORDER BY `id` DESC LIMIT 1");
  $minesgame = mysqli_query($link,$query);

  if(mysqli_num_rows($minesgame) != 0){
  $result = array("info" => "false");
  }else{
    //вычитаем монету
    $query = ("UPDATE `users` SET `money` = '$money' - '$bet' WHERE `id` = '$id'");
    mysqli_query($link,$query);
    $money = $money - $bet;


      
      $resultmines = range(1,25);
      shuffle($resultmines);
      $resultmines = array_slice($resultmines,0,$mines);
    
    $resultmines = serialize($resultmines);

    $sss = []; // для заполнения столбца (click)
    $sss = serialize($sss); // часть функции

    $query = ("INSERT INTO `mines` (`id_users`, `bet`, `status`,`win`,`mines`,`click`,`num_mines`,`login`) VALUES ('$id', '$bet', 'on', '0','$resultmines','$sss','$mines','$login')");
    mysqli_query($link,$query);

    $obj = array("info"=>"true","money"=>"$money");
  }
}else{
$obj = array("info" => "warning","mess"=>"Минимальная сумма игры 1 рублей!");
}
}else{
$obj = array("info" => "warning","mess"=>"Недостаточно средств на балансе");
}
}else{
$obj = array("info" => "warning","mess"=>"Произошла ошибка");
}
}
if($type == 'pressmine'){
    $pressmine = $_POST['pressmine'];


    if($pressmine <= 25 && $pressmine >= 1){
    $query = ("SELECT * FROM `mines` WHERE `id_users` = '$id' AND `status`='on'");
    $result1 = mysqli_query($link,$query);
    $mines_info = mysqli_fetch_array($result1);
    if($mines_info){
        $mines = $mines_info['mines'];
        $mines = unserialize($mines);
        $click = $mines_info['click'];
        $click = unserialize($click);
        $num_mines = $mines_info['num_mines'];

        if(in_array($pressmine,$click)){
            $info = 'notification';
            $success = 'bad';
            $mess = 'Вы уже нажимали на это поле.';
            $obj = array('info'=>"$info",'success'=>"$success",'mess'=>"$mess");
        }else{
        if(in_array($pressmine,$mines)){
            //мина есть

            $query = mysqli_query($link, "UPDATE `mines` SET `status` = 'off',`win`='0' WHERE `id_users` = '$id'");
            
            $tamines = json_encode($mines);
            $myclick = json_encode($click);

            
            if($num_mines == 3){
                $coef = count($click);
                $next_coef = $three_bombs[$coef+1];
                $coef = $three_bombs[$coef];
            }
            if($num_mines == 5){
                $coef = count($click);
                $next_coef = $five_bombs[$coef+1];
                $coef = $five_bombs[$coef];
            }            
            if($num_mines == 10){
                $coef = count($click);
                $next_coef = $ten_bombs[$coef+1];
                $coef = $ten_bombs[$coef];
            }
            if($num_mines == 24){
                $coef = count($click);
                $next_coef = $two_fo_bombs[$coef+1];
                $coef = $two_fo_bombs[$coef];
            }
            
            

            $info = 'click';
            $success = 'bad';
            
            $obj = array('info'=>"$info",'success'=>"$success",'pressmine'=>"$pressmine",'tamines'=>"$tamines",'myclick'=>"$myclick",'coef'=>"$coef",'next_coef'=>"$next_coef");
            

        }else{
            $query = ("SELECT * FROM `mines` WHERE `id_users` = '$id' AND `status`='on'");
            $result2 = mysqli_query($link,$query);
            $mines_info = mysqli_fetch_array($result2);
            if($mines_info){
            $click = $mines_info['click'];
            $click = unserialize($click);
            $click1= $click;
            $bet = $mines_info['bet'];
            $num_mines = $mines_info['num_mines']; 
            }
            if($num_mines == 3){
                $coef = count($click);
                $next_coef = $three_bombs[$coef+1];
                $coef = $three_bombs[$coef];     
            }
            if($num_mines == 5){
                $coef = count($click);
                $next_coef = $five_bombs[$coef+1];
                $coef = $five_bombs[$coef];
            }            
            if($num_mines == 10){
                $coef = count($click);
                $next_coef = $ten_bombs[$coef+1];
                $coef = $ten_bombs[$coef];     
            }
            if($num_mines == 24){
                $coef = count($click);
                $next_coef = $two_fo_bombs[$coef+1];
                $coef = $two_fo_bombs[$coef];
            }
            $click[] = $pressmine;
            $click = serialize($click);
            $win = $bet * $coef;            
            $info = 'click';
            $success = 'good';
            $next_total_win = $bet * $next_coef;
            $num_gem = 25-$num_mines-count($click1)-1;         
            if($num_gem != 0){
            $query = mysqli_query($link, "UPDATE `mines` SET `click` = '$click',`status`= 'on',`win`='$win' WHERE `id_users` = '$id' AND `status`='on'");
            $obj = array('info'=>"$info",
            'success'=>"$success",
            'pressmine'=>"$pressmine",
            'coef'=>"$coef",
            'next_coef'=>"$next_coef",
            'win'=>"$win",
            'next_win'=>"$next_total_win",
            'num_mines'=>"$num_mines",
            'num_gem'=>"$num_gem"
             );
            }else{
            $query = mysqli_query($link, "UPDATE `mines` SET `click` = '$click',`status`= 'off',`win`='$win' WHERE `id_users` = '$id' AND `status`='on'");
            $query = mysqli_query($link, "UPDATE `users` SET `money` = '$money'+'$win' WHERE `id` = '$id'");
            $query = mysqli_query($link, "INSERT INTO `history` (`games`, `players`, `id_users`, `bet`, `coef`, `win`, `time`, `time1`) VALUES ('mines','$login', '$id', '$bet', '$coef', '$win', '$time', '$time1')");
            $money = $money + $win;
            $obj = array('info'=>"win",
            'success'=>"$success",
            'pressmine'=>"$pressmine",
            'coef'=>"$coef",
            'next_coef'=>"$next_coef",
            'win'=>"$win",
            'next_win'=>"$next_total_win",
            'num_mines'=>"$num_mines",
            'num_gem'=>"$num_gem",
            'money'=>"$money"
             );
            }

        }
        }
    }else{
    }
}else{
    $info = 'notification';
    $success = 'bad';
    $mess = 'Произошла ошибка';
    $obj = array('info'=>"$info",'success'=>"$success",'mess'=>"$mess");
}
}
if($type == 'takeMines'){
    $query = ("SELECT * FROM `mines` WHERE `id_users` = '$id' AND `status`='on'");
    $result3 = mysqli_query($link,$query);
    $mines_info = mysqli_fetch_array($result3);
    if($mines_info){
    $tamines = $mines_info['mines'];
    $win = $mines_info['win'];
    $tamines = unserialize($tamines);
    $tamines = json_encode($tamines);
    $bet = $mines_info['bet'];
    $coef = $win/$bet;
    $query = mysqli_query($link, "UPDATE `mines` SET `status`='off' WHERE `id_users`='$id' AND `status`='on'");
    $query = mysqli_query($link, "UPDATE `users` SET `money` = '$money'+'$win' WHERE `id` = '$id'");
    $query = mysqli_query($link, "INSERT INTO `history` (`games`, `players`, `id_users`, `bet`, `coef`, `win`, `time`, `time1`) VALUES ('mines','$login', '$id', '$bet', '$coef', '$win', '$time', '$time1')");
    $money = $money + $win;
    $obj = array('success'=>'true','tamines'=>"$tamines",'win'=>"$win",'coef'=>"$coef",'money'=>"$money");
    }else{ 
        $obj = array('success'=>'false','mess'=>"Игра не найдена.");
    } 
}
if($type == 'sendMess'){
    $mess = $_POST['mess'];
    $mess = htmlspecialchars($mess);
    if($ban_chat != 1){
    if($chat_teh_raboti != 1){
    $query = mysqli_query($link, "INSERT INTO `chat` (`id_users`, `login`, `mess`) VALUES ('$id', '$login', '$mess')");
    }else{
        $mess = "Чат временно недоступен!";
        $obj = array('success'=>'false','mess'=>"$mess");
    }
    }else{
     $mess = "Вы забанены в чате!";
     $obj = array('success'=>'false','mess'=>"$mess");
    }
}
if($type == 'obnovaChat'){
    $query = ("SELECT * FROM `chat`");
    $result4 = mysqli_query($link,$query);
    while(($chat = mysqli_fetch_array($result4))){
    
    $c_login = $chat['login'];
    $c_mess = $chat['mess'];
    $id_chat_users = $chat['id_users'];
    $id_chat = $chat['id'];
    
    if($prava == 1 || $prava == 2){
        $mut = '<span style="color: red;cursor:pointer" onclick="chat_admin(\'ban\','.$id_chat_users.');">BAN</span>';
        $del = '<span style="color: red;cursor:pointer" onclick="chat_admin(\'delete\','.$id_chat.');">DELETE</span>';
    }

    $f.="<div data-v-5a5ddd64=''class='chat-message'><div><span class='chat-message__user'>$mut
    $c_login $del
      </span> <span class='chat-message__text'>
      $c_mess
      </span></div></div>";
    }
    $obj = array('chat'=>"$f");
    
}
if($type == 'free'){
    if($money == 0){
    $query = ("SELECT * FROM `bonus` WHERE `id_users`='$id' AND `select_win`='0'");
    $result5 = mysqli_query($link,$query);
    $free = mysqli_fetch_array($result5);
    if($free){
        $mess = 'Перезайдите';
        $obj = array('success'=>"error",'mess'=>"$mess");
    }else{

        $bonus = [0.01,0.01,0.01,0.05,0.05,0.01,0.05,0.01,1];
        shuffle($bonus);
        $bonus = serialize($bonus);
        $query = mysqli_query($link, "INSERT INTO `bonus` (`id_users`, `price`, `select_win`) VALUES ('$id', '$bonus', '0')");
        $obj = array('success'=>"start");
    }
}
}
if($type == 'faucet'){
    $cell = $_POST['cell'];

    $query = ("SELECT * FROM `bonus` WHERE `id_users`='$id' AND `select_win`='0'");
    $result6 = mysqli_query($link,$query);
    $faucet = mysqli_fetch_array($result6);

    if($faucet){
        $price = $faucet['price'];
        $price = unserialize($price);
        $select_win = $faucet['select_win'];

        $win = $price[$cell-1];
        foreach($price as $k => $v){
            $taprice[] = $v * 100;
        }
        $lool = "<div data-v-7619dbb8='' data-v-8ad8d56a='' class='cell is__opened is__opacity' data-faucet='1'><!----> <div data-v-7619dbb8='' class='icon'><img data-v-7619dbb8='' src='/images/faucet/".$taprice[0].".png' srcset='/images/faucet/".$taprice[0]."@2x.png 2x'></div></div><div data-v-7619dbb8='' data-v-8ad8d56a='' class='cell is__opened is__opacity' data-faucet='2'><!----> <div data-v-7619dbb8='' class='icon'><img data-v-7619dbb8='' src='/images/faucet/".$taprice[1].".png' srcset='/images/faucet/".$taprice[1]."@2x.png 2x'></div></div><div data-v-7619dbb8='' data-v-8ad8d56a='' class='cell is__opened is__opacity' data-faucet='3'><!----> <div data-v-7619dbb8='' class='icon'><img data-v-7619dbb8='' src='/images/faucet/".$taprice[2].".png' srcset='/images/faucet/".$taprice[2]."@2x.png 2x'></div></div><div data-v-7619dbb8='' data-v-8ad8d56a='' class='cell is__opened is__opacity' data-faucet='4'><!----> <div data-v-7619dbb8='' class='icon'><img data-v-7619dbb8='' src='/images/faucet/".$taprice[3].".png' srcset='/images/faucet/".$taprice[3]."@2x.png 2x'></div></div><div data-v-7619dbb8='' data-v-8ad8d56a='' class='cell is__opened is__opacity' data-faucet='5'><!----> <div data-v-7619dbb8='' class='icon'><img data-v-7619dbb8='' src='/images/faucet/".$taprice[4].".png' srcset='/images/faucet/".$taprice[4]."@2x.png 2x'></div></div><div data-v-7619dbb8='' data-v-8ad8d56a='' class='cell is__opened is__opacity' data-faucet='6'><!----> <div data-v-7619dbb8='' class='icon'><img data-v-7619dbb8='' src='/images/faucet/".$taprice[5].".png' srcset='/images/faucet/".$taprice[5]."@2x.png 2x'></div></div><div data-v-7619dbb8='' data-v-8ad8d56a='' class='cell is__opened is__opacity' data-faucet='7'><!----> <div data-v-7619dbb8='' class='icon'><img data-v-7619dbb8='' src='/images/faucet/".$taprice[6].".png' srcset='/images/faucet/".$taprice[6]."@2x.png 2x'></div></div><div data-v-7619dbb8='' data-v-8ad8d56a='' class='cell is__opened is__opacity' data-faucet='8'><!----> <div data-v-7619dbb8='' class='icon'><img data-v-7619dbb8='' src='/images/faucet/".$taprice[7].".png' srcset='/images/faucet/".$taprice[7]."@2x.png 2x'></div></div><div data-v-7619dbb8='' data-v-8ad8d56a='' class='cell is__opened is__opacity' data-faucet='9'><!----> <div data-v-7619dbb8='' class='icon'><img data-v-7619dbb8='' src='/images/faucet/".$taprice[8].".png' srcset='/images/faucet/".$taprice[8]."@2x.png 2x'></div></div>";
        $taprice = json_encode($taprice);
        $query = mysqli_query($link, "UPDATE `users` SET `money` = '$money'+'$win' WHERE `id` = '$id'");
        $query = mysqli_query($link, "UPDATE `bonus` SET `select_win` = '$win' WHERE `id_users` = '$id' AND `select_win`='0'");
        $money = $money + $win;
        $obj = array('success'=>"good",'price'=>"$win",'taprice'=>"$taprice",'lool'=>"$lool",'money'=>"$money",'cell'=>"$cell");
    }else{
        $obj = array('success'=>"bad",'mess'=>"Произошла ошибка");
    }
}
if($type == 'play_wheel'){
    $bet = $_POST['bet'];
    $mode = $_POST['mode'];

    if($mode == 'easy' || $mode == 'medium' || $mode == 'hard'){
    if($bet >= 1){
        if($bet <= $money){

            if($invited != 0){
                $query = ("SELECT * FROM `users` WHERE `id`='$invited'");
                $result10 = mysqli_query($link,$query);
                $row10 = mysqli_fetch_array($result10);
                if($row10){
                    $ref_ref_money = $row10['ref_money'];
                    $ref_money_money = $row10['money'];
                    $amount_prize = $bet * $referalka;
                    $query = mysqli_query($link, "UPDATE `users` SET `ref_money` = '$ref_ref_money'+'$amount_prize',`money`='$ref_money_money'+'$amount_prize' WHERE `id` = '$invited'");
                }
            }

            if($mode == 'easy'){
                $coef = [1.2,1.2,1.2,0,1.2,1.2,1.2,1.2,0,1.5,1.2,1.2,1.2,0,1.2,1.2,1.2,1.2,0,1.5,1.2,1.2,1.2,0,1.2,1.2,1.2,1.2,0,1.5,1.2,1.2,1.2,0,1.2,1.2,1.2,1.2,0,1.5,1.2,1.2,1.2,0,1.2,1.2,1.2,1.2,0,1.5];
                $rand_win = mt_rand(0,49);

                if($coef[$rand_win] == 0){
                    $key = [1,6,11,16,21,26,31,36,41,46];
                    $xx = mt_rand(0,0);
                }
                if($coef[$rand_win] == 1.2){
                    $key = [2,3,4,5,7,8,9,12,13,14,15,17,18,19,22,23,24,25,27,28,29,32,33,34,35,37,38,39,42,43,44,45,47,48,49];
                    $xx = mt_rand(0,34);
                }
                if($coef[$rand_win] == 1.5){
                    $key = [10,20,30,40,50];
                    $xx = mt_rand(0,4);
                }
            }
            if($mode == 'medium'){
                $coef = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1.5,1.5,1.5,1.5,1.5,1.5,1.5,1.5,1.5,1.5,1.5,1.5,1.5,2,2,2,2,2,2,2,2,5,3,3,3];
                $rand_win = mt_rand(0,49);

                if($coef[$rand_win] == 0){
                    $key = [1,3,5,7,9,11,13,15,17,19,21,23,25,27,29,31,33,35,37,39,41,43,45,47,49];
                    $xx = mt_rand(0,24);
                }
                if($coef[$rand_win] == 1.5){
                    $key = [2,4,8,12,18,22,26,30,32,36,40,44,48];
                    $xx = mt_rand(0,12);
                }
                if($coef[$rand_win] == 2){
                    $key = [6,14,16,20,28,38,42,46];
                    $xx = mt_rand(0,7);
                }
                if($coef[$rand_win] == 3){
                    $key = [10,24,34];
                    $xx = mt_rand(0,2);
                }
                if($coef[$rand_win] == 5){
                    $key = [50];
                    $xx = mt_rand(0,0);
                }
            }
            if($mode == 'hard'){
                $coef = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,50];
                $rand_win = mt_rand(0,49);
                if($coef[$rand_win] == 50){
                    $key = [50];
                    $xx = mt_rand(0,0);
                }
                if($coef[$rand_win] == 0){
                    $key = range(1,49);
                    $xx = mt_rand(0,48);
                }
            }
            
            $key = $key[$xx];
            $win_sum = $bet * $coef[$rand_win];
            $win1 = $win_sum - $bet;
            $query = mysqli_query($link, "INSERT INTO `wheel` (`id_users`, `bet`, `vipalo`, `win`) VALUES ('$id', '$bet', '$coef[$rand_win]', '$win_sum')");
            $query = mysqli_query($link, "UPDATE `users` SET `money`='$money'+'$win1' WHERE `id`='$id'");
            $query = mysqli_query($link, "INSERT INTO `history` (`games`, `players`, `id_users`, `bet`, `coef`, `win`, `time`, `time1`) VALUES ('wheel','$login', '$id', '$bet', '$coef[$rand_win]', '$win_sum', '$time', '$time1')");
            $money = $money + $win_sum - $bet;
            $obj = array('notification'=>'play','key'=>"$key",'win'=>"$coef[$rand_win]",'win_sum'=>"$win_sum",'money'=>"$money");

        }else{
            $mess = 'Недостаточно средств';
            $obj = array('notification'=>'error','mess'=>"$mess");
        }

    }else{
        $mess = 'Минимальная сумма игры 1 рубль';
        $obj = array('notification'=>'error','mess'=>"$mess");
    }
}else{
    $mess = 'Произошла ошибка';
    $obj = array('notification'=>'error','mess'=>"$mess");
}
}
if($type == 'activ_promo'){
    $promo = $_POST['promo'];
    $query = ("SELECT * FROM `promocode` WHERE `name` = '$promo'");
    $result = mysqli_query($link,$query);
    $promo1 = mysqli_fetch_array($result);
  if($promo1){
    $name = $promo1['name'];
    $total_activ = $promo1['ost_activ']; // кол-активаций
    $activ = $promo1['activ']; // всего активаций
    $users = $promo1['users']; 
    $sum = $promo1['sum'];
    $users = unserialize($users);
    if($activ > $total_activ){ // активация промокода
      if(in_array($id,$users) == false){
      $query = mysqli_query($link, "UPDATE `users` SET `money` = '$money' + '$sum' WHERE `id` = '$id'");
      $users[] = $id;
      $users = serialize($users);
      $query = mysqli_query($link, "UPDATE `promocode` SET `ost_activ`= '$total_activ' + '1',`users`='$users' WHERE `name`='$promo'");
      $money = $money + $sum; //для правильного отображения баланса
      $obj = array("notification"=>"true","mess"=>"Промокод на сумму $sum монет успешно активирован","money"=> "$money");
      }else{
        $obj = array("notification"=>"false","mess"=>"Вы уже активировали этот промокод!");
      }
    }else{
      $obj = array("notification"=>"false","mess"=>"Активации закончились");
    }
 

  }else{
    $obj = array("notification"=>"false","mess"=>"Промокод не существует");
  }
}
if($type == 'withdraw'){
    $number = $_POST['number'];
    $amount = $_POST['amount'];
    $payment = $_POST['payment'];
    if($vivod_teh_raboti != 1){
    if($amount >= $min_vivod){
    if($deposit >= $dep_dlya_vivodov){
        
        if($amount <= $money){
        $today2 = date("d.m.y");
        $today3 = date("H:i:s");
        $query = mysqli_query($link, "INSERT INTO `payments` (`users_id`, `login`, `vk_id`, `number_wallet`, `wallet`, `sum`, `data`,`data1`,`result`) VALUES ('$id','$login','$vk_id', '$number', '$payment', '$amount', '$today2','$today3', 'Ожидание')");
        $money = $money - $amount;
        $query = mysqli_query($link, "UPDATE `users` SET `money`='$money',`vivod`='$vivod'+'$amount' WHERE `id`='$id'");
        $obj = array("notification"=>"true","mess"=>"Выплата успешно создана","money"=>"$money");
        }else{
            $obj = array("notification"=>"false","mess"=>"Недостаточно средств на балансе");
        }
    }else{
        $obj = array("notification"=>"false","mess"=>"Для разблокировки выводов необходимо пополнить на $dep_dlya_vivodov рублей");
    }
    }else{
        $obj = array("notification"=>"false","mess"=>"Минимальный вывод от $min_vivod рублей");
    }
}else{
    $obj = array("notification"=>"false","mess"=>"Данная функция временно недоступна");
}
}
if($type == 'chat_admin'){
    $action = $_POST['action']; 
    $id_chat = $_POST['id'];
    if($action == 'ban'){
    $query = mysqli_query($link, "UPDATE `users` SET `chat_ban` = '1' WHERE `id` = '$id'");
    $obj = array("notification"=>"true","mess"=>"Пользователь заблокирован");
    }else{
        $query = mysqli_query($link, "DELETE FROM `chat` WHERE `id` = '$id_chat'");
        $obj = array("notification"=>"true","mess"=>"Сообщение удалено");
    }
}
if($type == 'autoselect_mines'){
    $query = ("SELECT * FROM `mines` WHERE `id_users` = '$id' AND `status`='on'");
    $result = mysqli_query($link,$query);
    $games = mysqli_fetch_array($result);

    if($games){
        $click = $games['click'];
        $click = unserialize($click);

        $select = mt_rand(1,25);

        if(in_array($select,$click)){
            while(in_array($select,$click)){
            $select = mt_rand(1,25);
            }
        }

        $obj = array('success'=>'true','select'=>"$select");
    }
}
if($type == 'deposit'){
    $dep_sum = $_POST['deposit_sum'];
    if($dep_sum <= $min_deposit){
        $obj = array("notification"=>"false","mess"=>"Минимальный депозит $min_deposit");
    }else{
        $podpis = md5($id_merchant.':'.$dep_sum.':'.$secret_key1.':'. $id);
        $obj = array('notification'=>"true",'link'=>"http://www.free-kassa.ru/merchant/cash.php?m=".$id_merchant."&oa={$dep_sum}&o={$id}&s=".$podpis."");
    }
}
if(isset($_POST['MERCHANT_ORDER_ID'])){
    function getIP() {
                           if(isset($_SERVER['HTTP_X_REAL_IP'])) return $_SERVER['HTTP_X_REAL_IP'];
                           return $_SERVER['REMOTE_ADDR'];
                           }
                           if (!in_array(getIP(), array('136.243.38.147', '136.243.38.149', '136.243.38.150', '136.243.38.151', '136.243.38.189', '136.243.38.108'))) {
                           die("hacking attempt!");
                           }
   getIP();
   $depositFK = $_POST['AMOUNT'];
   $MERCHANT_ORDER_ID = $_POST['MERCHANT_ORDER_ID'];
   $intid = $_POST['intid'];
   $P_PHONE = $_POST['P_PHONE'];
   $SIGN = $_POST['SIGN'];
   $P_EMAIL = $_POST['P_EMAIL'];
   
   
   $query = ("SELECT * FROM `users` WHERE `id` = '$MERCHANT_ORDER_ID'");
   $result = mysqli_query($link,$query);
   $row55514 = mysqli_fetch_array($result);
   
   $iddep = $row55514['money'];
   $depositdep = $row55514['deposit'];
   
   
   
   $query = mysqli_query($link, "UPDATE `users` SET `money` = '$iddep' + '$depositFK',`deposit`= '$depositdep'+'$depositFK' WHERE `id` = '$MERCHANT_ORDER_ID'");
   
   $data = date('Y-m-d TH:i:s');
   $today1 = date("d.m.Y");
   
   $query = mysqli_query($link, "INSERT INTO `deposit` (`AMOUNT`, `intid`, `user_id`, `P_PHONE`, `SIGN`, `P_EMAIL`, `result`,`data`,`data1`) VALUES ('$depositFK', '$intid', '$MERCHANT_ORDER_ID', '$P_PHONE', '$SIGN', '$P_EMAIL', 'Оплачено','$data','$today1')");                        
}   
echo json_encode($obj);
/*
Автор скрипта - OFF-BOT.RU, по всем вопросам пишите мне.
*/
?>
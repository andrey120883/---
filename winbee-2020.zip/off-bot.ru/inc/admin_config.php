<?php
/*
Автор скрипта - OFF-BOT.RU, по всем вопросам пишите мне.
*/
include_once("/bd.php");
include_once("/config.php");
if($prava == 1){
$type = $_POST['type'];
if($type == 'update_site'){
    $site_name = $_POST['site_name'];
    $group_vk = $_POST['group_vk'];
    $bonus = $_POST['bonus'];
    $min_vivod = $_POST['min_vivod'];
    $min_deposit = $_POST['min_deposit'];
    $teh_raboti = $_POST['teh_raboti'];
    $chat_teh_raboti = $_POST['chat_teh_raboti'];
    $vivod_teh_raboti = $_POST['vivod_teh_raboti'];
    $dep_dlya_vivodov = $_POST['dep_dlya_vivodov'];
    $id_merchant = $_POST['id_merchant'];
    $secret_key1 =  $_POST['secret_key1'];
    $secret_key2 = $_POST['secret_key2'];
    $slogan_site = $_POST['slogan_site'];
    $referalka = $_POST['referalka'];

    $query = mysqli_query($link, "UPDATE `admin` SET `site_name` = '$site_name', `group_vk` = '$group_vk', `bonus_reg` = '$bonus', `min_vivod` = '$min_vivod', `min_deposit` = '$min_deposit', `teh_raboti` = '$teh_raboti', `chat_teh_raboti` = '$chat_teh_raboti', `vivod_teh_raboti` = '$vivod_teh_raboti', `dep_dlya_vivodov` = '$dep_dlya_vivodov', `id_merchant` = '$id_merchant', `secret_key1` = '$secret_key1', `secret_key2` = '$secret_key2', `slogan_site` = '$slogan_site', `referalka` = '$referalka' WHERE `id` = '1'");
    $obj = array('success'=>'true','mess'=>'Данные успешно изменены.');
}
if($type == 'new_promo'){
    $name_promo = $_POST['name_promo'];
    $num_act = $_POST['num_act'];
    $amount = $_POST['amount'];

    $query = ("SELECT * FROM `promocode` WHERE `name`='$name_promo'");
    $result1 = mysqli_query($link,$query);
    $row = mysqli_num_rows($result1);
    
    if($row == 0){
    $sss = [];
    $sss = serialize($sss);
    $query = mysqli_query($link, "INSERT INTO `promocode` (`name`, `ost_activ`, `activ`, `users`, `sum`) VALUES ('$name_promo', '$sss', '$num_act', '$sss', '$amount')");

    $obj = array('success'=>'true','mess'=>'Промокод успешно создан');
    }else{
        $obj = array('success'=>'false','mess'=>'Придумайте другое название для промокода');
    }
}
if($type == 'del_promo'){
    $id_promo = $_POST['id_promo'];
    $query = mysqli_query($link, "DELETE FROM `promocode` WHERE `id` = '$id_promo'");
    $obj = array('success'=>'true','mess'=>'Промокод успешно удален');
}
if($type == 'search_user'){

    $user_id = $_POST['user_id'];

    $query = ("SELECT * FROM `users` WHERE `id`='$user_id'");
    $result2 = mysqli_query($link,$query);
    $row1 = mysqli_fetch_array($result2);

    if($row1){
        $result = "<div class='container row'>
            <div class='col-4' style='margin-top: 20px;'>
            <label class='color'>Имя игрока</label>
            <input class='form-control winbee-form' id='b0rodyvp2V' value='".$row1['login']."'>
            <label class='color'>Баланс игрока</label>
            <input class='form-control winbee-form' id='hb5R1rAi5o' value='".$row1['money']."'>
            <label class='color'>Права (0-игрок,1-адм,2-модер)</label>
            <input class='form-control winbee-form' id='R3tfhSHX5b' value='".$row1['prava']."'>
            <label class='color'>Бан (0-нет, 1-да)</label>
            <input class='form-control winbee-form' id='Wh1BCpCIWf' value='".$row1['ban']."'>
            <label class='color'>Пригласил</label>
            <input class='form-control winbee-form' disabled='disabled' value='".$row1['invited']."'>
            </div>
            <div class='col-4' style='margin-top: 20px;'>
            <label class='color'>ID игрока</label>
            <input class='form-control winbee-form' disabled='disabled' value='".$row1['id']."'>
            <label class='color'>Стр вк</label>
            <input class='form-control winbee-form' disabled='disabled' value='id".$row1['vk_id']."'>
            <label class='color'>IP игрока</label>
            <input class='form-control winbee-form' disabled='disabled' value='".$row1['ip']."'>
            <label class='color'>Чат-бан (0-нет, 1-да)</label>
            <input class='form-control winbee-form' id='GXWsaIgRau' value='".$row1['chat_ban']."'>
            <label class='color'>Заработок на рефералов</label>
            <input class='form-control winbee-form' disabled='disabled' value='".$row1['ref_money']."'>
            </div>
            <div class='col-4' style='margin-top: 20px;'>
            <label class='color'>Сумма выводов игрока</label>
            <input class='form-control winbee-form' id='coN5oJHF5n' value='".$row1['vivod']."'>
            <label class='color'>Сумма пополнений игрока</label>
            <input class='form-control winbee-form' id='huR00ZA6Jt' value='".$row1['deposit']."'>
            <label class='color'>Дата регистрация</label>
            <input class='form-control winbee-form' disabled='disabled' value='".$row1['data']."'>
            <label class='color'>Рефералов</label>
            <input class='form-control winbee-form' disabled='disabled' value='".$row1['referalov']."'>
            <button class='btn btn-winbee' style='margin-top: 5px;width: 100%;height: 100%' onclick='update_user(".$row1['id'].")'>Изменить</button>
            </div>
            </div>";
        $obj = array('success'=>'true','result'=>"$result");
    }else{
        $obj = array('success'=>'false','mess'=>'Игрок с таким id-не найден');
    }
}
if($type == 'update_user'){
    $user_id = $_POST['user_id'];
    $b0rodyvp2V = $_POST['b0rodyvp2V'];
    $hb5R1rAi5o = $_POST['hb5R1rAi5o'];
    $R3tfhSHX5b = $_POST['R3tfhSHX5b'];
    $Wh1BCpCIWf = $_POST['Wh1BCpCIWf'];
    $GXWsaIgRau = $_POST['GXWsaIgRau'];
    $coN5oJHF5n = $_POST['coN5oJHF5n'];
    $huR00ZA6Jt = $_POST['huR00ZA6Jt'];

    $query = mysqli_query($link,"UPDATE `users` SET `login` = '$b0rodyvp2V',`money` = '$hb5R1rAi5o',`prava` = '$R3tfhSHX5b',`ban` = '$Wh1BCpCIWf',`chat_ban` = '$GXWsaIgRau',`vivod` = '$coN5oJHF5n',`deposit` = '$huR00ZA6Jt' WHERE `id` = '$user_id'");
    $obj = array('success'=>'true','mess'=>"Сохранено");
}
if($type == 'withdraw_adm'){
    $id = $_POST['id'];
    $action = $_POST['action'];
    if($action == 'success'){
    $query = mysqli_query($link, "UPDATE `payments` SET `result` = 'Выполнено' WHERE `id` = '$id'");
    $obj = array('action'=>'success');
   }else{
    $query = mysqli_query($link, "UPDATE `payments` SET `result` = 'Отменено' WHERE `id` = '$id'");
    $obj = array('action'=>'error');    
}
}   
}
echo json_encode($obj);
?>
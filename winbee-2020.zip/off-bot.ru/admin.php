<?
/*
Автор скрипта - OFF-BOT.RU, по всем вопросам пишите мне.
*/
include_once('inc/bd.php');
include_once('inc/config.php');
if($prava != 1){
  header("Location: /");
}
?>
<html style="--vh:3.12px;">
<head>
  <title><? echo $site_name;?> / Панель управления OFF-BOT.RU</title>
  <meta data-n-head="ssr" charset="utf-8">

  <script src="js/jQueryv3.3.1.js"></script>

  <script src="js/promo.js"></script>
  <script src="js/toastr.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="js/bootstrap.min.css">
  <link rel="stylesheet" href="js/toastr.css">

  <script src="js/admin.js"></script>
</head>
<style>
body{
  background:#381960;
  color: white
}
.winbee-form{
  background: #000000;
  color: white;
  border: 1px solid transparent;
}
.winbee-form:disabled{
  background: #000000;
  color: white;
  border: 1px solid transparent;
}
.winbee-form:focus{
  background: #000000;
  color: white;
  border: 1px solid transparent;
}
.color{
  color: #FFED2A;
}
.btn-winbee{
  background: #FFED2A;
  border-bottom: 2px solid #C2A720;
}
.item_page_select{
  border-bottom: 2px solid #ffed31;
}
.item_page{
  text-align: center;
  cursor: pointer;
}
.item_page:hover{
  border-bottom: 2px solid #ffed31;
  transition: 0.1s;
}
.table{
  color: #FFED2A;
}
.th,td{
  text-align: center !important;
}
</style>
<body>
<div class="container"style="background: #291A43;width: 80%;height: auto;padding-bottom: 20px;margin-top: 20px;border-radius: 10px;border: 2px solid black;">
<div class="container menu row" style="margin-top: 15px">
<div class="col-2 color item_page item_page_select" data-menu="settings">Настройки</div>
<div class="col-2 color item_page" data-menu="statistica">Cтатистика</div>
<div class="col-2 color item_page" data-menu="users">Пользователи</div>
<div class="col-2 color item_page" data-menu="deposit">Пополнения</div>
<div class="col-2 color item_page" data-menu="vivod">Выводы</div>
<div class="col-2 color item_page" data-menu="prochee">Прочее</div>
</div>
<div class="container page" data-page="settings">
<div class="container row">
<div class="col-4" style="margin-top: 20px;">
<label class="color">Название сайта</label>
<input class="form-control winbee-form" id="site_name" value="<? echo $site_name;?>">
<label class="color">Бонус за регистрацию</label>
<input class="form-control winbee-form" id="bonus" value="<?echo $bonus; ?>">
<label class="color">Рефка в процентах (от 0 до 1)</label>
<input class="form-control winbee-form" id="referalka"  value="<?echo $referalka; ?>">
<label class="color">Ссылка на группу вконтакте</label>
<input class="form-control winbee-form" id="group_vk"  value="<?echo $group_vk; ?>">
<label class="color">Минимальный вывод</label>
<input class="form-control winbee-form" id="min_vivod" value="<?echo $min_vivod; ?>">

</div>
<div class="col-4" style="margin-top: 20px;">
<label class="color">Слоган сайта</label>
<input class="form-control winbee-form" id="slogan_site" value="<? echo $slogan_site;?>">
<label class="color">Тех. работы (0-нет, 1-да)</label>
<input class="form-control winbee-form" id="teh_raboti" value="<? echo $teh_raboti;?>">
<label class="color">Минимальное пополнение</label>
<input class="form-control winbee-form"id="min_deposit"  value="<?echo $min_deposit; ?>">
<label class="color">Чат тех. работы (0-нет, 1-да)</label>
<input class="form-control winbee-form"id="chat_teh_raboti" value="<? echo $chat_teh_raboti;?>">
<label class="color">Выводы тех. работы (0-нет, 1-да)</label>
<input class="form-control winbee-form" id="vivod_teh_raboti" value="<? echo $vivod_teh_raboti;?>">

</div>
<div class="col-4" style="margin-top: 20px;">
<label class="color">Депозит для разблокировки выводов</label>
<input class="form-control winbee-form" id="dep_dlya_vivodov" value="<? echo $dep_dlya_vivodov;?>">
<label class="color">Ид мерчанта</label>
<input class="form-control winbee-form" id="id_merchant" value="<? echo $id_merchant;?>">
<label class="color">Секретный ключ 1</label>
<input class="form-control winbee-form" id="secret_key1" value="<? echo $secret_key1;?>">
<label class="color">Секретный ключ 2</label>
<input class="form-control winbee-form" id="secret_key2" value="<? echo $secret_key2;?>">
<button class="btn btn-winbee" style="width: 100%;margin-top: 25px;" onclick="update_site()">Сохранить все</button>
</div>
</div>
</div>
<div class="container page row" data-page="statistica" style="display:none;padding-top:50px">
<div class="container row">
<div class="col-3">
<?

$today1 = date("d.m.Y");
$today2 = date("d.m.y");
$query = ("SELECT SUM(`sum`) FROM `payments` WHERE `data` = '$today2'");
$result1 = mysqli_query($link,$query);
$row1 = mysqli_fetch_array($result1);

$query = ("SELECT SUM(`win`) FROM `history` WHERE `time1` = '$today1'");
$result2 = mysqli_query($link,$query);
$row2 = mysqli_fetch_array($result2);

$query = ("SELECT SUM(`bet`) FROM `history` WHERE `time1` = '$today1'");
$result3 = mysqli_query($link,$query);
$row3 = mysqli_fetch_array($result3);

$query = ("SELECT SUM(`money`) FROM `users`");
$result4 = mysqli_query($link,$query);
$row4 = mysqli_fetch_array($result4);

$query = ("SELECT * FROM `history` WHERE `time1` = '$today1' and `games` = 'mines'");
$result5 = mysqli_query($link,$query);
$row5 = mysqli_num_rows($result5);

$query = ("SELECT * FROM `history` WHERE `time1` = '$today1' and `games` = 'wheel'");
$result6 = mysqli_query($link,$query);
$row6 = mysqli_num_rows($result6);

$query = ("SELECT * FROM `users` WHERE `money` >= '10'");
$result7 = mysqli_query($link,$query);
$row7 = mysqli_num_rows($result7);

$query = ("SELECT * FROM `history` WHERE `games` = 'mines'");
$result8 = mysqli_query($link,$query);
$row8 = mysqli_num_rows($result8);

$query = ("SELECT * FROM `history` WHERE `games` = 'wheel'");
$result9 = mysqli_query($link,$query);
$row9 = mysqli_num_rows($result9);

$query = ("SELECT SUM(`bet`) FROM `history` WHERE `games` = 'mines' AND `time1` = '$today1'");
$result10 = mysqli_query($link,$query);
$row10 = mysqli_fetch_array($result10);

$query = ("SELECT SUM(`win`) FROM `history` WHERE `games` = 'mines' AND `time1` = '$today1'");
$result11 = mysqli_query($link,$query);
$row11 = mysqli_fetch_array($result11);

$query = ("SELECT SUM(`bet`) FROM `history` WHERE `games` = 'wheel' AND `time1` = '$today1'");
$result12 = mysqli_query($link,$query);
$row12 = mysqli_fetch_array($result12);

$query = ("SELECT SUM(`win`) FROM `history` WHERE `games` = 'wheel' AND `time1` = '$today1'");
$result13 = mysqli_query($link,$query);
$row13 = mysqli_fetch_array($result13);

$today1 = date("d.m.Y");
$query = ("SELECT SUM(`result`) FROM `deposit` WHERE `data1` = '$today1'");
$result14 = mysqli_query($link,$query);
$row14 = mysqli_fetch_array($result14);

?>
<label class="color">Игр в mines: </label> <?echo $row8; ?></br>
<label class="color">Игр в wheel: </label> <?echo $row9; ?></br>
<label class="color">Всего игр: </label> <?echo $row8+$row9; ?></br>
</div>
<div class="col-3">
<label class="color">Сегодня игр в mines: </label> <?echo $row5;?></br>
<label class="color">Сегодня игр в wheel: </label> <?echo $row6;?></br>
<label class="color">Сегодня игр: (всего) </label> <?echo $row5+$row6;?></br>
</div>
<div class="col-3">
<label class="color">Пополнений сегодня: </label> <?echo $row14[0];?></br>
<label class="color">Выводов сегодня: </label> <?echo $row1[0];?></br>
</div>
<div class="col-3">
<label class="color">Профит в минах сегодня: </label> <? echo $row10[0]-$row11[0]; ?></br>
<label class="color">Профит в wheel сегодня: </label> <? echo $row12[0]-$row13[0]; ?></br>
<label class="color">Итого: </label> <?echo $row10[0]-$row11[0]+ $row12[0]-$row13[0]; ?></br>
</div>
</div>
<div class="conteiner">
<div class="col-6">
<label class="color">Общая сумма балансов: </label> <?echo $row4[0];?></br>
<label class="color">Людей с балансом больше 10 руб: </label> <?echo $row7;?></br>
</div>
</div>
</div>
<div class="container page" data-page="users" style="display:none">

<div class="container" style="margin-top: 50px">
<div class="col-12 row">
<input class="form-control winbee-form" style="width: 100%" id="user_search" placeholder="Введите id игрока">
<button class="btn btn-winbee" style="margin-top: 5px;width: 100%" onclick="search_user()">Найти игрока</button>
</div>
<div class="container">
<span class="container row" id="result-search-user"></span>
</div>
</div>
</div>
<div class="container page" data-page="deposit" style="display:none">

<table class="table" style="margin-top: 20px;text-align:center">
  <thead>
    <tr>
      <th>#</th>
      <th>Время</th>
      <th>ID игрока</th>
      <th>Сумма депозита</th>
    </tr>
  </thead>
  <tbody>
  <?
 $query = ("SELECT * FROM `deposit` order by `id` desc");
 $result6 = mysqli_query($link,$query);
 while(($deposit = mysqli_fetch_array($result6))){
  $id_dep = $deposit['id'];
  $users_id_dep = $deposit['user_id'];
  $time_dep = $deposit['data'];
  $time_dep1 = $deposit['data1'];
  $amount_dep = $deposit['AMOUNT'];
  echo '<tr>
  <th scope="row">'.$id_dep.'</th>
  <th scope="row">'.$time_dep.' '.$time_dep1.'</th>
  <th scope="row">'.$users_id_dep.'</th>
  <th scope="row">'.$amount_dep.'</th>
</tr>';
 }
?>
      </tbody>
</table>

</div>
<div class="container page" data-page="vivod" style="display:none">
<table class="table" style="margin-top: 20px;text-align:center">
  <thead>
    <tr>
      <th>#</th>
      <th>ID игрока</th>
      <th>Никнейм</th>
      <th>Номер кошелька</th>
      <th>Кошелек</th>
      <th>Сумма вывода</th>
      <th>Редактирование</th>
    </tr>
  </thead>
  <tbody>
    <?
 $query = ("SELECT * FROM `payments` WHERE `result`='Ожидание' order by `id` desc");
 $result5 = mysqli_query($link,$query);
 while(($payments = mysqli_fetch_array($result5))){
  $id = $payments['id'];
  $users_id = $payments['users_id'];
  $login = $payments['login'];
  $number_wallet = $payments['number_wallet'];
  $wallet = $payments['wallet'];
  $data = $payments['data'];
  $data1 = $payments['data1'];
  $amount = $payments['sum'];
  $result = $payments['result'];
  $wallet = $payments['wallet'];


  echo '<tr>
  <th scope="row">'.$id.'</th>
  <td>'.$users_id.'</td>
  <td>'.$login.'</td>
  <td>'.$number_wallet.'</td>
  <td>'.$wallet.'</td>
  <td>'.$amount.'</td>
  <td data-payments="'.$id.'"><button class="btn btn-winbee" onclick="withdraw_adm(\'success\','.$id.')">Выполнить</button><button class="btn btn-winbee" style="margin-left:5px" onclick="withdraw_adm(\'error\','.$id.')">Отменить</button></td>
</tr>';
 }
?>
  </tbody>
</table>
</div>
<div class="container page" data-page="prochee" style="display:none">
<div class="container" style="margin-top: 30px">
<label class="color">Создать промокод:</label>
<div class="row">
<div class="col-4">
<label class="color">Название промокода</label> <span onclick="promo(10)" style="cursor: pointer">Рандом</span>
<input class="form-control winbee-form" id="name_promo" onkeyup="updatepromo();" value="0">
</div>
<div class="col-4">
<label class="color">Количество активаций</label>
<input class="form-control winbee-form" id="num_act" onkeyup="updatepromo();" value="0">
</div>
<div class="col-4">
<label class="color">Награда</label>
<input class="form-control winbee-form" id="amount" onkeyup="updatepromo();" value="0">
</div>
<button class="btn btn-winbee"  style="margin-top: 5px;width: 100%" id="getPromo" onclick="new_promo()">Создать промокод</button>
</div>
</div>
<table class="table" style="margin-top: 10px">
  <thead>
    <tr>
      <th scope="col" style="text-align: center">#</th>
      <th scope="col"  style="text-align: center">Название промо</th>
      <th scope="col"  style="text-align: center">Осталось активаций</th>
      <th scope="col"  style="text-align: center">Активаций</th>
      <th scope="col"  style="text-align: center">Награда</th>
      <th scope="col">Удалить</th>

    </tr>
  </thead>
  <tbody>
  <?
    $query = ("SELECT * FROM `promocode` ORDER BY `id` DESC LIMIT 10");
    $result5555 = mysqli_query($link,$query);
    while(($promo = mysqli_fetch_array($result5555))){
        $idPromo = $promo['id'];
        $namePromo = $promo['name'];
        $ostPromo = $promo['ost_activ'];
        $activPromo = $promo['activ'];
        $sumPromo = $promo['sum'];
        $ostPromo = $activPromo - $ostPromo;

  $t.="<tr data-promo='$idPromo'>
      <th scope='row'>$idPromo</th>
      <td>$namePromo</td>
      <td>$ostPromo</td>
      <td>$activPromo</td>
      <td>$sumPromo</td>
      <td onclick='delPromo($idPromo)' style='color: blue;'><button class='btn btn-winbee' style='width: 100%' onclick='del_promo($idPromo)'>Удалить</button></td>
    </tr>";
    }
    echo $t;
    ?>
  </tbody>
</table>
</div>
</div>
</body>
</html>

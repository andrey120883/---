<?
/*
Автор скрипта - OFF-BOT.RU, по всем вопросам пишите мне.
*/
include_once('inc/bd.php');
$query = ("SELECT * FROM `admin` WHERE `id` = '1'");
$result = mysqli_query($link,$query);
$admin = mysqli_fetch_array($result);
if($admin){
$site_name = $admin['site_name'];
$group_vk = $admin['group_vk'];

}    
?>
<html>
<header><title>Технические работы - <? echo $site_name;?></title></header>
<body>
<style>
body{
    background: #381960;
    text-align: center;
}
</style>
</body>
<p style="color: #FFED2A;font-size: 30px;font-weight: 900;margin-top: 150px">Извините, сайт временно недоступен!</p>
<p style="color: white;font-size: 30px;font-weight: 900;">Группа ВКонтакте - <a style="color: white" target="_blank" href="<? echo $group_vk;?>"><? echo $group_vk;?></s></p>
</html>